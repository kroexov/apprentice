/* Code generated from jsonrpc schema by rpcgen v2.5.x with typescript v1.0.0; DO NOT EDIT. */
/* eslint-disable */
export interface IAdvanceResult {
  candidate?: ICandidate,
  candidateStage?: ICandidateStage
}

export interface IAuthLoginParams {
  login: string,
  password: string,
  userType: string
}

export interface IAuthRegisterParams {
  login: string,
  password: string,
  userType: string
}

export interface IAuthSignUpParams {
  params: ISignUpParams
}

export interface ICandidate {
  id: number,
  name: string,
  handle: string,
  login: string,
  city: string,
  age?: number,
  bio: string,
  avatarColor: string,
  initials: string,
  avatarUrl?: string,
  strengths: Array<string>,
  weaknesses: Array<string>,
  currentStageId: number,
  createdAt: string,
  updatedAt: string,
  completedAt?: string
}

export interface ICandidateAddParams {
  candidate: ICandidate
}

export interface ICandidateAdvanceParams {
  candidateID: number,
  score: number
}

export interface ICandidateBrief {
  id: number,
  name: string,
  handle: string,
  avatarColor: string,
  initials: string,
  avatarUrl?: string,
  currentStageId: number
}

export interface ICandidateDeleteParams {
  id: number
}

export interface ICandidateDetail {
  id: number,
  name: string,
  handle: string,
  city: string,
  age?: number,
  avatarColor: string,
  initials: string,
  avatarUrl?: string,
  strengths: Array<string>,
  weaknesses: Array<string>,
  currentStage?: IStage,
  currentCandidateStage?: ICandidateStageSummary,
  totalPoints: number,
  maxPoints: number,
  completedStages: number,
  stageCount: number,
  completedAt?: string,
  bio: string,
  history: Array<ICandidateStageHistory>
}

export interface ICandidateGetByIDParams {
  id: number
}

export interface ICandidateGetParams {
  sortBy: ICandidateSort
}

export interface ICandidateMaterial {
  id: number,
  candidateId: number,
  materialId: number,
  readAt?: string,
  score?: number,
  scoredAt?: string,
  scoredBy?: number,
  notes?: string,
  createdAt: string
}

export interface ICandidateProfile {
  login: string,
  name: string,
  handle: string,
  city: string,
  age?: number,
  bio: string,
  avatarColor: string,
  initials: string,
  avatarUrl?: string,
  strengths: Array<string>,
  weaknesses: Array<string>
}

export interface ICandidateRateParams {
  candidateStageID: number,
  score: number
}

export interface ICandidateRollbackParams {
  candidateID: number
}

export interface ICandidateSetAvatarURLParams {
  candidateID: number,
  avatarUrl?: string
}

export interface ICandidateSetLinkParams {
  candidateStageID: number,
  link?: string
}

export interface ICandidateSetReadyParams {
  candidateStageID: number,
  isReady: boolean
}

export interface ICandidateStage {
  id: number,
  candidateId: number,
  stageId: number,
  link?: string,
  score?: number,
  scoredAt?: string,
  deadline?: string,
  createdAt: string,
  isReady: boolean,
  setReadyAt?: string,
  retries: number
}

export interface ICandidateStageHistory {
  stageId: number,
  stage?: IStage,
  status: string,
  score?: number,
  maxScore: number,
  scoredAt?: string,
  candidateStageId?: number,
  link?: string,
  deadline?: string,
  createdAt?: string,
  isReady: boolean,
  setReadyAt?: string,
  retries: number
}

export interface ICandidateStageSummary {
  link?: string,
  deadline?: string,
  createdAt: string,
  isReady: boolean,
  setReadyAt?: string,
  retries: number
}

export interface ICandidateSummary {
  id: number,
  name: string,
  handle: string,
  city: string,
  age?: number,
  avatarColor: string,
  initials: string,
  avatarUrl?: string,
  strengths: Array<string>,
  weaknesses: Array<string>,
  currentStage?: IStage,
  currentCandidateStage?: ICandidateStageSummary,
  totalPoints: number,
  maxPoints: number,
  completedStages: number,
  stageCount: number,
  completedAt?: string
}

export interface ICandidateUpdateParams {
  candidate: ICandidate
}

export interface ICandidateUpdateProfileParams {
  profile: ICandidateProfile
}

export interface ICandidateWithPassword {
  id: number,
  name: string,
  handle: string,
  login: string,
  city: string,
  age?: number,
  bio: string,
  avatarColor: string,
  initials: string,
  avatarUrl?: string,
  strengths: Array<string>,
  weaknesses: Array<string>,
  currentStageId: number,
  createdAt: string,
  updatedAt: string,
  completedAt?: string,
  password: string
}

export interface IKanbanColumn {
  stage?: IStage,
  candidates: Array<ICandidateSummary>
}

export interface IMaterial {
  id: number,
  title: string,
  type: string,
  url: string,
  description: string,
  maxScore: number,
  order: number,
  createdAt: string,
  updatedAt: string
}

export interface IMaterialAddParams {
  input: IMaterialInput
}

export interface IMaterialDeleteParams {
  id: number
}

export interface IMaterialGetByIDParams {
  id: number
}

export interface IMaterialGetParams {
  view?: IViewOps
}

export interface IMaterialInput {
  title: string,
  type: string,
  url: string,
  description: string,
  maxScore?: number,
  order?: number
}

export interface IMaterialScoreParams {
  candidateID: number,
  materialID: number,
  score: number,
  notes?: string
}

export interface IMaterialSetReadParams {
  materialID: number,
  read: boolean
}

export interface IMaterialUnscoreParams {
  candidateID: number,
  materialID: number
}

export interface IMaterialUpdateParams {
  id: number,
  input: IMaterialInput
}

export interface IMaterialsProgress {
  materials: Array<IMaterial>,
  candidates: Array<ICandidateBrief>,
  progress: Array<ICandidateMaterial>
}

export interface IMe {
  userId: number,
  login: string,
  userType: string
}

export interface IMyMaterialProgress {
  material: IMaterial,
  progress?: ICandidateMaterial
}

export interface ISignUpParams {
  login: string,
  password: string,
  name: string,
  handle?: string,
  city: string,
  age?: number,
  bio: string,
  avatarColor: string,
  initials?: string,
  avatarUrl?: string,
  strengths: Array<string>,
  weaknesses: Array<string>
}

export interface IStage {
  id: number,
  alias: string,
  order: number,
  title: string,
  shortTitle: string,
  description: string,
  maxScore: number,
  deadlineDays: number
}

export interface IStageAddParams {
  stage: IStage
}

export interface IStageDeleteParams {
  id: number
}

export interface IStageGetByIDParams {
  id: number
}

export interface IStageReorderParams {
  ids: Array<number>
}

export interface IStageUpdateParams {
  stage: IStage
}

export interface ISummary {
  candidatesCount: number,
  stagesCount: number,
  totalPoints: number,
  maxPoints: number,
  averageOrder: number
}

export interface IViewOps {
  page: number,
  pageSize: number
}

export const factory = (send: any) => ({
  auth: {
    /**
     * Login authenticates an existing admin or candidate and returns a fresh authKey.
     */
    login(params: IAuthLoginParams): Promise<string> {
      return send('auth.Login', params)
    },
    /**
     * Me returns the current principal — login, userId and userType (admin or
candidate). Requires the Authorization2 header; the middleware resolves
admin first, then candidate.
     */
    me(): Promise<IMe> {
      return send('auth.Me')
    },
    /**
     * Register creates a candidate and returns a fresh authKey (userType=user only).
     */
    register(params: IAuthRegisterParams): Promise<string> {
      return send('auth.Register', params)
    },
    /**
     * SignUp creates a candidate with the basic profile a candidate fills on the
registration form, and returns a fresh authKey. Credential policy matches
Register (login regex, password 8..72). Handle defaults to Login when not
provided, Initials defaults to defaultInitials(Login). The first available
stage is assigned automatically; currentStageId / completedAt are not
caller-controlled.
     */
    signUp(params: IAuthSignUpParams): Promise<string> {
      return send('auth.SignUp', params)
    }
  },
  candidate: {
    /**
     * Add creates a candidate and returns a one-time password (only here).
     */
    add(params: ICandidateAddParams): Promise<ICandidateWithPassword> {
      return send('candidate.Add', params)
    },
    /**
     * Advance scores current stage; moves to next or sets completedAt if last.
     */
    advance(params: ICandidateAdvanceParams): Promise<IAdvanceResult> {
      return send('candidate.Advance', params)
    },
    /**
     * Delete soft-deletes a candidate.
     */
    delete(params: ICandidateDeleteParams): Promise<boolean> {
      return send('candidate.Delete', params)
    },
    /**
     * Get returns candidate list with aggregates, sorted by sortBy.
     */
    get(params: ICandidateGetParams): Promise<Array<ICandidateSummary>> {
      return send('candidate.Get', params)
    },
    /**
     * GetByID returns full candidate detail with stage history.
     */
    getByID(params: ICandidateGetByIDParams): Promise<ICandidateDetail> {
      return send('candidate.GetByID', params)
    },
    /**
     * Kanban returns candidates grouped by their current stage.
     */
    kanban(): Promise<Array<IKanbanColumn>> {
      return send('candidate.Kanban')
    },
    /**
     * Rate sets or corrects score on a CandidateStage; does not move stage.
     */
    rate(params: ICandidateRateParams): Promise<ICandidateStage> {
      return send('candidate.Rate', params)
    },
    /**
     * Rollback reverts the most recent Advance; clears completedAt if set.
     */
    rollback(params: ICandidateRollbackParams): Promise<ICandidate> {
      return send('candidate.Rollback', params)
    },
    /**
     * SetAvatarURL attaches or detaches avatarUrl on a Candidate (admin or self-candidate).
avatarUrl param name (vs avatarURL) is intentional: zenrpc reuses it as the
JSON tag, and Candidate.AvatarURL ships json:avatarUrl — keep them in sync.
     */
    setAvatarURL(params: ICandidateSetAvatarURLParams): Promise<ICandidate> {
      return send('candidate.SetAvatarURL', params)
    },
    /**
     * SetLink attaches or detaches link on a CandidateStage (admin or self-candidate).
     */
    setLink(params: ICandidateSetLinkParams): Promise<ICandidateStage> {
      return send('candidate.SetLink', params)
    },
    /**
     * SetReady toggles isReady on a CandidateStage (admin or self-candidate).
Setting isReady=true requires a non-empty link. isReady=false has no
preconditions; allowed at any time, including after the stage is scored.
     */
    setReady(params: ICandidateSetReadyParams): Promise<ICandidateStage> {
      return send('candidate.SetReady', params)
    },
    /**
     * Update changes basic fields. login/currentStageId/timestamps are immutable here.
     */
    update(params: ICandidateUpdateParams): Promise<boolean> {
      return send('candidate.Update', params)
    },
    /**
     * UpdateProfile updates the editable subset of the *caller's own* profile.
Self-only: candidate-authKey required; admin requests are rejected (admin
edits go through candidate.update). Login is editable — the existing
authKey survives a login change (token is independent of login).
Password / authKey / currentStageId / completedAt are not touched here.
     */
    updateProfile(params: ICandidateUpdateProfileParams): Promise<ICandidate> {
      return send('candidate.UpdateProfile', params)
    }
  },
  dashboard: {
    /**
     * Summary returns aggregated counters for the page header.
     */
    summary(): Promise<ISummary> {
      return send('dashboard.Summary')
    }
  },
  material: {
    /**
     * Add creates a material in the catalog (admin only).
     */
    add(params: IMaterialAddParams): Promise<IMaterial> {
      return send('material.Add', params)
    },
    /**
     * Delete soft-deletes a material (admin only). Existing candidateMaterials
rows remain intact for historical reporting.
     */
    delete(params: IMaterialDeleteParams): Promise<boolean> {
      return send('material.Delete', params)
    },
    /**
     * Get returns the active materials catalog ordered by order, then title.
     */
    get(params: IMaterialGetParams): Promise<Array<IMaterial>> {
      return send('material.Get', params)
    },
    /**
     * GetByID returns a single material by id.
     */
    getByID(params: IMaterialGetByIDParams): Promise<IMaterial> {
      return send('material.GetByID', params)
    },
    /**
     * GetMyProgress returns the current candidate's progress on every active
material. nil Progress = candidate has not marked the material yet.
     */
    getMyProgress(): Promise<Array<IMyMaterialProgress>> {
      return send('material.GetMyProgress')
    },
    /**
     * GetProgress returns the materials × candidates × progress matrix data.
Public read — same tier as dashboard.Summary and candidate.Get. The three
lists are read inside a single transaction so the matrix is consistent
(no orphan progress rows pointing at a soft-deleted material seen mid-read).
     */
    getProgress(): Promise<IMaterialsProgress> {
      return send('material.GetProgress')
    },
    /**
     * Score sets score/scoredAt/scoredBy/notes on a candidateMaterial (admin only,
UPSERT-style). Score must be within [1, materials.maxScore].
     */
    score(params: IMaterialScoreParams): Promise<ICandidateMaterial> {
      return send('material.Score', params)
    },
    /**
     * SetRead toggles the candidate-side readAt flag for a material. read=true is
idempotent: the original readAt is preserved on repeat calls. read=false is
rejected once the admin has scored the material.
     */
    setRead(params: IMaterialSetReadParams): Promise<ICandidateMaterial> {
      return send('material.SetRead', params)
    },
    /**
     * Unscore clears score/scoredAt/scoredBy/notes on a candidateMaterial. Returns
false if no scored row existed (idempotent).
     */
    unscore(params: IMaterialUnscoreParams): Promise<boolean> {
      return send('material.Unscore', params)
    },
    /**
     * Update edits a material (admin only). All fields from input replace the
stored values.
     */
    update(params: IMaterialUpdateParams): Promise<IMaterial> {
      return send('material.Update', params)
    }
  },
  stage: {
    /**
     * Add creates a new stage.
     */
    add(params: IStageAddParams): Promise<IStage> {
      return send('stage.Add', params)
    },
    /**
     * Delete removes a stage. Fails if any candidate has a score for it.
     */
    delete(params: IStageDeleteParams): Promise<boolean> {
      return send('stage.Delete', params)
    },
    /**
     * Get returns all enabled stages ordered by order field.
     */
    get(): Promise<Array<IStage>> {
      return send('stage.Get')
    },
    /**
     * GetByID returns a stage by ID.
     */
    getByID(params: IStageGetByIDParams): Promise<IStage> {
      return send('stage.GetByID', params)
    },
    /**
     * Reorder accepts an ordered list of stage ids and re-numbers order to match.
All enabled stages must be present, no duplicates allowed.
     */
    reorder(params: IStageReorderParams): Promise<Array<IStage>> {
      return send('stage.Reorder', params)
    },
    /**
     * Update changes a stage. To reorder use Reorder.
     */
    update(params: IStageUpdateParams): Promise<boolean> {
      return send('stage.Update', params)
    }
  }
})
