# Apprentice RPC API

Шпаргалка для фронта. Сервер — JSON-RPC 2.0 over HTTP. Три уровня доступа:
- **open** — без header'а (`auth.*`, `*.get` / `*.getById`, `dashboard.summary`, `material.getProgress`);
- **registered** — нужен любой валидный authKey (admin **или** candidate): `auth.me`, `candidate.setLink`, `candidate.setAvatarUrl`, `candidate.setReady`, `candidate.updateProfile`, `material.setRead`, `material.getMyProgress`;
- **protected** — только админский authKey: всё остальное.

## Endpoint и сервисная информация

| URL | Назначение |
|---|---|
| `POST /v1/rpc/` | Сам JSON-RPC endpoint |
| `GET  /v1/rpc/doc/` | SMDBox UI — тыкаемая документация |
| `GET  /v1/rpc/openrpc.json` | OpenRPC schema (для генераторов) |
| `GET  /v1/rpc/api.ts` | Готовый TypeScript-клиент (можно подцепить напрямую) |
| `GET  /status` | Healthcheck |

Дев-порт по умолчанию `8075`. CORS открыт `*`.

## Формат вызова

```http
POST /v1/rpc/ HTTP/1.1
Content-Type: application/json
Authorization2: <authKey>           # обязателен для всего, кроме auth.* и *.get/getById

{"jsonrpc":"2.0","method":"<namespace>.<method>","params":{...},"id":1}
```

- `method` — `<namespace>.<method>` в нижнем регистре: `stage.get`, `candidate.advance`, `auth.login`, …
- `params` — объект с **camelCase**-именами параметров (имена совпадают с сигнатурой Go-метода), либо позиционный массив. Объектная форма читается человеком — рекомендую её.
- Успех: `{"result": ..., "id": 1}`. Ошибка: `{"error": {"code": 4xx|5xx, "message": "...", "data": ...}, "id": 1}`.
- Дев-режим добавляет к ответу поле `extensions` с SQL и таймингами — это нормально, в проде не приходит.
- Любой опциональный параметр может быть пропущен или `null`.

## Авторизация

- **Получить authKey**: `auth.login` (для уже зарегистрированных), `auth.register` (минимальная регистрация: только login/password — остальные поля заполняются дефолтами), либо `auth.signUp` (полная регистрация с профилем). Самостоятельная регистрация админов в обоих случаях отключена.
- **Передавать в заголовке** `Authorization2: <authKey>` на всех protected/registered методах.
- На `protected`-методах кандидатский authKey **не принимается** (вернётся `401`).
- На `registered`-методах принимается любой валидный authKey, но действия кандидата ограничены **своими** объектами (см. `candidate.setLink`, `candidate.setAvatarUrl`, `candidate.setReady`); попытка тронуть чужой → `403 forbidden`.

| namespace.method | без auth | админ | кандидат |
|---|:---:|:---:|:---:|
| `auth.login`, `auth.register`, `auth.signUp` | ✅ | ✅ | ✅ |
| `stage.get`, `stage.getById` | ✅ | ✅ | ✅ |
| `candidate.get`, `candidate.getById` | ✅ | ✅ | ✅ |
| `dashboard.summary` | ✅ | ✅ | ✅ |
| `auth.me` | ❌ 401 | ✅ | ✅ |
| `candidate.setLink` | ❌ 401 | ✅ (любой) | ✅ (только свои → иначе 403) |
| `candidate.setAvatarUrl` | ❌ 401 | ✅ (любой) | ✅ (только свой → иначе 403) |
| `candidate.setReady` | ❌ 401 | ✅ (любой) | ✅ (только свои → иначе 403) |
| `candidate.updateProfile` | ❌ 401 | ❌ 403 (админ — через `candidate.update`) | ✅ (только свой профиль) |
| `stage.add`/`update`/`delete`/`reorder` | ❌ 401 | ✅ | ❌ 401 |
| `candidate.add`/`update`/`delete`/`advance`/`rate`/`rollback`/`kanban` | ❌ 401 | ✅ | ❌ 401 |
| `material.get`, `material.getById`, `material.getProgress` | ✅ | ✅ | ✅ |
| `material.setRead`, `material.getMyProgress` | ❌ 401 | ✅ | ✅ (только своя запись) |
| `material.add`/`update`/`delete`/`score`/`unscore` | ❌ 401 | ✅ | ❌ 401 |

## Типы данных

### Время
**Все даты — строки RFC3339** (`"2026-05-01T18:54:08+03:00"`). Никаких unix-таймстампов.
Опциональные даты — `null`.

### Stage

```ts
interface Stage {
  id: number;
  alias: string;        // slug, ^[a-z0-9.\-_]{2,64}$
  order: number;        // ≥ 1, уникален среди не-удалённых
  title: string;        // ≤ 255
  shortTitle: string;   // ≤ 64
  description: string;
  maxScore: number;     // 1..100, по умолчанию 10
  deadlineDays: number; // 0..365, по умолчанию 0; 0 = без дедлайна
}
```

`deadlineDays` используется при создании `CandidateStage`-записи: deadline = createdAt + deadlineDays суток. При обновлении этапа дедлайны уже существующих записей **не пересчитываются**.

### Candidate (для Add/Update и в ответе getById/advance)

```ts
interface Candidate {
  id: number;
  name: string;            // 1..80
  handle: string;          // 2..40, ^[a-z0-9.\-_]+$, уникален среди не-удалённых
  login: string;           // 2..40, тот же regex что handle, уникален среди не-удалённых
  city: string;            // ≤ 128
  age: number | null;      // 14..120 либо null
  bio: string;
  avatarColor: string;     // ≤ 16, например "#5b8def"
  initials: string;        // 1..3 символа
  avatarUrl: string | null;
  strengths: string[];     // до 10 шт., каждый ≤ 40
  weaknesses: string[];    // до 10 шт., каждый ≤ 40
  currentStageId: number;  // FK на Stage
  createdAt: string;       // RFC3339
  updatedAt: string;
  completedAt: string | null; // выставлен, когда оценены все этапы
}
```

> Поля `password` и `authKey` в ответах **никогда не возвращаются** — они хранятся только на сервере. Исключение — `candidate.add` (см. ниже).

### SignUpParams (только в `auth.signUp`)

```ts
interface SignUpParams {
  login: string;             // 2..40, ^[a-z0-9.\-_]+$, уникален
  password: string;          // 8..72 байт
  name: string;              // 1..80
  handle?: string | null;    // 2..40, тот же regex; null/omitted → = login
  city?: string;             // ≤ 128
  age?: number | null;       // 14..120 либо null
  bio?: string;
  avatarColor?: string;      // ≤ 16
  initials?: string | null;  // 1..3; null/omitted → первые 1-2 alphanum символа login (uppercased)
  avatarUrl?: string | null; // http(s), ≤ 2048
  strengths?: string[];      // до 10, каждый ≤ 40
  weaknesses?: string[];     // до 10, каждый ≤ 40
}
```

`currentStageId` и `completedAt` сюда не входят: первый этап выставляется автоматически (первый активный stage), `completedAt` появляется только через `candidate.advance` на последнем этапе.

### CandidateProfile (только в `candidate.updateProfile`)

```ts
interface CandidateProfile {
  login: string;             // 2..40, ^[a-z0-9.\-_]+$, уникален; меняем — старый authKey остаётся валидным
  name: string;              // 1..80
  handle: string;            // 2..40, ^[a-z0-9.\-_]+$, уникален
  city: string;              // ≤ 128
  age: number | null;        // 14..120 либо null
  bio: string;
  avatarColor: string;       // ≤ 16
  initials: string;          // 1..3
  avatarUrl: string | null;  // http(s), ≤ 2048
  strengths: string[];       // до 10, каждый ≤ 40
  weaknesses: string[];      // до 10, каждый ≤ 40
}
```

Поля `password` / `authKey` / `currentStageId` / `completedAt` / `createdAt` / `updatedAt` / `statusId` сюда не входят и через этот метод не меняются.

### CandidateWithPassword (только в ответе `candidate.add`)

```ts
interface CandidateWithPassword extends Candidate {
  password: string;        // 12-символьный URL-safe пароль, выдаётся ОДИН РАЗ
}
```

Никакой другой метод не возвращает пароль. Передайте его кандидату и не сохраняйте на стороне фронта.

### CandidateSummary — для списка и канбана

```ts
interface CandidateStageSummary {
  link: string | null;       // ссылка кандидата на текущей стадии (см. setLink)
  deadline: string | null;   // дедлайн текущей стадии (createdAt + stage.deadlineDays)
  createdAt: string;         // когда кандидат попал на текущую стадию
  isReady: boolean;          // кандидат отметил задание готовым к проверке (setReady)
  setReadyAt: string | null; // момент последнего setReady(true); null когда снят
  retries: number;           // сколько раз админ возвращал на доработку (cumulative)
}

interface CandidateSummary {
  id: number;
  name: string;
  handle: string;
  city: string;
  age: number | null;
  avatarColor: string;
  initials: string;
  avatarUrl: string | null;
  strengths: string[];
  weaknesses: string[];
  currentStage: Stage | null;
  currentCandidateStage: CandidateStageSummary | null;
  totalPoints: number;       // сумма выставленных score
  maxPoints: number;         // candidates × Σ(stages.maxScore)
  completedStages: number;   // сколько оценок проставлено
  stageCount: number;        // всего этапов в системе
  completedAt: string | null;
}
```

`currentCandidateStage` — компактная сводка по строке `candidateStages` кандидата для текущей (либо последней достигнутой, если completed) стадии. Идентификаторы сюда намеренно не входят: сама стадия идентифицируется через `currentStage`. `null` только если у кандидата нет ни одной строки в `candidateStages` (на практике после `add`/`register` всегда есть).

### CandidateDetail (= Summary + bio + history)

```ts
interface CandidateStageHistory {
  stageId: number;
  stage: Stage;
  status: "done" | "current" | "todo";
  score: number | null;        // null если этап ещё не оценён
  maxScore: number;
  scoredAt: string | null;     // null если score == null
  candidateStageId: number | null; // null только для status == "todo"
  link: string | null;         // прикреплённая ссылка, null = не прикреплена
  deadline: string | null;     // вычисленный дедлайн, null если deadlineDays = 0
  createdAt: string | null;    // когда кандидат попал на этап (null для todo)
  isReady: boolean;            // кандидат отметил задание готовым к проверке; для todo всегда false
  setReadyAt: string | null;   // момент последнего setReady(true); null если снят / для todo
  retries: number;             // сколько раз админ возвращал на доработку (cumulative); для todo всегда 0
}

interface CandidateDetail extends CandidateSummary {
  bio: string;
  history: CandidateStageHistory[]; // по одной строке на каждый этап, в порядке order
}
```

### CandidateStage — прохождение этапа кандидатом

```ts
interface CandidateStage {
  id: number;
  candidateId: number;
  stageId: number;
  link: string | null;       // ссылка на тестовое задание / артефакт
  score: number | null;      // null пока этап не оценён
  scoredAt: string | null;   // момент проставления оценки
  deadline: string | null;   // createdAt + stage.deadlineDays
  createdAt: string;         // момент попадания кандидата на этап
  isReady: boolean;          // кандидат отметил задание готовым к проверке; меняется через setReady, дефолт false
  setReadyAt: string | null; // момент последнего setReady(true); null когда снят
  retries: number;           // сколько раз админ возвращал на доработку (cumulative)
}
```

> Запись создаётся автоматически: при `candidate.add` / `auth.register` для начального этапа, при `candidate.advance` — для следующего. Уникальна по `(candidateId, stageId)`. Поля `score`/`scoredAt` всегда заполняются вместе или оба `null`.

### Material — теоретические материалы

```ts
type MaterialType = "book" | "article" | "video" | "test" | "other";

interface Material {
  id: number;
  title: string;        // ≤ 255, уникально среди не-удалённых
  type: MaterialType;
  url: string;          // http(s), ≤ 2048
  description: string;  // комментарий автора курса
  maxScore: number;     // 1..100, дефолт 10
  order: number;        // порядок в списке, уникален среди не-удалённых
  createdAt: string;    // RFC3339
  updatedAt: string;
}

interface MaterialInput {
  title: string;
  type: MaterialType;
  url: string;
  description: string;
  maxScore?: number | null; // null/omitted → дефолт 10 (или старое значение при update)
  order?: number | null;    // null/omitted → 0 (или старое значение при update)
}
```

### CandidateMaterial — прогресс кандидата по материалу

```ts
interface CandidateMaterial {
  id: number;
  candidateId: number;
  materialId: number;
  readAt: string | null;    // когда кандидат впервые отметил прочитанным
  score: number | null;     // 1..material.maxScore; null пока не оценено
  scoredAt: string | null;  // момент проставления оценки
  scoredBy: number | null;  // userId админа, поставившего оценку
  notes: string | null;     // заметка админа после личного обсуждения
  createdAt: string;
}
```

Запись создаётся **лениво** — первой попыткой `material.setRead(read=true)` или первым `material.score`. До этого пары `(candidateId, materialId)` в БД нет, и UI должен трактовать её как «не отмечен».

`readAt` фиксирует **момент первой отметки** — повторный `setRead(true)` не сдвигает timestamp. Снять отметку можно только пока админ не выставил `score`.

### CandidateBrief, MaterialsProgress, MyMaterialProgress

```ts
interface CandidateBrief {
  id: number;
  name: string;
  handle: string;
  avatarColor: string;
  initials: string;
  avatarUrl: string | null;
  currentStageId: number;
}

interface MaterialsProgress {
  materials: Material[];          // отсортированы по order, title
  candidates: CandidateBrief[];   // отсортированы по name
  progress: CandidateMaterial[];  // только реально существующие записи
}

interface MyMaterialProgress {
  material: Material;
  progress: CandidateMaterial | null; // null = ещё не отмечен
}
```

`MaterialsProgress` — это публичная «доска прогресса». Клиент сам строит матрицу `materials × candidates`, ища ячейку в `progress` по `(candidateId, materialId)`; ячейки без записи трактуются как «не отмечен».

### Прочее

```ts
interface KanbanColumn { stage: Stage | null; candidates: CandidateSummary[]; }

interface Summary {
  candidatesCount: number;
  stagesCount: number;
  totalPoints: number;
  maxPoints: number;
  averageOrder: number;   // дробное среднее по current.order
}

interface AdvanceResult { candidate: Candidate; candidateStage: CandidateStage; }

type CandidateSort = "points" | "stage" | "name";
type UserType = "admin" | "user";

interface Me {
  userId: number;          // id админа или кандидата
  login: string;
  userType: "admin" | "candidate";
}
```

## Ошибки

Сервер возвращает RFC-типичные HTTP-style коды в `error.code`. Валидационные ошибки приходят с `code: 400` и массивом полей в `error.data`:

```ts
interface FieldError {
  field: string;          // "handle", "login", "strengths" и т.п.
  error: "required" | "max" | "min" | "len" | "unique" | "format";
  constraint?: { max?: number; min?: number };
}
```

Стандартные коды по всем методам:

| code | Смысл |
|---|---|
| 400 | Validation Error / нарушение бизнес-правила (см. ниже) |
| 401 | Нет/невалидный authKey, либо кандидатский authKey на admin-методе |
| 403 | Авторизован, но запрошенный объект не принадлежит вызывающему (например, `candidate.setLink` на чужой `candidateStage`) |
| 404 | Объект не найден |
| 500 | Internal — что-то упало на бэке |

Конкретные `error.message` для бизнес-правил:

**Auth:**
- `"invalid login or password"` — credentials не совпали (так же при unknown login — без user enumeration)
- `"login is already taken"` — `auth.register` или `candidate.add` с занятым login/handle
- `"invalid userType"` — `userType` ≠ `"user"` для register, ≠ `"admin"|"user"` для login
- `"password policy violation"` — пароль короче 8 или длиннее 72 байт
- `"register requires at least one stage"` — `auth.register` без хотя бы одного активного этапа

**Stage / Candidate / CandidateStage:**
- `"stage already scored for this candidate"` — кандидат уже оценён за этот этап
- `"candidate already completed all stages"` — попытка `advance` на завершённом
- `"score out of range"` — балл вне `1..stage.maxScore`
- `"no previous stage to roll back to"` — `rollback` без оценок
- `"stage has scores, cannot delete"` — `stage.delete`, на котором уже есть `candidateStages`-записи
- `"reorder list does not match stages"` — список ID в `stage.reorder` не покрывает все этапы / есть дубли
- `"currentStageId references unknown stage"` — `candidate.add` со ссылкой на несуществующий этап
- `"alias is already taken"` / `"order is already taken"` — конфликт уникальности на стадии
- `"handle is already taken"` — конфликт уникальности handle/login кандидата
- `"candidate stage not found"` — `rate` / `setLink` с несуществующим `candidateStageId`
- `"forbidden"` — кандидат пытается изменить чужой `candidateStage` / `candidate` (`setLink`, `setAvatarUrl`)
- `"link is not a valid http(s) URL"` — `setLink` / `setAvatarUrl` с невалидной ссылкой (не http/https, без host, длиннее 2048)
- `"link is required to mark stage as ready"` — `setReady(true)` без прикреплённого `link`

**Material:**
- `"material not found"` — id отсутствует или мягко удалён
- `"title is required"` — пустой `title` в `material.add`/`material.update`
- `"title is already taken"` — конфликт уникальности `title` среди активных
- `"type must be one of book/article/video/test/other"` — `type` вне enum
- `"url is required"` — пустая или невалидная `url` (не http(s), > 2048)
- `"maxScore must be between 1 and 100"` — `maxScore` вне диапазона
- `"score out of range"` — `material.score` с `score` вне `1..material.maxScore`
- `"material is already scored, candidate cannot retract"` — кандидат пытается `setRead(false)` после того, как админ уже оценил
- `"candidate has no progress on this material"` — `setRead(false)` от кандидата, у которого нет записи по этому материалу

## Методы

### `auth` — авторизация

#### `auth.login`
`{ login: string, password: string, userType: "admin"|"user" } → string` (authKey).

Возвращает свежий 32-символьный URL-safe токен (Base64-URL без padding, 192 бита энтропии). Старый authKey пользователя инвалидируется. Без header'а.

#### `auth.register`
`{ login: string, password: string, userType: "user" } → string` (authKey).

- **Только `userType: "user"`**. Самостоятельная регистрация админов отключена. Передача `"admin"` → `400 invalid userType`.
- Создаёт нового кандидата с `login = handle = name = <login>`, `initials` — первые 1-2 буквенно-цифровых символа login (uppercased), `currentStageId` — первый активный этап. Если этапов нет → `400 register requires at least one stage`.
- `login` валидируется регулярным `^[a-z0-9.\-_]{2,40}$`. Пароль 8..72 байт.
- Конкурентные регистры одного login безопасны: один проходит, остальные → `400 login is already taken`.

#### `auth.signUp`
`{ params: SignUpParams } → string` (authKey).

- Полная регистрация кандидата с профильными полями. В отличие от `auth.register`, форма заполняет `name`, `city`, `age`, `bio`, `avatarColor`, `avatarUrl`, `strengths`, `weaknesses`; необязательные `handle` / `initials` заполняются дефолтами от `login`.
- Поля прогресса (`currentStageId`, `completedAt`) пользователь задавать не может: первый этап назначается автоматически (первый активный `stage`), запись `candidateStage` создаётся сразу.
- Те же гарантии, что и у `auth.register`: advisory-lock по `login`, валидация пароля 8..72 байт, login regex `^[a-z0-9.\-_]{2,40}$`.
- Возвращает свежий 32-символьный authKey.
- Ошибки: `400 login is already taken` / `400 handle is already taken` / `400 register requires at least one stage` / `400 password policy violation` / `400 invalid login or password` / Validation Error по полям профиля.

#### `auth.me` 👤 admin или candidate
Параметры: нет. → `Me`.

- Возвращает текущего принципала по переданному `Authorization2`-токену. Анонимам — `401`.
- `userType` — `"admin"` для админов, `"candidate"` для кандидатов (намеренно отличается от `userType: "user"` в `auth.login`/`auth.register` — здесь это сущность, не флоу авторизации).
- `userId` — id из соответствующей таблицы (`users.userId` либо `candidates.candidateId`).
- Удобно для bootstrap'а UI: фронт вызывает `auth.me` с сохранённым authKey и сразу понимает, кого показывать (админскую панель / личный кабинет кандидата).

---

### `stage` — этапы программы

#### `stage.get`
Параметры: нет. **Без auth.**
Ответ: `Stage[]`, отсортированы по `order` ASC. Удалённые (`statusId=3`) исключены.

#### `stage.getById`
`{ id: number } → Stage | error 404`. **Без auth.**

#### `stage.add` 🔒 admin
`{ stage: Stage } → Stage`.
- `id` в payload игнорируется.
- Уникальность `alias` и `order` — partial unique по не-удалённым строкам. Конфликт → `400 alias is already taken` / `order is already taken`.

#### `stage.update` 🔒 admin
`{ stage: Stage } → boolean`.
- Меняет `alias`, `title`, `shortTitle`, `description`, `maxScore`, `deadlineDays`. **`order` через этот метод не двигается** — для перестановки используй `stage.reorder`.
- Изменение `deadlineDays` влияет только на **новые** `candidateStage`-записи; уже созданные не пересчитываются.

#### `stage.delete` 🔒 admin
`{ id: number } → boolean`.
- Soft-delete (`statusId → 3`). Если есть хотя бы одна `candidateStage`-запись с этим `stageId` — вернёт `400 stage has scores, cannot delete`.
- Внутри транзакции (count + delete атомарны).

#### `stage.reorder` 🔒 admin
`{ ids: number[] } → Stage[]`.
- Принимает **полный** список ID этапов в нужном порядке.
- Длина `ids` должна совпасть с числом этапов, дубли запрещены, неизвестные ID запрещены.
- Внутри: одна транзакция под advisory-lock'ом. Двухфазное обновление с положительным offset (1_000_000+i → итоговый), чтобы не упасть на UNIQUE.
- Возвращает обновлённый список.

---

### `candidate` — кандидаты и прогресс

#### `candidate.get`
`{ sortBy: CandidateSort } → CandidateSummary[]`. **Без auth.**
- `"points"` — по `totalPoints` DESC (default, если передано неизвестное значение).
- `"stage"` — по `currentStage.order` DESC.
- `"name"` — по имени, локалезависимо для русского (collation `ru`).
- В каждом элементе есть `currentCandidateStage` — компактная сводка по `candidateStage`-записи с максимальным `stageId` (`link`/`deadline`/`createdAt`), чтобы по списку не ходить отдельно за прикреплённой ссылкой и дедлайном текущей стадии.

#### `candidate.getById`
`{ id: number } → CandidateDetail | error 404`. **Без auth.**
- В `history` строка для **каждого** этапа: `done` (с `score`/`scoredAt`/`candidateStageId`/`link`/`deadline`/`createdAt`), `current` (без score, но с `candidateStageId`/`link`/`deadline`/`createdAt`), `todo` (только `stageId`/`stage`/`maxScore`).
- Если кандидат `completed`, все строки либо `done`, либо `todo`; `current` отсутствует.

#### `candidate.add` 🔒 admin
`{ candidate: Candidate } → CandidateWithPassword`.
- `id`, `createdAt`, `updatedAt`, `completedAt` в payload игнорируются.
- Поля `login` и `handle` обязательны (regex `^[a-z0-9.\-_]{2,40}$`); уникальны среди не-удалённых.
- `currentStageId` обязателен и должен указывать на существующий этап. Обычно это первый этап.
- **Сразу создаётся пустая `candidateStage`-запись** для `currentStageId` (`score`/`scoredAt` = null, `deadline` = now + `stage.deadlineDays` дней).
- **В ответе один раз приходит `password`** — 12-символьный URL-safe токен, который надо передать кандидату вне канала. Сервер его не отдаст повторно.
- Конфликты handle/login → `400 handle is already taken`. Внутри транзакции (stage check + insert + candidateStage атомарны).

#### `candidate.update` 🔒 admin
`{ candidate: Candidate } → boolean`.
- Меняет: `name`, `handle`, `city`, `age`, `bio`, `avatarColor`, `initials`, `avatarUrl`, `strengths`, `weaknesses`.
- **Не меняет**: `currentStageId` (переходы только через `advance`/`rollback`), `login` (immutable: поле в payload игнорируется и не валидируется), `password`/`authKey` (управляются `auth.*`), `createdAt`/`completedAt`.
- Внутри транзакции.

#### `candidate.updateProfile` 👤 candidate-self only
`{ profile: CandidateProfile } → Candidate`.

Самостоятельная правка профиля кандидатом. Метод **только для self**: candidateId не принимается, целевой кандидат всегда определяется по `Authorization2`-токену. Админам этот метод недоступен (`403 forbidden`) — для редактирования любого кандидата админ использует `candidate.update`.

- **Доступ**: только candidate-authKey. Анонимам → `401`. Админский authKey → `403 forbidden`.
- Меняет: `login`, `name`, `handle`, `city`, `age`, `bio`, `avatarColor`, `initials`, `avatarUrl`, `strengths`, `weaknesses`.
- **Не меняет**: `password` (отдельный метод), `authKey`, `currentStageId`, `completedAt`, `createdAt`. `updatedAt` ставится в `now()`.
- Смена `login` **не сбрасывает существующий authKey** — токен у кандидата остаётся валидным, повторно логиниться не нужно. После смены `auth.login` принимает новый `login`.
- Уникальность `login` и `handle` пересекается с другими активными кандидатами; конфликт → `400 login is already taken` / `400 handle is already taken`.
- Возвращает обновлённый `Candidate`.

#### `candidate.delete` 🔒 admin
`{ id: number } → boolean`. Soft-delete.

#### `candidate.advance` 🔒 admin ⭐ главная операция
`{ candidateId: number, score: number } → AdvanceResult`.

Что делает атомарно (одна транзакция):
1. Находит существующую **пустую** запись `candidateStage` для `currentStageId` и проставляет ей `score`/`scoredAt`.
2. Если есть следующий этап — создаёт **пустую** `candidateStage`-запись для него (deadline = now + nextStage.deadlineDays) и двигает `currentStageId` на него.
3. Если следующего нет — выставляет `completedAt` (программа пройдена), `currentStageId` остаётся на последнем этапе.

Ограничения:
- `score` должен быть в `1..currentStage.maxScore` → иначе `400 score out of range`.
- Если запись текущего этапа уже имеет `score` (например, кандидат "вернулся" на стадию вручную) → `400 stage already scored`.
- Нельзя advance'ить завершённого → `400 already completed`.
- Если по какой-то причине пустой записи для `currentStageId` нет → `404 candidate stage not found` (нарушение инварианта; типично для ручных правок БД).

В ответе `AdvanceResult.candidateStage` — обновлённая запись с проставленным `score`/`scoredAt`. Запись для **следующего** этапа в ответе не возвращается; чтобы её получить, вызовите `candidate.getById` или прочитайте список через предстоящие методы кандидата.

#### `candidate.rate` 🔒 admin — корректировка
`{ candidateStageId: number, score: number } → CandidateStage`.
- Обновляет `score` существующей записи. Если `scoredAt` был `null`, ставит его в `now()`; если уже был — оставляет как есть.
- Стадию кандидата не двигает. Та же проверка `1..stage.maxScore`.
- `404 candidate stage not found` если запись не существует.

#### `candidate.rollback` 🔒 admin — откат
`{ candidateId: number } → Candidate`.
- Находит **последнюю записанную оценку** (max `scoredAt`) по `candidateStages` кандидата.
- Если кандидат не завершён — удаляет пустую запись текущего этапа и стирает `score`/`scoredAt` у предыдущей оценённой записи; кандидат «возвращается» на этот этап без оценки. `deadline` оставляется без изменений.
- Если кандидат завершён — снимает `completedAt` и стирает `score`/`scoredAt` у последней (она же — запись последнего этапа); пустую новую не создаём.
- Если оценок нет вообще → `400 no previous stage to roll back to`.
- Внутри транзакции.

#### `candidate.setLink` 👤 admin или candidate-self
`{ candidateStageId: number, link: string | null } → CandidateStage`.

Прикрепляет / отвязывает ссылку на тестовое задание или артефакт.

- **Доступ**: admin — на любую запись; candidate — только на свои (`cur.candidateId == ctx.candidate.id`), иначе `403 forbidden`. Анонимам — `401`.
- `link === null` или пустая/whitespace строка → запись `null` (detach).
- Иначе валидируется как `http(s)://...` URL длиной ≤ 2048 — иначе `400 link is not a valid http(s) URL`.
- Возвращает обновлённую `CandidateStage`. `404 candidate stage not found` если запись не существует.

#### `candidate.setReady` 👤 admin или candidate-self
`{ candidateStageId: number, isReady: boolean } → CandidateStage`.

Помечает CandidateStage как готовый к проверке (или снимает флаг).

- **Доступ**: admin — на любую запись; candidate — только на свои (`cur.candidateId == ctx.candidate.id`), иначе `403 forbidden`. Анонимам — `401`.
- Чтобы поставить `isReady=true`, у записи должен быть прикреплён непустой `link` (после trim) — иначе `400 link is required to mark stage as ready`.
- На `isReady=false` предусловий нет; разрешено в том числе после `rate`/`advance`.
- На `setReady(true)` пишется `setReadyAt = now`.
- На `setReady(false)` сбрасывается `setReadyAt = null`. Если вызвал **админ** и до этого `isReady` был `true` — `retries` инкрементится (+1) атомарно. Кандидат `retries` не трогает. Повторный admin-`false` поверх уже снятого флага — no-op для `retries` (идемпотентен).
- Возвращает обновлённую `CandidateStage`. `404 candidate stage not found` если запись не существует.

#### `candidate.setAvatarUrl` 👤 admin или candidate-self
`{ candidateId: number, avatarUrl: string | null } → Candidate`.

Точечно обновляет `avatarUrl` кандидата без полного `candidate.update`.

- **Доступ**: admin — на любого; candidate — только на себя (`cur.id == ctx.candidate.id`), иначе `403 forbidden`. Анонимам — `401`.
- `avatarUrl === null` или пустая/whitespace строка → поле `null` (detach).
- Иначе валидируется как `http(s)://...` URL длиной ≤ 2048 — иначе `400 link is not a valid http(s) URL`.
- Возвращает обновлённый `Candidate`. `404 candidate not found` если кандидата нет.

#### `candidate.kanban` 🔒 admin
Параметры: нет. → `KanbanColumn[]` (по одной колонке на каждый этап в порядке `order`). Кандидаты в колонке не отсортированы.

---

### `dashboard` — агрегаты для шапки

#### `dashboard.summary`
Параметры: нет. **Без auth.** → `Summary` (см. тип выше).

`maxPoints = candidatesCount × Σ(stages.maxScore)`. `averageOrder` — среднее значение `current.order` по всем кандидатам (дробное), `0` если кандидатов нет.

---

### `material` — теоретические материалы и прогресс

#### `material.get`
`{ view?: { page: number, pageSize: number } } → Material[]`. **Без auth.**
- Только активные материалы (`statusId <> 3`), отсортированы по `order` ASC, затем `title`.

#### `material.getById`
`{ id: number } → Material | error 404`. **Без auth.**

#### `material.add` 🔒 admin
`{ input: MaterialInput } → Material`.
- Валидируется `title`/`type`/`url`/`maxScore`. URL приводится к http(s) с длиной ≤ 2048.
- Конфликт уникальности `title` (или `order`, если задан) → `400 title is already taken`.
- `maxScore`/`order` опциональны; при отсутствии — дефолты 10 / 0.

#### `material.update` 🔒 admin
`{ id: number, input: MaterialInput } → Material`.
- Все поля input заменяют сохранённые. Если `maxScore`/`order` опущены — сохраняются предыдущие значения.
- `404 material not found` если материал отсутствует / уже soft-deleted.

#### `material.delete` 🔒 admin
`{ id: number } → boolean`. Soft-delete. Существующие `candidateMaterials`-записи остаются для отчётности.

#### `material.setRead` 👤 candidate-self
`{ materialId: number, read: boolean } → CandidateMaterial`.

Кандидат отмечает материал прочитанным или снимает отметку.

- **Доступ**: только candidate (`Authorization2` кандидата). Админ → `403 forbidden`. Анонимам → `401`.
- `read=true`: UPSERT — первый раз создаёт запись с `readAt=now()`; повторный вызов сохраняет старый `readAt` (момент **первой** отметки фиксируется и не сдвигается).
- `read=false`: пытается обнулить `readAt`. Если админ уже выставил `score` для этой записи — операция запрещена → `400 material is already scored, candidate cannot retract`. Если записи нет вообще — `404 candidate has no progress on this material`.
- Возвращает свежую `CandidateMaterial`.

#### `material.getProgress`
Параметры: нет. **Без auth.** → `MaterialsProgress`.
- Публичная «доска прогресса»: все активные материалы, все активные кандидаты и все существующие записи `candidateMaterials`.
- Клиент строит матрицу `materials × candidates`, ища ячейку по `(candidateId, materialId)`; ячейки без записи — «не отмечен».
- Параметров и пагинации нет — выдаёт всё. Объёмы рассчитаны на школу/курс уровня сотен материалов и десятков кандидатов.

#### `material.getMyProgress` 👤 candidate-self
Параметры: нет. → `MyMaterialProgress[]`.
- Кандидатская версия `getProgress`: все активные материалы плюс прогресс **текущего кандидата** по каждому. `progress: null` означает «ещё не отмечал».
- Анонимам и админам через этот метод не отвечаем (нужен candidate-context). Админу — используйте `material.getProgress` для общего полотна.

#### `material.score` 🔒 admin
`{ candidateId: number, materialId: number, score: number, notes?: string | null } → CandidateMaterial`.

Админ ставит оценку (после личного обсуждения).

- UPSERT: если записи `(candidateId, materialId)` ещё не было — создаст её с заполненными `score`/`scoredAt`/`scoredBy` (и `readAt=null`, что валидно — кандидат может узнать о материале от админа лично).
- `score` валидируется в диапазоне `1..material.maxScore` → иначе `400 score out of range`.
- `notes` — опциональный комментарий; пустая строка / whitespace приводится к `null`.
- `scoredBy` фиксируется как `userId` админа из контекста.
- `404` если кандидата или материала нет.

#### `material.unscore` 🔒 admin
`{ candidateId: number, materialId: number } → boolean`.
- Обнуляет `score`/`scoredAt`/`scoredBy`/`notes` для пары. Возвращает `true` если строка была оценена и сейчас сброшена; `false` если оценки и так не было (идемпотентно).
- После `unscore` кандидат снова может вызвать `setRead(false)`.

## Тонкие моменты, на которые стоит обратить внимание

- **Authorization2-заголовок**, не `Authorization` — стандартный header не используем (parity с VT).
- **Сортировка `stage.get` стабильно по `order`** — фронту не нужно ещё раз сортировать.
- **`candidate.get`** возвращает `CurrentStage = null` только если `currentStageId` указывает на удалённый/несуществующий этап — в нормальной жизни такого нет, но проверка не лишняя.
- **`history` всегда полный** — включая `todo`-этапы. Используй его и для прогресс-бара, и для списка «осталось пройти».
- **`completed`-кандидат**: `completedAt != null`, `currentStage` остаётся последним этапом, в `history` все строки `done`. На фронте проверяй `completedAt`, а не `status === "done"` для последнего этапа.
- **Инвариант `candidateStages`**: для каждого незавершённого кандидата существует **ровно одна** запись без оценки — для его `currentStageId`. Все более ранние записи кандидата имеют не-NULL `score`/`scoredAt`. Завершённый кандидат — все записи с оценками.
- **Создание `candidateStages` всегда автоматическое** — через `candidate.add` / `auth.register` (для начального этапа) и `candidate.advance` (для следующего). Прямого RPC для создания нет.
- **`deadline` фиксируется в момент попадания на этап** и не пересчитывается после — даже если admin поменяет `stage.deadlineDays` или произойдёт `rollback` обратно на этот этап.
- **Имена параметров в `params`** — те же, что в подписи метода (`candidateId`, `candidateStageId`, `sortBy`, `userType`). Передаёшь объектом — порядок неважен.
- **Партиальная уникальность**: `handle`/`login` у кандидатов и `alias`/`order` у этапов уникальны только среди не-удалённых (`statusId <> 3`). Удалив строку, можно создать новую с тем же значением.
- **Сидинг для разработки**: 5 этапов и 5 кандидатов с логинами `ivan.sokolov`, `maria.petrova`, `alex.ivanov`, `olga.novikova`, `dmitry.kuznetsov`. Пароль у всех (включая `admin`) — `12345`. Лежит в `docs/init.sql`, накатывается через `make db`.
- **TS-клиент** генерится сервером на `/v1/rpc/api.ts` — типы там автогенерированные, можно дёргать оттуда вместо ручной поддержки интерфейсов из этого файла.
- **Login возвращает свежий authKey** — старый инвалидируется. Если у фронта параллельно открыто несколько вкладок и где-то перелогин — остальные потеряют сессию. Использовать центральный store для authKey.
