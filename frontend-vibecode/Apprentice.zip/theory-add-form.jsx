/* Theory · admin form — add material. Two themes side-by-side. */

const { useState } = React;

const TYPES = [
  { id: 'book',    label: 'Книга',  glyph: '📖', color: 'oklch(0.66 0.13 30)'  },
  { id: 'article', label: 'Статья', glyph: '📰', color: 'oklch(0.66 0.13 220)' },
  { id: 'video',   label: 'Видео',  glyph: '▶',  color: 'oklch(0.66 0.13 340)' },
  { id: 'quiz',    label: 'Тест',   glyph: '✓',  color: 'oklch(0.66 0.13 160)' },
  { id: 'other',   label: 'Другое', glyph: '◆',  color: 'oklch(0.58 0.05 250)' },
];

function Field({ label, hint, children, required }) {
  return (
    <label className="ta-field">
      <div className="ta-label">
        <span>{label}{required && <em>*</em>}</span>
        {hint && <span className="ta-hint">{hint}</span>}
      </div>
      {children}
    </label>
  );
}

function TypePicker({ value, onChange }) {
  return (
    <div className="ta-types">
      {TYPES.map(t => (
        <button
          key={t.id}
          type="button"
          className={`ta-type ${value === t.id ? 'on' : ''}`}
          style={{ '--tc': t.color }}
          onClick={() => onChange(t.id)}
        >
          <span className="ta-type-glyph">{t.glyph}</span>
          <span className="ta-type-lbl">{t.label}</span>
        </button>
      ))}
    </div>
  );
}

function ScoreStepper({ value, onChange, max = 10 }) {
  return (
    <div className="ta-stepper">
      <button type="button" className="ta-step-btn" onClick={() => onChange(Math.max(1, value - 1))} aria-label="Меньше">−</button>
      <input
        type="number"
        className="ta-step-input"
        value={value}
        min={1}
        max={max}
        onChange={(e) => onChange(Math.max(1, Math.min(max, Number(e.target.value) || 1)))}
      />
      <button type="button" className="ta-step-btn" onClick={() => onChange(Math.min(max, value + 1))} aria-label="Больше">+</button>
      <div className="ta-step-dots" aria-hidden>
        {Array.from({ length: max }).map((_, i) => (
          <i key={i} className={i < value ? 'on' : ''} />
        ))}
      </div>
    </div>
  );
}

function AdminAddForm({ theme, state, setState }) {
  const t = TYPES.find(x => x.id === state.type);

  return (
    <div className="ta-frame" data-theme={theme}>
      <div className="ta-topbar">
        <div className="ta-brand">{theme === 'rpg' ? 'Apprentice ⚔' : 'Apprentice'}</div>
        <div className="ta-tabs">
          <div className="ta-tab">Доска</div>
          <div className="ta-tab on">{theme === 'rpg' ? 'Гримуар' : 'Теория'}</div>
        </div>
        <div className="ta-role">
          <span className={`ta-role-badge admin`}>{theme === 'rpg' ? 'Магистр' : 'Админ'}</span>
          <span className="ta-role-login">@admin</span>
        </div>
      </div>

      <div className="ta-page">
        <div className="ta-bread">
          <span>{theme === 'rpg' ? 'Гримуар' : 'Теория'}</span>
          <span className="ta-bread-sep">/</span>
          <span className="ta-bread-cur">{theme === 'rpg' ? 'Новая глава' : 'Новый материал'}</span>
        </div>

        <div className="ta-card">
          <div className="ta-card-head">
            <h2 className="ta-h2">{theme === 'rpg' ? 'Новая глава гримуара' : 'Новый материал'}</h2>
            <p className="ta-sub">{theme === 'rpg'
              ? 'Запиши, что ученики должны изучить, и впиши в общий перечень.'
              : 'Добавьте источник, который кандидаты должны изучить.'}
            </p>
          </div>

          <div className="ta-form">
            <Field label="Title" required>
              <input
                type="text"
                className="ta-input"
                placeholder={theme === 'rpg' ? 'Название тома или свитка' : 'Например: Effective Go'}
                value={state.title}
                onChange={(e) => setState(s => ({ ...s, title: e.target.value }))}
              />
            </Field>

            <Field label="Type" required>
              <TypePicker value={state.type} onChange={(v) => setState(s => ({ ...s, type: v }))} />
            </Field>

            <Field label="URL" required hint="Ссылка на источник">
              <div className="ta-url-wrap">
                <span className="ta-url-glyph" style={{ color: t.color }}>↗</span>
                <input
                  type="url"
                  className="ta-input"
                  placeholder="https://"
                  value={state.url}
                  onChange={(e) => setState(s => ({ ...s, url: e.target.value }))}
                />
              </div>
            </Field>

            <Field label="Description" hint="Что прочитать, на что обратить внимание">
              <textarea
                className="ta-input ta-textarea"
                rows={4}
                placeholder={theme === 'rpg'
                  ? 'Главы, на которые обратить взор. Что обсудим на следующей встрече…'
                  : 'Главы, ключевые идеи, что обсудим на встрече…'}
                value={state.description}
                onChange={(e) => setState(s => ({ ...s, description: e.target.value }))}
              />
              <div className="ta-counter">{state.description.length}/500</div>
            </Field>

            <div className="ta-row-2">
              <Field label="Max score" required hint="1–10, проставляется при оценке">
                <ScoreStepper value={state.maxScore} onChange={(v) => setState(s => ({ ...s, maxScore: v }))} />
              </Field>

              <Field label="Order" required hint="Положение в списке">
                <div className="ta-order-wrap">
                  <input
                    type="number"
                    className="ta-input ta-order"
                    value={state.order}
                    min={1}
                    onChange={(e) => setState(s => ({ ...s, order: Number(e.target.value) || 1 }))}
                  />
                  <span className="ta-order-after">из 11</span>
                </div>
              </Field>
            </div>
          </div>

          <div className="ta-actions">
            <button type="button" className="ta-btn ghost">Отмена</button>
            <button type="button" className="ta-btn primary">{theme === 'rpg' ? 'Внести в гримуар' : 'Добавить материал'}</button>
          </div>
        </div>

        <div className="ta-preview">
          <div className="ta-preview-lbl">Превью карточки</div>
          <div className="ta-mat-card" style={{ '--tc': t.color }}>
            <div className="ta-mat-eyebrow">
              <span className="ta-mat-glyph">{t.glyph}</span>
              <span>{t.label} · #{state.order}</span>
              <span className="ta-mat-score">{state.maxScore}p</span>
            </div>
            <div className="ta-mat-title">{state.title || (theme === 'rpg' ? '— Без названия —' : 'Заголовок материала')}</div>
            <div className="ta-mat-link">{state.url || 'https://'}</div>
            <div className="ta-mat-desc">{state.description || (theme === 'rpg' ? 'Описания пока нет — оставьте напутствие ученикам.' : 'Опишите материал и что нужно знать.')}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---- Canvas ---- */

function FormCanvas() {
  const [stOff, setStOff] = useState({
    title: 'Concurrency in Go',
    type: 'book',
    url: 'https://www.oreilly.com/library/view/concurrency-in-go/9781491941294/',
    description: 'Прочитать главы 3 и 4. Обсудим pipelines и cancellation patterns на личной встрече.',
    maxScore: 5,
    order: 11,
  });
  const [stRpg, setStRpg] = useState({
    title: 'Concurrency in Go',
    type: 'book',
    url: 'https://www.oreilly.com/library/view/concurrency-in-go/9781491941294/',
    description: 'Главы 3 и 4 — обязательно. Особое внимание уделить главе о судьбах горутин.',
    maxScore: 5,
    order: 11,
  });
  const [stEmpty, setStEmpty] = useState({
    title: '', type: 'article', url: '', description: '', maxScore: 3, order: 11,
  });

  return (
    <DesignCanvas title="Theory · форма добавления материала" subtitle="Поля: Title, Type, URL, Description, MaxScore, Order. Превью карточки справа.">
      <DCSection id="filled" title="Заполненная форма" subtitle="С данными — чтобы оценить плотность.">
        <DCArtboard id="off-filled" label="Official тема" width={1200} height={920}>
          <AdminAddForm theme="official" state={stOff} setState={setStOff} />
        </DCArtboard>
        <DCArtboard id="rpg-filled" label="RPG тема" width={1200} height={920}>
          <AdminAddForm theme="rpg" state={stRpg} setState={setStRpg} />
        </DCArtboard>
      </DCSection>

      <DCSection id="empty" title="Пустая форма" subtitle="Стартовое состояние — placeholders.">
        <DCArtboard id="off-empty" label="Official тема" width={1200} height={920}>
          <AdminAddForm theme="official" state={stEmpty} setState={setStEmpty} />
        </DCArtboard>
        <DCArtboard id="rpg-empty" label="RPG тема" width={1200} height={920}>
          <AdminAddForm theme="rpg" state={stEmpty} setState={setStEmpty} />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<FormCanvas />);
