/* global React, RPC, RPC_SESSION, TagEditor */
const { useState: useStateAuth, useEffect: useEffectAuth, useMemo: useMemoAuth } = React;

const AUTH_AVATAR_PALETTE = [
  '#ffffff',
  'oklch(0.85 0.10 30)',  'oklch(0.85 0.10 70)',
  'oklch(0.85 0.10 120)', 'oklch(0.85 0.10 170)',
  'oklch(0.85 0.10 220)', 'oklch(0.85 0.10 270)',
  'oklch(0.85 0.10 330)',
];

function defaultInitialsFromLogin(login) {
  const m = (login || '').match(/[a-z0-9]/gi) || [];
  return (m.slice(0, 2).join('') || '').toUpperCase();
}

function AuthModal({ onClose, onSuccess }) {
  const [mode, setMode] = useStateAuth('login');         // 'login' | 'register'
  const [step, setStep] = useStateAuth(1);                // 1 = creds, 2 = profile (register only)
  const [userType, setUserType] = useStateAuth('user');   // login: 'admin' | 'user'
  const [login, setLogin] = useStateAuth('');
  const [password, setPassword] = useStateAuth('');
  const [password2, setPassword2] = useStateAuth('');

  // step 2 fields
  const [name, setName] = useStateAuth('');
  const [handle, setHandle] = useStateAuth('');
  const [city, setCity] = useStateAuth('');
  const [age, setAge] = useStateAuth('');
  const [bio, setBio] = useStateAuth('');
  const [initials, setInitials] = useStateAuth('');
  const [avatarColor, setAvatarColor] = useStateAuth(
    AUTH_AVATAR_PALETTE[Math.floor(Math.random() * AUTH_AVATAR_PALETTE.length)]
  );
  const [avatarUrl, setAvatarUrl] = useStateAuth('');
  const [strengths, setStrengths] = useStateAuth([]);
  const [weaknesses, setWeaknesses] = useStateAuth([]);

  const [busy, setBusy] = useStateAuth(false);
  const [error, setError] = useStateAuth(null);

  useEffectAuth(() => {
    if (mode === 'register') setUserType('user');
    setPassword2('');
    setStep(1);
    setError(null);
  }, [mode]);

  const isRegister = mode === 'register';
  const loginTrimmed = login.trim();
  const loginValid = loginTrimmed.length >= 2 && /^[a-z0-9.\-_]+$/.test(loginTrimmed);
  const passwordValid = isRegister ? password.length >= 8 : password.length > 0;
  const password2Valid = !isRegister || (password2.length > 0 && password2 === password);
  const showPassword2Mismatch = isRegister && password2.length > 0 && password2 !== password;
  const showPasswordTooShort = isRegister && password.length > 0 && password.length < 8;
  const canStep1 = !busy && loginValid && passwordValid && password2Valid;

  const autoInitials = useMemoAuth(() => {
    const parts = name.trim().split(/\s+/);
    const a = parts[0] ? parts[0][0] : '';
    const b = parts[1] ? parts[1][0] : '';
    return ((a + b) || a || defaultInitialsFromLogin(login)).toUpperCase().slice(0, 3);
  }, [name, login]);

  const nameValid = name.trim().length > 0 && name.trim().length <= 80;
  const ageValid = age === '' || (Number(age) >= 14 && Number(age) <= 120);
  const handleValid = handle === '' || /^[a-z0-9.\-_]{2,40}$/.test(handle.trim());
  const avatarUrlValid = avatarUrl === '' || /^https?:\/\/\S+$/i.test(avatarUrl.trim());
  // "Show invalid" flags: only highlight a field when the user has typed something
  // (or, for required fields, after they tried to submit) AND it actually fails validation.
  const showLoginInvalid = login.length > 0 && !loginValid;
  const showNameInvalid = name.length > 0 && !nameValid;
  const showHandleInvalid = handle.length > 0 && !handleValid;
  const showAgeInvalid = age !== '' && !ageValid;
  const showAvatarUrlInvalid = avatarUrl.length > 0 && !avatarUrlValid;
  const canSubmitRegister = !busy && canStep1 && nameValid && ageValid && handleValid && avatarUrlValid;

  const submitLogin = async (e) => {
    e && e.preventDefault();
    if (busy || !canStep1) return;
    setBusy(true); setError(null);
    try {
      const session = await RPC.auth.login({ login: loginTrimmed, password, userType });
      onSuccess && onSuccess(session);
    } catch (err) {
      setError(err.message || 'Ошибка');
    } finally {
      setBusy(false);
    }
  };

  const submitSignUp = async (e) => {
    e && e.preventDefault();
    if (!canSubmitRegister) return;
    setBusy(true); setError(null);
    try {
      const params = {
        login: loginTrimmed,
        password,
        name: name.trim(),
        handle: (handle.trim().replace(/^@+/, '')) || undefined,
        city: city.trim(),
        age: age === '' ? undefined : parseInt(age, 10),
        bio,
        avatarColor,
        initials: (initials.trim() || autoInitials).slice(0, 3) || undefined,
        avatarUrl: avatarUrl.trim() || undefined,
        strengths,
        weaknesses,
      };
      const session = await RPC.auth.signUp(params);
      onSuccess && onSuccess(session);
    } catch (err) {
      setError(err.message || 'Ошибка');
    } finally {
      setBusy(false);
    }
  };

  const headerTitle = 'Golang Apprentice';
  const headerEyebrow = !isRegister ? 'Вход' : (step === 1 ? 'Регистрация · 1 из 2' : 'Регистрация · 2 из 2');
  const headerSub = !isRegister
    ? 'Войдите как ученик или администратор'
    : (step === 1
      ? 'Шаг 1 — придумайте логин и пароль. Профиль заполните на следующем шаге.'
      : 'Шаг 2 — расскажите немного о себе. Все поля кроме имени необязательные.');

  return (
    <>
      <div className="scrim open" onClick={() => !busy && onClose && onClose()} />
      <div className={`modal auth-modal ${isRegister && step === 2 ? 'wide' : ''}`} role="dialog" aria-modal="true">
        <div className="modal-eyebrow">{headerEyebrow}</div>
        <div className="modal-title">{headerTitle}</div>
        <div className="modal-sub">{headerSub}</div>

        <div className="auth-tabs" role="tablist">
          <button
            type="button"
            role="tab"
            className={mode === 'login' ? 'on' : ''}
            onClick={() => setMode('login')}
            disabled={busy}
          >Войти</button>
          <button
            type="button"
            role="tab"
            className={mode === 'register' ? 'on' : ''}
            onClick={() => setMode('register')}
            disabled={busy}
          >Регистрация</button>
        </div>

        {/* ---------------- LOGIN ---------------- */}
        {!isRegister && (
          <form onSubmit={submitLogin} className="auth-form">
            <div className="auth-segment" role="radiogroup" aria-label="Тип пользователя">
              <button
                type="button" role="radio" aria-checked={userType === 'user'}
                className={userType === 'user' ? 'on' : ''}
                onClick={() => setUserType('user')}
              >Ученик</button>
              <button
                type="button" role="radio" aria-checked={userType === 'admin'}
                className={userType === 'admin' ? 'on' : ''}
                onClick={() => setUserType('admin')}
              >Админ</button>
            </div>

            <label className="auth-field">
              <span>Логин</span>
              <input
                type="text" value={login}
                onChange={e => setLogin(e.target.value)}
                autoComplete="username"
                required minLength={2} maxLength={40} pattern="[a-z0-9.\-_]+"
                disabled={busy} autoFocus
              />
            </label>

            <label className="auth-field">
              <span>Пароль</span>
              <input
                type="password" value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="current-password"
                required minLength={1} maxLength={72}
                disabled={busy}
              />
            </label>

            {error && <div className="rpc-error">{error}</div>}

            <div className="modal-actions">
              <button type="button" className="btn" onClick={onClose} disabled={busy}>Гостем</button>
              <button type="submit" className="btn primary" disabled={!canStep1}>
                {busy ? 'Подождите…' : 'Войти'}
              </button>
            </div>
          </form>
        )}

        {/* ---------------- REGISTER STEP 1 ---------------- */}
        {isRegister && step === 1 && (
          <form
            onSubmit={(e) => { e.preventDefault(); if (canStep1) setStep(2); }}
            className="auth-form"
          >
            <label className="auth-field">
              <span>Логин <span className="auth-hint">— только a-z, 0-9, точка, дефис, подчёркивание</span></span>
              <input
                type="text" value={login}
                onChange={e => setLogin(e.target.value.toLowerCase())}
                autoComplete="username"
                required minLength={2} maxLength={40} pattern="[a-z0-9.\-_]+"
                disabled={busy} autoFocus
                placeholder="ivan.sokolov"
                aria-invalid={showLoginInvalid || undefined}
              />
              {showLoginInvalid && (
                <span className="auth-error">Логин: 2–40 символов из латиницы, цифр, «.», «-», «_»</span>
              )}
            </label>

            <label className="auth-field">
              <span>Пароль <span className="auth-hint">— минимум 8 символов</span></span>
              <input
                type="password" value={password}
                onChange={e => setPassword(e.target.value)}
                autoComplete="new-password"
                required minLength={8} maxLength={72}
                disabled={busy}
                aria-invalid={showPasswordTooShort || undefined}
              />
              {showPasswordTooShort && (
                <span className="auth-error">Пароль должен быть не короче 8 символов</span>
              )}
            </label>

            <label className="auth-field">
              <span>Повторите пароль</span>
              <input
                type="password" value={password2}
                onChange={e => setPassword2(e.target.value)}
                autoComplete="new-password"
                required minLength={8} maxLength={72}
                disabled={busy}
                aria-invalid={showPassword2Mismatch || undefined}
              />
              {showPassword2Mismatch && (
                <span className="auth-error">Пароли не совпадают</span>
              )}
            </label>

            {error && <div className="rpc-error">{error}</div>}

            <div className="modal-actions">
              <button type="button" className="btn" onClick={onClose} disabled={busy}>Гостем</button>
              <button type="submit" className="btn primary" disabled={!canStep1}>
                Далее →
              </button>
            </div>
          </form>
        )}

        {/* ---------------- REGISTER STEP 2 ---------------- */}
        {isRegister && step === 2 && (
          <form onSubmit={submitSignUp} className="auth-form">
            <div className="add-row two">
              <label className="auth-field">
                <span>Имя <span className="auth-hint">· обязательно</span></span>
                <input
                  type="text" value={name}
                  onChange={e => setName(e.target.value)}
                  required maxLength={80} disabled={busy} autoFocus
                  placeholder="Иван Соколов"
                  aria-invalid={showNameInvalid || undefined}
                />
                {showNameInvalid && (
                  <span className="auth-error">Имя обязательно (до 80 символов)</span>
                )}
              </label>
              <label className="auth-field">
                <span>Handle <span className="auth-hint">· тег для канбана, без @</span></span>
                <input
                  type="text" value={handle}
                  onChange={e => setHandle(e.target.value.toLowerCase().replace(/^@+/, ''))}
                  minLength={2} maxLength={40} pattern="[a-z0-9.\-_]+"
                  disabled={busy}
                  placeholder={loginTrimmed || 'ivan.sokolov'}
                  aria-invalid={showHandleInvalid || undefined}
                />
                {showHandleInvalid && (
                  <span className="auth-error">Только латиница, цифры, «.», «-», «_» (2–40 символов)</span>
                )}
              </label>
            </div>

            <div className="add-row three">
              <label className="auth-field">
                <span>Город</span>
                <input
                  type="text" value={city}
                  onChange={e => setCity(e.target.value)}
                  maxLength={128} disabled={busy}
                />
              </label>
              <label className="auth-field">
                <span>Возраст</span>
                <input
                  type="number" value={age}
                  onChange={e => setAge(e.target.value)}
                  min={14} max={120} disabled={busy}
                  aria-invalid={showAgeInvalid || undefined}
                />
                {showAgeInvalid && (
                  <span className="auth-error">Возраст: от 14 до 120</span>
                )}
              </label>
              <label className="auth-field">
                <span>Инициалы</span>
                <input
                  type="text" value={initials}
                  onChange={e => setInitials(e.target.value.toUpperCase())}
                  maxLength={3} disabled={busy}
                  placeholder={autoInitials}
                />
              </label>
            </div>

            <div className="add-row">
              <span className="edit-label">Цвет аватарки</span>
              <div className="color-row">
                {AUTH_AVATAR_PALETTE.map(c => (
                  <button
                    key={c} type="button"
                    className={`color-dot ${avatarColor === c ? 'on' : ''}`}
                    style={{ background: c }}
                    onClick={() => setAvatarColor(c)}
                    disabled={busy}
                    aria-label="Выбрать цвет"
                  />
                ))}
              </div>
            </div>

            <label className="auth-field">
              <span>Ссылка на аватар <span className="auth-hint">· необязательно</span></span>
              <input
                type="url" value={avatarUrl}
                onChange={e => setAvatarUrl(e.target.value)}
                maxLength={2048} disabled={busy}
                placeholder="https://example.com/avatar.jpg"
                aria-invalid={showAvatarUrlInvalid || undefined}
              />
              {showAvatarUrlInvalid && (
                <span className="auth-error">Ссылка должна начинаться с http:// или https://</span>
              )}
            </label>

            <label className="auth-field">
              <span>О себе</span>
              <textarea
                className="edit-textarea" rows={3}
                value={bio}
                onChange={e => setBio(e.target.value)}
                maxLength={2000} disabled={busy}
                placeholder="Короткое био — кто вы, чем интересны"
              />
            </label>

            <div className="add-row">
              <span className="edit-label">Сильные стороны</span>
              <TagEditor value={strengths} onChange={setStrengths} disabled={busy} />
            </div>

            <div className="add-row">
              <span className="edit-label">Зоны роста</span>
              <TagEditor value={weaknesses} onChange={setWeaknesses} accent="muted" disabled={busy} />
            </div>

            {error && <div className="rpc-error">{error}</div>}

            <div className="modal-actions">
              <button type="button" className="btn" onClick={() => setStep(1)} disabled={busy}>← Назад</button>
              <button type="submit" className="btn primary" disabled={!canSubmitRegister}>
                {busy ? 'Регистрирую…' : 'Зарегистрироваться'}
              </button>
            </div>
          </form>
        )}

        {!isRegister && (
          <div className="auth-foot">
            Нет аккаунта? Зарегистрируйтесь как ученик.
          </div>
        )}
      </div>
    </>
  );
}

window.AuthModal = AuthModal;
