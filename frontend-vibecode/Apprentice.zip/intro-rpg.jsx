/* global React */
/* RPG-themed intro variant — toggled from the official Intro screen.
   Ironclad-style hooded knight, dark red battlefield, gophers with helms
   trailing fire, voiced-over subtitles synced to assets/intro-rpg.mp3. */

const { useEffect, useRef, useState } = React;

/* ------------------------------ Subtitles ------------------------------- */
/* Audio is ~18.6s; playback starts +1s after the toggle into RPG mode.
   `t` values below are relative to audio currentTime (i.e. 0 = audio start). */
const RPG_LINES = [
  { t: 0.0,  d: 3.0, text: "Наш мир тонет в говнокоде. Прод падает, дедлайны горят." },
  { t: 3.0,  d: 3.2, text: "Но ты можешь это изменить. Стать идеальным джун гофером." },
  { t: 6.2,  d: 3.4, text: "Ты будешь ошибаться. И переделывать. Учить теорию и практику." },
  { t: 9.6,  d: 3.0, text: "Писать и исправлять код раз за разом. Пока не научишься." },
  { t: 12.6, d: 4.4, text: "В конце — вкусный оффер, достойный всех твоих страданий, и долгий путь к сеньору." },
  { t: 17.0, d: 1.6, text: "Ready? Работаем!" },
];

/* ------------------------------ Knight art ------------------------------ */
/* Stylised Ironclad-esque knight, tinted gopher-helm with a Go-logo plate.
   Hand-drawn SVG so it stays crisp and can glow. */
function IroncladKnight() {
  // Soulslike full-body knight: spike-crowned bucket helm, plate armour,
  // long crimson cloak with fire kissed edges. No sword. The Go mascot
  // (small blue gopher) sits as a heraldic emblem on the breastplate.
  return (
    <svg className="rpg-knight" viewBox="0 0 520 880" aria-hidden="true">
      <defs>
        <linearGradient id="rpgSteel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#5a4438" />
          <stop offset="50%" stopColor="#2a1e18" />
          <stop offset="100%" stopColor="#100806" />
        </linearGradient>
        <linearGradient id="rpgSteelLit" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%"  stopColor="#8a6244" />
          <stop offset="60%" stopColor="#3a2418" />
          <stop offset="100%" stopColor="#1a0e08" />
        </linearGradient>
        <linearGradient id="rpgCloak" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#7a1a10" />
          <stop offset="55%" stopColor="#4a0a08" />
          <stop offset="100%" stopColor="#1a0404" />
        </linearGradient>
        <linearGradient id="rpgTabard" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#2a1410" />
          <stop offset="100%" stopColor="#0c0606" />
        </linearGradient>
        <radialGradient id="rpgVisor" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%"  stopColor="#fff2c8" />
          <stop offset="55%" stopColor="#ff7a14" />
          <stop offset="100%" stopColor="#ff3a08" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="rpgFireGlow" cx="0.5" cy="1" r="0.7">
          <stop offset="0%"  stopColor="#ffd070" stopOpacity="0.85" />
          <stop offset="50%" stopColor="#ff6a18" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#ff3a08" stopOpacity="0" />
        </radialGradient>
        <filter id="rpgKnightGlow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="4" result="b" />
          <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      {/* Aura behind the figure */}
      <ellipse cx="260" cy="780" rx="240" ry="80" fill="url(#rpgFireGlow)" />

      {/* CLOAK — back layer, sweeping wide */}
      <path d="M120,330 C70,380 30,500 40,720 C44,800 70,860 100,880 L200,880 L210,540 C200,470 200,420 230,360 Z"
            fill="url(#rpgCloak)" />
      <path d="M400,330 C450,380 490,500 480,720 C476,800 450,860 420,880 L320,880 L310,540 C320,470 320,420 290,360 Z"
            fill="url(#rpgCloak)" />
      {/* Cloak inner shadows */}
      <path d="M180,540 C170,640 170,760 190,860 L210,860 L210,540 Z" fill="#1a0606" opacity="0.7" />
      <path d="M340,540 C350,640 350,760 330,860 L310,860 L310,540 Z" fill="#1a0606" opacity="0.7" />

      {/* LEGS — armoured greaves */}
      <path d="M214,560 L212,860 L246,860 L252,560 Z" fill="url(#rpgSteel)" />
      <path d="M268,560 L274,860 L308,860 L306,560 Z" fill="url(#rpgSteel)" />
      {/* Knee plates */}
      <path d="M214,664 C228,656 244,656 252,664 L252,690 C244,696 228,696 214,690 Z" fill="url(#rpgSteelLit)" />
      <path d="M268,664 C282,656 298,656 306,664 L306,690 C298,696 282,696 268,690 Z" fill="url(#rpgSteelLit)" />
      {/* Boots — pointed sabatons */}
      <path d="M204,840 L260,840 L256,876 L196,876 Z" fill="#0c0604" />
      <path d="M260,840 L316,840 L320,876 L262,876 Z" fill="#0c0604" />

      {/* TABARD — long dark surcoat down the middle */}
      <path d="M214,360 L306,360 L320,560 C320,640 312,720 300,800 L220,800 C208,720 200,640 200,560 Z"
            fill="url(#rpgTabard)" />
      {/* Tabard belt */}
      <path d="M198,540 L322,540 L326,562 L194,562 Z" fill="#3a2418" stroke="#1a0e08" strokeWidth="1.5" />
      <circle cx="260" cy="552" r="9" fill="#5a4030" stroke="#1a0e08" strokeWidth="1.5" />
      {/* Tabard heraldic etching */}
      <g stroke="#5a1a14" strokeWidth="1.2" fill="none" opacity="0.6">
        <path d="M232,610 C236,640 248,660 260,672 C272,660 284,640 288,610" />
        <path d="M232,720 C236,740 248,760 260,772 C272,760 284,740 288,720" />
      </g>

      {/* TORSO / BREASTPLATE */}
      <path d="M170,360
               C170,330 200,310 230,308
               L290,308 C320,310 350,330 350,360
               L348,440 C346,490 330,540 322,560
               L198,560 C190,540 174,490 172,440 Z"
            fill="url(#rpgSteel)" />
      {/* Breastplate ridge */}
      <path d="M260,310 L260,556" stroke="#0a0404" strokeWidth="2" opacity="0.7" />
      {/* Breastplate lit edges */}
      <path d="M180,360 C188,420 196,490 210,540" stroke="#7a5238" strokeWidth="1.6" fill="none" opacity="0.5" />
      <path d="M340,360 C332,420 324,490 310,540" stroke="#7a5238" strokeWidth="1.6" fill="none" opacity="0.5" />

      {/* HERALDIC PLATE with blue gopher mascot — drawn AFTER breastplate so it sits on top */}
      <g transform="translate(260,440)">
        <ellipse cx="0" cy="0" rx="58" ry="64" fill="#0a0404" stroke="#7a3a18" strokeWidth="3" />
        <ellipse cx="0" cy="-2" rx="50" ry="56" fill="#f5e6c8" />
        <ellipse cx="0" cy="-2" rx="50" ry="56" fill="url(#rpgFireGlow)" opacity="0.25" />
        <g transform="translate(0,4) scale(1.35)">
          <ellipse cx="-22" cy="6" rx="5" ry="8" fill="#5dc9e2" />
          <ellipse cx="22"  cy="6" rx="5" ry="8" fill="#5dc9e2" />
          <rect x="-21" y="-12" width="42" height="34" rx="17" fill="#5dc9e2" />
          <circle cx="-12" cy="-15" r="5" fill="#5dc9e2" />
          <circle cx="12"  cy="-15" r="5" fill="#5dc9e2" />
          <circle cx="-12" cy="-15" r="2" fill="#2a7a90" />
          <circle cx="12"  cy="-15" r="2" fill="#2a7a90" />
          <circle cx="-7" cy="-3" r="4.5" fill="white" />
          <circle cx="7"  cy="-3" r="4.5" fill="white" />
          <circle cx="-6.2" cy="-2" r="1.9" fill="#0a1418" />
          <circle cx="7.8"  cy="-2" r="1.9" fill="#0a1418" />
          <ellipse cx="0" cy="6" rx="2.6" ry="1.8" fill="#0a1418" />
          <rect x="-2.5" y="7.4" width="2"   height="3.6" fill="white" />
          <rect x="0.5"  y="7.4" width="2"   height="3.6" fill="white" />
        </g>
      </g>

      {/* SHOULDERS — large pauldrons with rivets */}
      <g>
        <path d="M130,310 C130,280 160,260 195,260 C220,260 230,280 230,310 L228,360 C200,358 160,360 140,374 Z"
              fill="url(#rpgSteelLit)" />
        <path d="M390,310 C390,280 360,260 325,260 C300,260 290,280 290,310 L292,360 C320,358 360,360 380,374 Z"
              fill="url(#rpgSteelLit)" />
        {/* Rivets */}
        <g fill="#0a0404" opacity="0.85">
          <circle cx="148" cy="298" r="2.4" />
          <circle cx="170" cy="282" r="2.4" />
          <circle cx="196" cy="276" r="2.4" />
          <circle cx="220" cy="288" r="2.4" />
          <circle cx="372" cy="298" r="2.4" />
          <circle cx="350" cy="282" r="2.4" />
          <circle cx="324" cy="276" r="2.4" />
          <circle cx="300" cy="288" r="2.4" />
        </g>
      </g>

      {/* ARMS — hanging at sides, no weapons */}
      <path d="M134,372 C124,420 124,470 138,520 C150,556 168,576 184,580 L196,560 C186,556 170,540 162,510 C154,478 156,440 168,408 Z"
            fill="url(#rpgSteel)" />
      <path d="M386,372 C396,420 396,470 382,520 C370,556 352,576 336,580 L324,560 C334,556 350,540 358,510 C366,478 364,440 352,408 Z"
            fill="url(#rpgSteel)" />
      {/* Elbow plates */}
      <ellipse cx="138" cy="450" rx="14" ry="20" fill="url(#rpgSteelLit)" />
      <ellipse cx="382" cy="450" rx="14" ry="20" fill="url(#rpgSteelLit)" />
      {/* Gauntlets */}
      <g>
        <path d="M170,572 C162,584 162,604 178,612 C194,618 208,612 212,598 L208,576 Z" fill="#0c0604" />
        <path d="M350,572 C358,584 358,604 342,612 C326,618 312,612 308,598 L312,576 Z" fill="#0c0604" />
        {/* knuckle ridges */}
        <g stroke="#3a2418" strokeWidth="1.4" fill="none">
          <path d="M178,594 L208,594" />
          <path d="M312,594 L342,594" />
        </g>
      </g>

      {/* GORGET — neck plate */}
      <path d="M222,266 L298,266 L304,308 L216,308 Z" fill="url(#rpgSteelLit)" />
      <path d="M222,266 L298,266 L294,278 L226,278 Z" fill="#0a0404" opacity="0.7" />

      {/* HELMET — bucket helm with spike crown */}
      <g filter="url(#rpgKnightGlow)">
        {/* Skull / dome */}
        <path d="M210,160
                 C210,110 232,82 260,82
                 C288,82 310,110 310,160
                 L312,210
                 C312,236 304,258 290,266
                 L230,266
                 C216,258 208,236 208,210 Z"
              fill="url(#rpgSteel)" />
        {/* Brow ridge */}
        <path d="M214,170 C232,158 288,158 306,170" stroke="#0a0404" strokeWidth="2" fill="none" />
        {/* Crown of spikes */}
        <g fill="#1a0e08" stroke="#3a2418" strokeWidth="1.2">
          <path d="M222,108 L228,68 L236,108 Z" />
          <path d="M236,98  L244,52 L252,98 Z" />
          <path d="M252,90  L260,42 L268,90 Z" />
          <path d="M268,98  L276,52 L284,98 Z" />
          <path d="M284,108 L292,68 L298,108 Z" />
        </g>
        {/* Visor slit — single horizontal cut, glowing */}
        <rect x="218" y="190" width="84" height="12" rx="2" fill="#0a0404" />
        <rect x="222" y="192" width="76" height="8"  fill="url(#rpgVisor)" />
        <ellipse cx="240" cy="196" rx="6" ry="2" fill="#fff2cc" opacity="0.9" />
        <ellipse cx="282" cy="196" rx="6" ry="2" fill="#fff2cc" opacity="0.9" />

        {/* Mouth grille — vertical bars */}
        <rect x="232" y="222" width="56" height="30" rx="3" fill="#0a0404" />
        <g stroke="#3a2418" strokeWidth="1.4">
          <line x1="240" y1="226" x2="240" y2="248" />
          <line x1="248" y1="226" x2="248" y2="248" />
          <line x1="256" y1="226" x2="256" y2="248" />
          <line x1="264" y1="226" x2="264" y2="248" />
          <line x1="272" y1="226" x2="272" y2="248" />
          <line x1="280" y1="226" x2="280" y2="248" />
        </g>
        {/* Rivets around helm */}
        <g fill="#0a0404">
          <circle cx="218" cy="180" r="1.8" />
          <circle cx="302" cy="180" r="1.8" />
          <circle cx="220" cy="232" r="1.8" />
          <circle cx="300" cy="232" r="1.8" />
          <circle cx="226" cy="258" r="1.8" />
          <circle cx="294" cy="258" r="1.8" />
        </g>
      </g>

      {/* CLOAK FIRE — flame licks along the cloak edges */}
      <g opacity="0.9" style={{ mixBlendMode: 'screen' }}>
        <path d="M120,360 C100,400 96,450 110,490 C118,460 136,430 150,410 C140,390 128,376 120,360 Z" fill="#ff6a18" opacity="0.55">
          <animate attributeName="opacity" values="0.4;0.75;0.4" dur="2.6s" repeatCount="indefinite" />
        </path>
        <path d="M400,360 C420,400 424,450 410,490 C402,460 384,430 370,410 C380,390 392,376 400,360 Z" fill="#ff6a18" opacity="0.55">
          <animate attributeName="opacity" values="0.55;0.85;0.55" dur="2.2s" repeatCount="indefinite" />
        </path>
        <path d="M90,560 C82,600 80,640 96,670 C100,640 116,610 130,590 C112,580 100,572 90,560 Z" fill="#ffa040" opacity="0.6">
          <animate attributeName="opacity" values="0.45;0.8;0.45" dur="3.0s" repeatCount="indefinite" />
        </path>
        <path d="M430,560 C438,600 440,640 424,670 C420,640 404,610 390,590 C408,580 420,572 430,560 Z" fill="#ffa040" opacity="0.6">
          <animate attributeName="opacity" values="0.5;0.85;0.5" dur="2.8s" repeatCount="indefinite" />
        </path>
      </g>

      {/* GROUND FIRE — burning embers at his feet */}
      <g style={{ mixBlendMode: 'screen' }}>
        <ellipse cx="180" cy="852" rx="60" ry="14" fill="#ff7a18" opacity="0.55">
          <animate attributeName="opacity" values="0.35;0.7;0.35" dur="1.8s" repeatCount="indefinite" />
        </ellipse>
        <ellipse cx="340" cy="852" rx="60" ry="14" fill="#ff7a18" opacity="0.55">
          <animate attributeName="opacity" values="0.4;0.75;0.4" dur="1.6s" repeatCount="indefinite" />
        </ellipse>
        <ellipse cx="260" cy="864" rx="170" ry="16" fill="#ffb060" opacity="0.45">
          <animate attributeName="opacity" values="0.3;0.6;0.3" dur="2.4s" repeatCount="indefinite" />
        </ellipse>
      </g>
    </svg>
  );
}

/* ------------------------------ Helmed gophers ------------------------------ */
function HelmedGopherSprite() {
  // Same friendly shape as the official one, tinted RPG and crowned with a bronze helm.
  return (
    <svg viewBox="0 0 90 90" className="rpg-goph-svg" aria-hidden="true">
      <defs>
        <linearGradient id="rpgGoph" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="#7a3a1c" />
          <stop offset="100%" stopColor="#3c1608" />
        </linearGradient>
        <linearGradient id="rpgGophHelm" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#d8884a" />
          <stop offset="100%" stopColor="#7a3417" />
        </linearGradient>
      </defs>
      {/* arms */}
      <ellipse cx="14" cy="58" rx="6" ry="9" fill="url(#rpgGoph)" />
      <ellipse cx="76" cy="58" rx="6" ry="9" fill="url(#rpgGoph)" />
      {/* body */}
      <rect x="16" y="36" width="58" height="44" rx="22" fill="url(#rpgGoph)" />
      {/* feet */}
      <ellipse cx="32" cy="82" rx="7" ry="4" fill="#2a1208" />
      <ellipse cx="58" cy="82" rx="7" ry="4" fill="#2a1208" />
      {/* glowing eye slits */}
      <ellipse cx="32" cy="50" rx="5" ry="3" fill="#1a0a06" />
      <ellipse cx="58" cy="50" rx="5" ry="3" fill="#1a0a06" />
      <ellipse cx="32" cy="50" rx="3" ry="1.5" fill="#ffb845" />
      <ellipse cx="58" cy="50" rx="3" ry="1.5" fill="#ffb845" />
      {/* tiny snout */}
      <ellipse cx="45" cy="60" rx="2.5" ry="1.6" fill="#1a0a06" />

      {/* Helm — small bronze cap with ear bumps */}
      <g>
        <path d="M16,36 C16,18 32,8 45,8 C58,8 74,18 74,36 L70,40 C68,28 56,22 45,22 C34,22 22,28 20,40 Z"
              fill="url(#rpgGophHelm)" />
        <ellipse cx="24" cy="20" rx="6" ry="7" fill="url(#rpgGophHelm)" />
        <ellipse cx="66" cy="20" rx="6" ry="7" fill="url(#rpgGophHelm)" />
        {/* ridge */}
        <path d="M45,8 L45,40" stroke="#3a1810" strokeWidth="1.4" opacity="0.6" />
        {/* lantern */}
        <circle cx="45" cy="28" r="2.2" fill="#ffb845" />
      </g>
    </svg>
  );
}

function FlameTrail() {
  // Repeating soft flame puffs that fade tightly behind the gopher.
  return (
    <div className="rpg-trail" aria-hidden="true">
      {Array.from({ length: 4 }).map((_, i) => (
        <span key={i} className="rpg-trail-pip" style={{ animationDelay: `${-i * 0.13}s` }} />
      ))}
    </div>
  );
}

function HelmedGopher({ cls, flip }) {
  return (
    <div className={`rpg-goph ${cls}`} style={flip ? { transform: 'scaleX(-1)' } : undefined}>
      <FlameTrail />
      <HelmedGopherSprite />
    </div>
  );
}

/* ------------------------------ Background ------------------------------ */
/* Layered: deep red gradient + animated ember puffs + a subtle vignette. */
function RpgBackdrop() {
  return (
    <>
      <div className="rpg-bg" aria-hidden="true" />
      <div className="rpg-embers" aria-hidden="true">
        {Array.from({ length: 28 }).map((_, i) => (
          <span
            key={i}
            className="rpg-ember"
            style={{
              left: `${(i * 37) % 100}%`,
              animationDuration: `${7 + (i % 5) * 1.6}s`,
              animationDelay: `${-(i * 0.7) % 8}s`,
              opacity: 0.4 + ((i * 13) % 60) / 200,
            }}
          />
        ))}
      </div>
      <div className="rpg-vignette" aria-hidden="true" />
      <div className="rpg-firefloor" aria-hidden="true" />
    </>
  );
}

/* ------------------------------- RPG Intro ------------------------------ */
function RpgIntro({ onStart, onSwitchToOfficial, leaving, audioUrl = 'assets/intro-rpg.mp3' }) {
  const audioRef = useRef(null);
  const [audioTime, setAudioTime] = useState(-1); // -1 = haven't started yet
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    a.volume = 0.9;
    a.muted = muted;
    let timer = setTimeout(() => {
      a.play().catch(() => {/* autoplay blocked — user can hit "Начать" */});
    }, 1000);
    const onTime = () => setAudioTime(a.currentTime);
    a.addEventListener('timeupdate', onTime);
    return () => {
      clearTimeout(timer);
      a.removeEventListener('timeupdate', onTime);
      a.pause();
    };
  }, [audioUrl]);

  // Keep <audio>.muted in sync with toggle
  useEffect(() => {
    if (audioRef.current) audioRef.current.muted = muted;
  }, [muted]);

  // Pause + reset audio on leave
  useEffect(() => {
    if (leaving && audioRef.current) {
      try { audioRef.current.pause(); } catch (e) {}
    }
  }, [leaving]);

  // Accumulate every line whose start has already passed.
  // Treat the "active" (still-being-spoken) line specially so it can fade in.
  const revealedLines = RPG_LINES.filter(l => audioTime >= l.t);
  const activeIdx = revealedLines.length - 1;

  return (
    <div className={`intro intro-rpg ${leaving ? 'leaving' : ''}`} aria-hidden={leaving}>
      <RpgBackdrop />

      {/* Flying helmed gophers with fire trails */}
      <div className="rpg-sky">
        <HelmedGopher cls="rpg-goph-a" />
        <HelmedGopher cls="rpg-goph-b" flip />
        <HelmedGopher cls="rpg-goph-c" />
        <HelmedGopher cls="rpg-goph-d" flip />
        <HelmedGopher cls="rpg-goph-e" flip />
        <HelmedGopher cls="rpg-goph-f" />
      </div>

      {/* Knight portrait — sits behind the central content */}
      <div className="rpg-knight-wrap" aria-hidden="true">
        <IroncladKnight />
      </div>

      {/* Mode toggle */}
      <div className="rpg-mode" role="tablist" aria-label="Режим">
        <button role="tab" aria-selected="false" onClick={onSwitchToOfficial}>Official</button>
        <button role="tab" aria-selected="true" className="on">RPG</button>
      </div>

      {/* Mute toggle */}
      <button
        type="button"
        className="rpg-mute"
        onClick={() => setMuted(m => !m)}
        aria-label={muted ? 'Включить звук' : 'Выключить звук'}
        title={muted ? 'Включить звук' : 'Выключить звук'}
      >
        {muted ? (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M3 10v4h4l5 4V6l-5 4H3z" fill="currentColor" />
            <path d="M16 9l5 5M21 9l-5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
        ) : (
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M3 10v4h4l5 4V6l-5 4H3z" fill="currentColor" />
            <path d="M16 8c1.5 1 2.5 2.5 2.5 4s-1 3-2.5 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" />
            <path d="M19 5c2.5 1.7 4 4.2 4 7s-1.5 5.3-4 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" />
          </svg>
        )}
      </button>

      {/* Center content */}
      <div className="intro-content rpg-content">
        <h1 className="intro-title rpg-title">Golang Apprentice</h1>
        <p className="intro-sub rpg-sub">Сезон 1 · Когорта весна-лето 2026</p>

        {/* Subtitle stage */}
        <div className="rpg-subtitle" aria-live="polite">
          {revealedLines.length === 0 ? (
            <span className="rpg-sub-line rpg-sub-placeholder">&nbsp;</span>
          ) : (
            <p className="rpg-sub-stack">
              {revealedLines.map((l, i) => (
                <span
                  key={l.t}
                  className={`rpg-sub-frag ${i === activeIdx ? 'is-active' : ''}`}
                >
                  {l.text}
                  {i < revealedLines.length - 1 ? ' ' : null}
                </span>
              ))}
            </p>
          )}
        </div>

        <button className="intro-cta rpg-cta" onClick={onStart}>Начать</button>
      </div>

      <audio ref={audioRef} src={audioUrl} preload="auto" />
    </div>
  );
}

window.RpgIntro = RpgIntro;
