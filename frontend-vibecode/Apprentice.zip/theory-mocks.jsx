/* Theory tab — Variant 1 (matrix) refined.
   - Official + RPG themes
   - Self-row highlighted green for candidate
   - Faint "potential" checks on candidate's empty cells
   - Material cards open a detail drawer with full info + per-candidate stats
*/

const { useState, useMemo } = React;

/* ---------------------------------- Mock data ---------------------------------- */

const TYPES = {
  book:    { label: 'Книга',    glyph: '📖', color: 'oklch(0.66 0.13 30)'  },
  article: { label: 'Статья',   glyph: '📰', color: 'oklch(0.66 0.13 220)' },
  video:   { label: 'Видео',    glyph: '▶',  color: 'oklch(0.66 0.13 340)' },
  quiz:    { label: 'Тест',     glyph: '✓',  color: 'oklch(0.66 0.13 160)' },
  other:   { label: 'Другое',   glyph: '◆',  color: 'oklch(0.58 0.05 250)' },
};

/* Materials follow the Material DTO shape from the backend. */
const MATERIALS = [
  { id: 1,  type: 'book',    title: 'The Go Programming Language', url: 'https://www.gopl.io/',                 description: 'Базовый учебник по языку. Обязательны главы 1–6: синтаксис, типы, функции, методы, интерфейсы. Главы про concurrency можно прочитать после видео Pike.', maxScore: 5, order: 1, createdAt: '2026-03-01', updatedAt: '2026-03-01' },
  { id: 2,  type: 'article', title: 'Effective Go',                url: 'https://go.dev/doc/effective_go',       description: 'Идиомы, стиль, форматирование, обработка ошибок. Прочитать целиком, держать под рукой.', maxScore: 3, order: 2, createdAt: '2026-03-01', updatedAt: '2026-03-01' },
  { id: 3,  type: 'video',   title: 'Concurrency Patterns',        url: 'https://www.youtube.com/watch?v=f6kdp27TYZs', description: 'Доклад Роба Пайка про goroutines, channels, select. Смотреть с конспектом — будем разбирать на встрече.', maxScore: 4, order: 3, createdAt: '2026-03-01', updatedAt: '2026-03-01' },
  { id: 4,  type: 'article', title: 'Go Memory Model',             url: 'https://go.dev/ref/mem',                description: 'Что гарантирует язык про порядок операций между горутинами. Сложно — читать после Concurrency Patterns.', maxScore: 3, order: 4, createdAt: '2026-03-05', updatedAt: '2026-03-05' },
  { id: 5,  type: 'quiz',    title: 'Базовый синтаксис: квиз',     url: 'https://forms.example/go-basics',       description: '20 вопросов на синтаксис, типы и базовые конструкции. Проходной балл 80%. Можно перепроходить.', maxScore: 5, order: 5, createdAt: '2026-03-08', updatedAt: '2026-03-08' },
  { id: 6,  type: 'video',   title: 'Understanding Channels',      url: 'https://www.youtube.com/watch?v=KBZlN0izeiY', description: 'Kavya Joshi: как устроены каналы изнутри (hchan, sudog, очереди). Полезно после Pike.', maxScore: 4, order: 6, createdAt: '2026-03-10', updatedAt: '2026-03-10' },
  { id: 7,  type: 'book',    title: '100 Go Mistakes',             url: 'https://100go.co/',                     description: 'Teiva Harsanyi. Главы 1-4 (общее) и 9 (concurrency). Остальное — по желанию.', maxScore: 5, order: 7, createdAt: '2026-03-12', updatedAt: '2026-03-12' },
  { id: 8,  type: 'article', title: 'Context package',             url: 'https://go.dev/blog/context',           description: 'Sameer Ajmani. Зачем нужен context, как его прокидывать, что делать с отменой и таймаутами.', maxScore: 3, order: 8, createdAt: '2026-03-15', updatedAt: '2026-03-15' },
  { id: 9,  type: 'other',   title: 'Tour of Go',                  url: 'https://tour.golang.org/',              description: 'Интерактивный тур по языку. Пройти полностью, включая упражнения. Хорошее повторение перед квизом.', maxScore: 4, order: 9, createdAt: '2026-03-18', updatedAt: '2026-03-18' },
  { id: 10, type: 'quiz',    title: 'Concurrency: квиз',           url: 'https://forms.example/go-concurrency',  description: '15 вопросов про goroutines, channels, sync. Проходной 80%.', maxScore: 5, order: 10, createdAt: '2026-03-20', updatedAt: '2026-03-20' },
];

const CANDIDATES = [
  { id: 1, name: 'Анна Соколова',    handle: 'anna',   initials: 'АС', color: 'oklch(0.78 0.12 30)'  },
  { id: 2, name: 'Дмитрий Волков',   handle: 'dmitry', initials: 'ДВ', color: 'oklch(0.78 0.12 220)' },
  { id: 3, name: 'Мария Петрова',    handle: 'maria',  initials: 'МП', color: 'oklch(0.78 0.12 160)' },
  { id: 4, name: 'Иван Кузнецов',    handle: 'ivan',   initials: 'ИК', color: 'oklch(0.78 0.12 340)' },
  { id: 5, name: 'Елена Никитина',   handle: 'elena',  initials: 'ЕН', color: 'oklch(0.78 0.12 70)'  },
  { id: 6, name: 'Артём Орлов',      handle: 'artem',  initials: 'АО', color: 'oklch(0.78 0.12 280)' },
];

const PROGRESS = {
  1: { 1: { read: true, readAt: '2026-04-12', score: 5 }, 2: { read: true, readAt: '2026-04-15', score: 3 }, 3: { read: true, readAt: '2026-04-20', score: 4 }, 4: { read: true, readAt: '2026-04-22' }, 5: { read: true, readAt: '2026-04-25', score: 5 }, 6: { read: true, readAt: '2026-04-28' }, 8: { read: true, readAt: '2026-05-01' } },
  2: { 1: { read: true, readAt: '2026-04-10', score: 4 }, 2: { read: true, readAt: '2026-04-14', score: 3 }, 3: { read: true, readAt: '2026-04-19', score: 3 }, 5: { read: true, readAt: '2026-04-24', score: 4 } },
  3: { 1: { read: true, readAt: '2026-04-15', score: 5 }, 2: { read: true, readAt: '2026-04-18', score: 3 }, 3: { read: true, readAt: '2026-04-22', score: 4 }, 4: { read: true, readAt: '2026-04-25', score: 3 }, 5: { read: true, readAt: '2026-04-28', score: 5 }, 6: { read: true, readAt: '2026-05-01', score: 4 }, 7: { read: true, readAt: '2026-05-02' }, 8: { read: true, readAt: '2026-05-03' }, 9: { read: true, readAt: '2026-05-03' } },
  4: { 1: { read: true, readAt: '2026-04-20', score: 3 }, 2: { read: true, readAt: '2026-04-23' } },
  5: { 1: { read: true, readAt: '2026-04-08', score: 5 }, 2: { read: true, readAt: '2026-04-11', score: 3 }, 3: { read: true, readAt: '2026-04-15', score: 4 }, 4: { read: true, readAt: '2026-04-18', score: 3 }, 5: { read: true, readAt: '2026-04-20', score: 5 } },
  6: {},
};

/* "Anna" (id=1) is the logged-in candidate in candidate role */
const SELF_ID = 1;

const cellState = (cid, mid) => {
  const r = PROGRESS[cid] && PROGRESS[cid][mid];
  if (!r || !r.read) return 'empty';
  if (r.score == null) return 'pending';
  return 'verified';
};

const candProgress = (cid) => {
  let read = 0, verified = 0;
  MATERIALS.forEach(m => {
    const r = PROGRESS[cid] && PROGRESS[cid][m.id];
    if (r && r.read) read++;
    if (r && r.score != null) verified++;
  });
  return { read, verified, total: MATERIALS.length };
};

const itemProgress = (mid) => {
  let read = 0, verified = 0;
  CANDIDATES.forEach(c => {
    const r = PROGRESS[c.id] && PROGRESS[c.id][mid];
    if (r && r.read) read++;
    if (r && r.score != null) verified++;
  });
  return { read, verified, total: CANDIDATES.length };
};

/* ---------------------------------- Shared bits ---------------------------------- */

function MockTab({ active }) {
  return (
    <div className="tm-tabs">
      <div className={`tm-tab ${active === 'board' ? 'on' : ''}`}>Доска</div>
      <div className={`tm-tab ${active === 'theory' ? 'on' : ''}`}>Теория</div>
    </div>
  );
}

function ProgressPill({ read, total, verified }) {
  const pct = total ? Math.round(read / total * 100) : 0;
  const vpct = total ? Math.round(verified / total * 100) : 0;
  return (
    <div className="tm-pp" title={`${verified} проверено из ${read} прочитанных`}>
      <div className="tm-pp-bar">
        <div className="tm-pp-fill" style={{ width: pct + '%' }}></div>
        {verified > 0 && <div className="tm-pp-fill verified" style={{ width: vpct + '%' }}></div>}
      </div>
      <div className="tm-pp-text">
        <span className="tm-pp-num">{read}<span className="tm-pp-den">/{total}</span></span>
        <span className="tm-pp-pct">{pct}%</span>
      </div>
    </div>
  );
}

function Avatar({ c, size = 28 }) {
  return (
    <div className="tm-av" style={{ width: size, height: size, background: c.color, fontSize: size * 0.36 }}>
      {c.initials}
    </div>
  );
}

/* ----- Material detail drawer ----- */

function MaterialDrawer({ material, role, onClose }) {
  if (!material) return null;
  const ip = itemProgress(material.id);
  const t = TYPES[material.type];
  const pct = ip.total ? Math.round(ip.read / ip.total * 100) : 0;

  // sort: verified first, then pending, then empty
  const ordered = [...CANDIDATES].map(c => {
    const r = (PROGRESS[c.id] && PROGRESS[c.id][material.id]) || {};
    return { c, r, st: cellState(c.id, material.id) };
  }).sort((a, b) => {
    const w = { verified: 0, pending: 1, empty: 2 };
    return w[a.st] - w[b.st];
  });

  return (
    <div className="tm-drawer-scrim" onClick={onClose}>
      <aside className="tm-drawer" onClick={(e) => e.stopPropagation()}>
        <button className="tm-drawer-close" onClick={onClose} aria-label="Закрыть">×</button>

        <div className="tm-drawer-eyebrow" style={{ '--type-color': t.color }}>
          <span className="tm-drawer-glyph">{t.glyph}</span>
          <span>{t.label}</span>
          <span className="tm-drawer-id">#{material.id}</span>
        </div>
        <h2 className="tm-drawer-title">{material.title}</h2>
        <a className="tm-drawer-link" href={material.url} target="_blank" rel="noreferrer">{material.url} ↗</a>

        <p className="tm-drawer-desc">{material.description}</p>

        <div className="tm-drawer-stats">
          <div className="tm-stat">
            <div className="tm-stat-label">Прочитали</div>
            <div className="tm-stat-value">{ip.read}<span className="tm-stat-den">/{ip.total}</span></div>
          </div>
          <div className="tm-stat">
            <div className="tm-stat-label">Зачтено</div>
            <div className="tm-stat-value">{ip.verified}<span className="tm-stat-den">/{ip.total}</span></div>
          </div>
          <div className="tm-stat">
            <div className="tm-stat-label">Доля</div>
            <div className="tm-stat-value">{pct}<span className="tm-stat-den">%</span></div>
          </div>
          <div className="tm-stat">
            <div className="tm-stat-label">Макс. балл</div>
            <div className="tm-stat-value">{material.maxScore}</div>
          </div>
        </div>

        <div className="tm-drawer-section">По кандидатам</div>
        <div className="tm-drawer-list">
          {ordered.map(({ c, r, st }) => (
            <div key={c.id} className={`tm-dl-row ${st} ${role === 'candidate' && c.id === SELF_ID ? 'self' : ''}`}>
              <Avatar c={c} size={26} />
              <div className="tm-dl-name">{c.name}{role === 'candidate' && c.id === SELF_ID && <span className="tm-dl-mine">это вы</span>}</div>
              <div className="tm-dl-when">{r.readAt || <span className="tm-dl-empty">не открыто</span>}</div>
              <div className="tm-dl-status">
                {st === 'verified' && <span className="tm-mx-score">{r.score}<span className="tm-mx-max">/{material.maxScore}</span></span>}
                {st === 'pending'  && <span className="tm-pending-tag">ожидает</span>}
                {st === 'empty'    && <span className="tm-empty-tag">—</span>}
              </div>
              {role === 'admin' && st === 'pending' && (
                <button className="tm-dl-rate">оценить</button>
              )}
            </div>
          ))}
        </div>

        <div className="tm-drawer-meta">
          Добавлено: {material.createdAt} · Обновлено: {material.updatedAt} · Порядок: {material.order}
        </div>
      </aside>
    </div>
  );
}

/* ----- Material card (clickable header in matrix column) ----- */

function MaterialColHead({ material, onOpen }) {
  const t = TYPES[material.type];
  return (
    <button className="tm-mx-col-btn" onClick={() => onOpen(material)} style={{ '--type-color': t.color }}>
      <div className="tm-mx-glyph">{t.glyph}</div>
      <div className="tm-mx-title" title={material.title}>{material.title}</div>
    </button>
  );
}

/* ============================================================
   Matrix variant
   ============================================================ */

function MatrixVariant({ role = 'admin', theme = 'official' }) {
  const [openMaterial, setOpenMaterial] = useState(null);

  return (
    <div className={`tm-frame theme-${theme}`} data-theme={theme}>
      <div className="tm-topbar">
        <div className="tm-brand">Golang Apprentice</div>
        <MockTab active="theory" />
        <div className="tm-role">
          {role === 'admin' && <><span className="tm-role-badge admin">Админ</span><span>@admin</span></>}
          {role === 'candidate' && <><span className="tm-role-badge user">Ученик</span><span>@anna</span></>}
          {role === 'guest' && <span className="tm-role-badge guest">Гость</span>}
        </div>
      </div>

      <div className="tm-page">
        <div className="tm-page-head">
          <div>
            <h2 className="tm-h2">Теория</h2>
            <div className="tm-sub">{MATERIALS.length} материалов · {CANDIDATES.length} учеников · клик по материалу — детали</div>
          </div>
          <div className="tm-legend">
            <span><i className="dot empty"></i>не открыто</span>
            <span><i className="dot pending"></i>прочитано</span>
            <span><i className="dot verified"></i>зачтено</span>
          </div>
        </div>

        <div className="tm-matrix-wrap">
          <table className="tm-matrix">
            <thead>
              <tr>
                <th className="tm-mx-corner">Ученик</th>
                {MATERIALS.map(m => (
                  <th key={m.id} className="tm-mx-col">
                    <MaterialColHead material={m} onOpen={setOpenMaterial} />
                  </th>
                ))}
                <th className="tm-mx-progress">Прогресс</th>
              </tr>
            </thead>
            <tbody>
              {CANDIDATES.map(c => {
                const p = candProgress(c.id);
                const isSelf = role === 'candidate' && c.id === SELF_ID;
                return (
                  <tr key={c.id} className={isSelf ? 'self' : ''}>
                    <td className="tm-mx-row-head">
                      <Avatar c={c} />
                      <span>{c.name}</span>
                      {isSelf && <span className="tm-mx-mine-tag">это вы</span>}
                    </td>
                    {MATERIALS.map(m => {
                      const st = cellState(c.id, m.id);
                      const r = PROGRESS[c.id] && PROGRESS[c.id][m.id];
                      const showPotential = isSelf && st === 'empty';
                      return (
                        <td key={m.id} className={`tm-mx-cell ${st} ${showPotential ? 'potential' : ''}`}>
                          {st === 'verified' && <span className="tm-mx-score">{r.score}<span className="tm-mx-max">/{m.maxScore}</span></span>}
                          {st === 'pending'  && <span className="tm-mx-check">✓</span>}
                          {showPotential     && <span className="tm-mx-ghost">✓</span>}
                        </td>
                      );
                    })}
                    <td className="tm-mx-prog">
                      <ProgressPill read={p.read} total={p.total} verified={p.verified} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr>
                <td className="tm-mx-foot-head">Прочитали</td>
                {MATERIALS.map(m => {
                  const ip = itemProgress(m.id);
                  return (
                    <td key={m.id} className="tm-mx-foot">
                      <span className="tm-mx-foot-num">{ip.read}<span className="tm-mx-foot-den">/{ip.total}</span></span>
                    </td>
                  );
                })}
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="tm-note">
          {role === 'admin'     && 'Клик по материалу — карточка с деталями и списком кандидатов. Из неё можно проставить оценку.'}
          {role === 'candidate' && 'Ваша строка подсвечена. Серые галочки — материалы, которые вам ещё предстоит отметить.'}
          {role === 'guest'     && 'Просмотр без редактирования. Войдите, чтобы отмечать прочитанное.'}
        </div>
      </div>

      <MaterialDrawer material={openMaterial} role={role} onClose={() => setOpenMaterial(null)} />
    </div>
  );
}

/* ============================================================
   Canvas root
   ============================================================ */

function TheoryCanvas() {
  return (
    <DesignCanvas title="Вкладка «Теория» — Вариант 1 (доработанный)" subtitle="Матрица «кандидат × материал». Кликайте по карточкам теории — раскрывается детальная карточка.">
      <DCSection id="official" title="Тема: Official" subtitle="Светлая тема — как на главной доске.">
        <DCArtboard id="off-admin"     label="Админ"    width={1320} height={780}><MatrixVariant role="admin"     theme="official" /></DCArtboard>
        <DCArtboard id="off-candidate" label="Кандидат" width={1320} height={780}><MatrixVariant role="candidate" theme="official" /></DCArtboard>
        <DCArtboard id="off-guest"     label="Незарег"  width={1320} height={780}><MatrixVariant role="guest"     theme="official" /></DCArtboard>
      </DCSection>

      <DCSection id="rpg" title="Тема: RPG" subtitle="Тёмная ember-палитра — синхронно с RPG-режимом главной.">
        <DCArtboard id="rpg-admin"     label="Админ"    width={1320} height={780}><MatrixVariant role="admin"     theme="rpg" /></DCArtboard>
        <DCArtboard id="rpg-candidate" label="Кандидат" width={1320} height={780}><MatrixVariant role="candidate" theme="rpg" /></DCArtboard>
        <DCArtboard id="rpg-guest"     label="Незарег"  width={1320} height={780}><MatrixVariant role="guest"     theme="rpg" /></DCArtboard>
      </DCSection>

      <DCSection id="drawer" title="Карточка материала (drawer)" subtitle="Открывается по клику на любой материал — обложка типа, описание, ссылка, статистика, список кандидатов.">
        <DCArtboard id="drawer-admin" label="Админ — drawer открыт" width={1320} height={780}><MatrixWithOpenDrawer role="admin" theme="official" mid={1} /></DCArtboard>
        <DCArtboard id="drawer-rpg"   label="RPG — drawer открыт"   width={1320} height={780}><MatrixWithOpenDrawer role="candidate" theme="rpg" mid={3} /></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

/* same matrix but with a drawer pre-opened, for the static preview */
function MatrixWithOpenDrawer({ role, theme, mid }) {
  const [openMaterial, setOpenMaterial] = useState(MATERIALS.find(m => m.id === mid));
  return (
    <div className={`tm-frame theme-${theme}`} data-theme={theme}>
      <div className="tm-topbar">
        <div className="tm-brand">Golang Apprentice</div>
        <MockTab active="theory" />
        <div className="tm-role">
          {role === 'admin' && <><span className="tm-role-badge admin">Админ</span><span>@admin</span></>}
          {role === 'candidate' && <><span className="tm-role-badge user">Ученик</span><span>@anna</span></>}
        </div>
      </div>
      <div className="tm-page">
        <div className="tm-page-head">
          <div>
            <h2 className="tm-h2">Теория</h2>
            <div className="tm-sub">{MATERIALS.length} материалов · {CANDIDATES.length} учеников</div>
          </div>
          <div className="tm-legend">
            <span><i className="dot empty"></i>не открыто</span>
            <span><i className="dot pending"></i>прочитано</span>
            <span><i className="dot verified"></i>зачтено</span>
          </div>
        </div>
        <div className="tm-matrix-wrap dim">
          <table className="tm-matrix">
            <thead>
              <tr>
                <th className="tm-mx-corner">Ученик</th>
                {MATERIALS.map(m => (
                  <th key={m.id} className="tm-mx-col">
                    <MaterialColHead material={m} onOpen={() => {}} />
                  </th>
                ))}
                <th className="tm-mx-progress">Прогресс</th>
              </tr>
            </thead>
            <tbody>
              {CANDIDATES.map(c => {
                const p = candProgress(c.id);
                const isSelf = role === 'candidate' && c.id === SELF_ID;
                return (
                  <tr key={c.id} className={isSelf ? 'self' : ''}>
                    <td className="tm-mx-row-head">
                      <Avatar c={c} />
                      <span>{c.name}</span>
                    </td>
                    {MATERIALS.map(m => {
                      const st = cellState(c.id, m.id);
                      const r = PROGRESS[c.id] && PROGRESS[c.id][m.id];
                      const showPotential = isSelf && st === 'empty';
                      return (
                        <td key={m.id} className={`tm-mx-cell ${st} ${showPotential ? 'potential' : ''}`}>
                          {st === 'verified' && <span className="tm-mx-score">{r.score}<span className="tm-mx-max">/{m.maxScore}</span></span>}
                          {st === 'pending'  && <span className="tm-mx-check">✓</span>}
                          {showPotential     && <span className="tm-mx-ghost">✓</span>}
                        </td>
                      );
                    })}
                    <td className="tm-mx-prog">
                      <ProgressPill read={p.read} total={p.total} verified={p.verified} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      <MaterialDrawer material={openMaterial} role={role} onClose={() => setOpenMaterial(null)} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<TheoryCanvas />);
