/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard */
const { useState } = React;

const TYPES = {
  book:    { label: 'Книга',  glyph: '📖', color: 'oklch(0.66 0.13 30)'  },
  article: { label: 'Статья', glyph: '📰', color: 'oklch(0.66 0.13 220)' },
  video:   { label: 'Видео',  glyph: '▶',  color: 'oklch(0.66 0.13 340)' },
  quiz:    { label: 'Тест',   glyph: '✓',  color: 'oklch(0.66 0.13 160)' },
  other:   { label: 'Другое', glyph: '◆',  color: 'oklch(0.58 0.05 250)' },
};

const MATERIALS = [
  { id: 1,  type: 'book',    title: 'The Go Programming Language', maxScore: 5, order: 1 },
  { id: 2,  type: 'article', title: 'Effective Go', maxScore: 3, order: 2 },
  { id: 3,  type: 'video',   title: 'Concurrency Patterns', maxScore: 4, order: 3 },
  { id: 4,  type: 'article', title: 'Go Memory Model', maxScore: 3, order: 4 },
  { id: 5,  type: 'quiz',    title: 'Базовый синтаксис', maxScore: 5, order: 5 },
  { id: 6,  type: 'video',   title: 'Understanding Channels', maxScore: 4, order: 6 },
  { id: 7,  type: 'book',    title: '100 Go Mistakes and How to Avoid Them', maxScore: 5, order: 7 },
  { id: 8,  type: 'article', title: 'Context package', maxScore: 3, order: 8 },
  { id: 9,  type: 'other',   title: 'Tour of Go', maxScore: 4, order: 9 },
  { id: 10, type: 'quiz',    title: 'Concurrency: квиз после Pike + Joshi', maxScore: 5, order: 10 },
  { id: 11, type: 'article', title: 'Organizing Go Code', maxScore: 3, order: 11 },
  { id: 12, type: 'video',   title: 'What is a Goroutine, really', maxScore: 4, order: 12 },
];

const CANDIDATES = [
  { id: 1, name: 'Анна Соколова',    initials: 'АС', color: 'oklch(0.78 0.12 30)'  },
  { id: 2, name: 'Дмитрий Волков',   initials: 'ДВ', color: 'oklch(0.78 0.12 220)' },
  { id: 3, name: 'Мария Петрова',    initials: 'МП', color: 'oklch(0.78 0.12 160)' },
  { id: 4, name: 'Иван Кузнецов',    initials: 'ИК', color: 'oklch(0.78 0.12 340)' },
  { id: 5, name: 'Елена Никитина',   initials: 'ЕН', color: 'oklch(0.78 0.12 70)'  },
];

const PROGRESS = {
  1: { 1: { read: true, score: 5 }, 2: { read: true, score: 3 }, 3: { read: true, score: 4 }, 4: { read: true }, 5: { read: true, score: 5 }, 6: { read: true }, 8: { read: true }, 11: { read: true, score: 3 } },
  2: { 1: { read: true, score: 4 }, 2: { read: true, score: 3 }, 3: { read: true, score: 3 }, 5: { read: true, score: 4 }, 7: { read: true } },
  3: { 1: { read: true, score: 5 }, 2: { read: true, score: 3 }, 3: { read: true, score: 4 }, 4: { read: true, score: 3 }, 5: { read: true, score: 5 }, 6: { read: true, score: 4 }, 7: { read: true }, 8: { read: true }, 9: { read: true }, 12: { read: true } },
  4: { 1: { read: true, score: 3 }, 2: { read: true } },
  5: { 1: { read: true, score: 5 }, 2: { read: true, score: 3 }, 3: { read: true, score: 4 }, 4: { read: true, score: 3 }, 5: { read: true, score: 5 }, 10: { read: true, score: 4 } },
};

const cellState = (cid, mid) => {
  const r = PROGRESS[cid] && PROGRESS[cid][mid];
  if (!r || !r.read) return 'empty';
  if (r.score == null) return 'pending';
  return 'verified';
};
const candProgress = (cid) => {
  let read = 0, verified = 0;
  MATERIALS.forEach(m => {
    const r = PROGRESS[cid] && PROGRESS[cid][m.id];
    if (r && r.read) read++;
    if (r && r.score != null) verified++;
  });
  return { read, verified, total: MATERIALS.length };
};
const matProgress = (mid) => {
  let read = 0;
  CANDIDATES.forEach(c => {
    const r = PROGRESS[c.id] && PROGRESS[c.id][mid];
    if (r && r.read) read++;
  });
  return { read, total: CANDIDATES.length };
};

function Avatar({ c, size = 28 }) {
  return <div className="tm-av" style={{ width: size, height: size, background: c.color, fontSize: size * 0.36 }}>{c.initials}</div>;
}
function ProgressPill({ read, total, verified }) {
  const pct = Math.round(read / total * 100);
  return (
    <div className="tm-pp">
      <div className="tm-pp-bar">
        <div className="tm-pp-fill" style={{ width: pct + '%' }}></div>
        {verified > 0 && <div className="tm-pp-fill verified" style={{ width: Math.round(verified / total * 100) + '%' }}></div>}
      </div>
      <div className="tm-pp-text">
        <span className="tm-pp-num">{read}<span className="tm-pp-den">/{total}</span></span>
        <span className="tm-pp-pct">{pct}%</span>
      </div>
    </div>
  );
}

/* ---- Matrix variant with selectable header style ----
   headerStyle: 'rotate45' | 'rotate90' | 'wrap' | 'tooltip' */
function Matrix({ headerStyle, theme = 'official', myCandidateId = 1 }) {
  return (
    <div className="tm-frame" data-theme={theme} data-header={headerStyle}>
      <div className="tm-page">
        <div className="tm-page-head">
          <div>
            <h2 className="tm-h2">{theme === 'rpg' ? 'Гримуар' : 'Теория'}</h2>
            <div className="tm-sub">{MATERIALS.length} материалов · {CANDIDATES.length} учеников</div>
          </div>
          <div className="tm-legend">
            <span><i className="dot empty"></i>не открыто</span>
            <span><i className="dot pending"></i>прочитано</span>
            <span><i className="dot verified"></i>зачтено</span>
          </div>
        </div>

        <div className="tm-matrix-wrap">
          <table className={`tm-matrix h-${headerStyle}`}>
            <thead>
              <tr>
                <th className="tm-mx-corner">Ученик</th>
                {MATERIALS.map(m => (
                  <th key={m.id} className="tm-mx-col">
                    {headerStyle === 'rotate45' && (
                      <div className="hcol-rot45">
                        <div className="hcol-rot45-inner">
                          <span className="hcol-glyph" style={{ color: TYPES[m.type].color }}>{TYPES[m.type].glyph}</span>
                          <span className="hcol-text">{m.title}</span>
                        </div>
                      </div>
                    )}
                    {headerStyle === 'rotate90' && (
                      <div className="hcol-rot90">
                        <span className="hcol-glyph" style={{ color: TYPES[m.type].color }}>{TYPES[m.type].glyph}</span>
                        <span className="hcol-text">{m.title}</span>
                      </div>
                    )}
                    {headerStyle === 'wrap' && (
                      <div className="hcol-wrap">
                        <div className="hcol-glyph" style={{ color: TYPES[m.type].color }}>{TYPES[m.type].glyph}</div>
                        <div className="hcol-text">{m.title}</div>
                      </div>
                    )}
                    {headerStyle === 'tooltip' && (
                      <div className="hcol-tip" tabIndex={0}>
                        <div className="hcol-glyph" style={{ color: TYPES[m.type].color }}>{TYPES[m.type].glyph}</div>
                        <div className="hcol-text">{m.title}</div>
                        <div className="hcol-pop">{m.title}</div>
                      </div>
                    )}
                  </th>
                ))}
                <th className="tm-mx-progress">Прогресс</th>
              </tr>
            </thead>
            <tbody>
              {CANDIDATES.map(c => {
                const p = candProgress(c.id);
                const isMine = myCandidateId === c.id;
                return (
                  <tr key={c.id} className={isMine ? 'mine' : ''}>
                    <td className="tm-mx-row-head">
                      <Avatar c={c} />
                      <span className="tm-mx-row-name">{c.name}</span>
                      {isMine && <span className="tm-mx-mine-badge">это вы</span>}
                    </td>
                    {MATERIALS.map(m => {
                      const st = cellState(c.id, m.id);
                      const r = PROGRESS[c.id] && PROGRESS[c.id][m.id];
                      const showCheckable = isMine && st === 'empty';
                      return (
                        <td key={m.id} className={`tm-mx-cell ${st} ${showCheckable ? 'checkable' : ''}`}>
                          {st === 'verified' && <span className="tm-mx-score">{r.score}<span className="tm-mx-max">/{m.maxScore}</span></span>}
                          {st === 'pending' && <span className="tm-mx-check">✓</span>}
                          {showCheckable && <span className="tm-mx-ghost">✓</span>}
                        </td>
                      );
                    })}
                    <td className="tm-mx-prog">
                      <ProgressPill read={p.read} total={p.total} verified={p.verified} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr>
                <td className="tm-mx-foot-head">Прочитали</td>
                {MATERIALS.map(m => {
                  const ip = matProgress(m.id);
                  return (
                    <td key={m.id} className="tm-mx-foot">
                      <span className="tm-mx-foot-num">{ip.read}<span className="tm-mx-foot-den">/{ip.total}</span></span>
                    </td>
                  );
                })}
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <DesignCanvas title="Theory v3 — варианты заголовков матрицы" subtitle="Полные названия материалов вместо обрезки. Сравните 4 подхода в обеих темах.">
      <DCSection id="official" title="Стандартная тема" subtitle="То же содержимое — разные способы показать длинные названия.">
        <DCArtboard id="off-rot45"   label="A · Поворот 45°"      width={1320} height={620}><Matrix headerStyle="rotate45" theme="official" /></DCArtboard>
        <DCArtboard id="off-rot90"   label="B · Вертикально 90°"  width={1320} height={620}><Matrix headerStyle="rotate90" theme="official" /></DCArtboard>
        <DCArtboard id="off-wrap"    label="C · Перенос строк"    width={1320} height={520}><Matrix headerStyle="wrap"     theme="official" /></DCArtboard>
        <DCArtboard id="off-tooltip" label="D · Hover-tooltip"    width={1320} height={520}><Matrix headerStyle="tooltip"  theme="official" /></DCArtboard>
      </DCSection>
      <DCSection id="rpg" title="RPG тема" subtitle="Те же варианты в тёмной палитре.">
        <DCArtboard id="rpg-rot45"   label="A · Поворот 45°"      width={1320} height={620}><Matrix headerStyle="rotate45" theme="rpg" /></DCArtboard>
        <DCArtboard id="rpg-rot90"   label="B · Вертикально 90°"  width={1320} height={620}><Matrix headerStyle="rotate90" theme="rpg" /></DCArtboard>
        <DCArtboard id="rpg-wrap"    label="C · Перенос строк"    width={1320} height={520}><Matrix headerStyle="wrap"     theme="rpg" /></DCArtboard>
        <DCArtboard id="rpg-tooltip" label="D · Hover-tooltip"    width={1320} height={520}><Matrix headerStyle="tooltip"  theme="rpg" /></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
