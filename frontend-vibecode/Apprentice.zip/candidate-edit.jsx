/* global React, RPC */
const { useState: useStateE, useEffect: useEffectE, useRef: useRefE, useMemo: useMemoE } = React;

/* ------------------------------- TagEditor ------------------------------- */
/* Chip list with × on each + input that accepts Enter / comma to add. */
function TagEditor({ value, onChange, placeholder, accent, max = 10, maxLen = 40, disabled }) {
  const [draft, setDraft] = useStateE('');
  const inputRef = useRefE(null);

  const commit = () => {
    const t = draft.trim().replace(/^,+|,+$/g, '').trim();
    if (!t) return;
    if (value.includes(t)) { setDraft(''); return; }
    if (value.length >= max) return;
    if (t.length > maxLen) return;
    onChange([...value, t]);
    setDraft('');
  };

  const remove = (i) => {
    const next = value.slice();
    next.splice(i, 1);
    onChange(next);
  };

  const onKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      commit();
    } else if (e.key === 'Backspace' && draft === '' && value.length > 0) {
      remove(value.length - 1);
    }
  };

  return (
    <div className={`tag-editor ${disabled ? 'is-disabled' : ''}`} onClick={() => inputRef.current && inputRef.current.focus()}>
      {value.map((t, i) => (
        <span key={i} className={`tag-chip ${accent === 'muted' ? 'muted' : ''}`}>
          {t}
          <button
            type="button"
            className="tag-x"
            aria-label={`Удалить ${t}`}
            onClick={(e) => { e.stopPropagation(); remove(i); }}
            disabled={disabled}
          >
            <svg width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">
              <path d="M2 2l6 6M8 2l-6 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
            </svg>
          </button>
        </span>
      ))}
      <input
        ref={inputRef}
        className="tag-input"
        type="text"
        value={draft}
        placeholder={value.length === 0 ? (placeholder || 'Добавить…') : ''}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={onKeyDown}
        onBlur={commit}
        disabled={disabled || value.length >= max}
        maxLength={maxLen}
      />
    </div>
  );
}

/* ------------------------------ Drawer Edit ------------------------------ */
/* In-place form for bio / strengths / weaknesses inside the drawer.       */
function DrawerEditForm({ detail, mode, onCancel, onSaved }) {
  const isSelf = mode === 'self';
  const [name, setName] = useStateE(detail.name || '');
  const [handle, setHandle] = useStateE(detail.handle || '');
  const [city, setCity] = useStateE(detail.city || '');
  const [age, setAge] = useStateE(detail.age == null ? '' : String(detail.age));
  const [bio, setBio] = useStateE(detail.bio || '');
  const [strengths, setStrengths] = useStateE(detail.strengths || []);
  const [weaknesses, setWeaknesses] = useStateE(detail.weaknesses || []);
  const [busy, setBusy] = useStateE(false);
  const [error, setError] = useStateE(null);

  const initialAge = detail.age == null ? '' : String(detail.age);
  const dirty =
    name !== (detail.name || '') ||
    handle !== (detail.handle || '') ||
    city !== (detail.city || '') ||
    age !== initialAge ||
    bio !== (detail.bio || '') ||
    JSON.stringify(strengths) !== JSON.stringify(detail.strengths || []) ||
    JSON.stringify(weaknesses) !== JSON.stringify(detail.weaknesses || []);

  const nameValid = name.trim().length > 0 && name.trim().length <= 80;
  const handleValid = /^[a-z0-9.\-_]{2,40}$/.test(handle.trim());
  const ageValid = age === '' || (Number(age) >= 14 && Number(age) <= 120);
  const canSave = !busy && dirty && nameValid && handleValid && ageValid;

  const save = async () => {
    if (!canSave) return;
    setBusy(true); setError(null);
    try {
      const ageVal = age === '' ? undefined : parseInt(age, 10);
      if (isSelf) {
        // candidate.UpdateProfile — самостоятельная правка профиля кандидатом.
        const profile = {
          login: detail.login || '',  // login is editable here, but we don't expose it in this form
          name: name.trim(),
          handle: handle.trim(),
          city: city.trim(),
          age: ageVal,
          bio,
          avatarColor: detail.avatarColor,
          initials: detail.initials,
          avatarUrl: detail.avatarUrl,
          strengths,
          weaknesses,
        };
        await RPC.candidate.updateProfile({ profile });
      } else {
        const stageId = detail.currentStage ? detail.currentStage.id : detail.currentStageId;
        const payload = {
          id: detail.id,
          name: name.trim(),
          handle: handle.trim(),
          login: '',
          city: city.trim(),
          age: ageVal,
          bio,
          avatarColor: detail.avatarColor,
          initials: detail.initials,
          avatarUrl: detail.avatarUrl,
          strengths,
          weaknesses,
          currentStageId: stageId,
          createdAt: detail.createdAt || '',
          updatedAt: detail.updatedAt || '',
          completedAt: detail.completedAt,
        };
        await RPC.candidate.update({ candidate: payload });
      }
      onSaved && onSaved();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="drawer-edit">
      <div className="edit-field">
        <label className="edit-label" htmlFor="edit-name">Имя</label>
        <input
          id="edit-name"
          className="edit-input"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={80}
          disabled={busy}
        />
      </div>

      <div className="edit-row two">
        <div className="edit-field">
          <label className="edit-label" htmlFor="edit-handle">Handle (@-тег)</label>
          <input
            id="edit-handle"
            className="edit-input"
            type="text"
            value={handle}
            onChange={(e) => setHandle(e.target.value.toLowerCase())}
            minLength={2} maxLength={40}
            pattern="[a-z0-9.\-_]+"
            disabled={busy}
            placeholder="ivan.sokolov"
          />
        </div>
        <div className="edit-field">
          <label className="edit-label" htmlFor="edit-age">Возраст</label>
          <input
            id="edit-age"
            className="edit-input"
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            min={14} max={120}
            disabled={busy}
          />
        </div>
      </div>

      <div className="edit-field">
        <label className="edit-label" htmlFor="edit-city">Город</label>
        <input
          id="edit-city"
          className="edit-input"
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          maxLength={128}
          disabled={busy}
        />
      </div>

      <div className="edit-field">
        <label className="edit-label" htmlFor="edit-bio">Описание</label>
        <textarea
          id="edit-bio"
          className="edit-textarea"
          rows={4}
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          disabled={busy}
          maxLength={2000}
          placeholder="Короткое био — кто такой кандидат, чем интересен"
        />
      </div>

      <div className="edit-field">
        <span className="edit-label">Сильные стороны</span>
        <TagEditor
          value={strengths}
          onChange={setStrengths}
          placeholder="Например: Кодит на сложных алгоритмах"
          disabled={busy}
        />
        <div className="edit-hint">{strengths.length}/10 · до 40 символов</div>
      </div>

      <div className="edit-field">
        <span className="edit-label">Зоны роста</span>
        <TagEditor
          value={weaknesses}
          onChange={setWeaknesses}
          placeholder="Например: Боится ревью"
          accent="muted"
          disabled={busy}
        />
        <div className="edit-hint">{weaknesses.length}/10 · до 40 символов</div>
      </div>

      {error && <div className="rpc-error">{error}</div>}

      <div className="edit-actions">
        <button className="btn" type="button" onClick={onCancel} disabled={busy}>Отменить</button>
        <button
          className="btn primary"
          type="button"
          onClick={save}
          disabled={!canSave}
        >{busy ? 'Сохраняю…' : 'Сохранить'}</button>
      </div>
    </div>
  );
}

/* --------------------------- Add Candidate Modal -------------------------- */
const AVATAR_PALETTE = [
  '#ffffff',
  'oklch(0.85 0.10 30)',  'oklch(0.85 0.10 70)',
  'oklch(0.85 0.10 120)', 'oklch(0.85 0.10 170)',
  'oklch(0.85 0.10 220)', 'oklch(0.85 0.10 270)',
  'oklch(0.85 0.10 330)',
];

function CandidateAddModal({ stages, onClose, onCreated }) {
  const [name, setName] = useStateE('');
  const [handle, setHandle] = useStateE('');
  const [login, setLogin] = useStateE('');
  const [city, setCity] = useStateE('');
  const [age, setAge] = useStateE('');
  const [bio, setBio] = useStateE('');
  const [initials, setInitials] = useStateE('');
  const [avatarColor, setAvatarColor] = useStateE(AVATAR_PALETTE[Math.floor(Math.random() * AVATAR_PALETTE.length)]);
  const [strengths, setStrengths] = useStateE([]);
  const [weaknesses, setWeaknesses] = useStateE([]);
  const [stageId, setStageId] = useStateE(stages[0] ? stages[0].id : 0);
  const [busy, setBusy] = useStateE(false);
  const [error, setError] = useStateE(null);
  const [createdResult, setCreatedResult] = useStateE(null); // { id, login, password, name }
  const [pwCopied, setPwCopied] = useStateE(false);

  const autoInitials = useMemoE(() => {
    const parts = name.trim().split(/\s+/);
    const a = parts[0] ? parts[0][0] : '';
    const b = parts[1] ? parts[1][0] : '';
    return ((a + b) || a || '').toUpperCase().slice(0, 2);
  }, [name]);

  const submit = async (e) => {
    e && e.preventDefault();
    setBusy(true); setError(null);
    try {
      const payload = {
        id: 0,
        name: name.trim(),
        handle: handle.trim(),
        login: login.trim(),
        city: city.trim(),
        age: age === '' ? undefined : parseInt(age, 10),
        bio,
        avatarColor,
        initials: (initials.trim() || autoInitials).slice(0, 3),
        avatarUrl: undefined,
        strengths,
        weaknesses,
        currentStageId: stageId,
        createdAt: '',
        updatedAt: '',
      };
      const created = await RPC.candidate.add({ candidate: payload });
      // Server returns CandidateWithPassword — password is shown ONCE.
      setCreatedResult(created || null);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const closeAndFinish = () => {
    if (createdResult) onCreated && onCreated(createdResult);
    else onClose && onClose();
  };

  if (createdResult) {
    return (
      <>
        <div className="scrim open" onClick={closeAndFinish} />
        <div className="modal candidate-add-modal" role="dialog" aria-modal="true">
          <div className="modal-eyebrow">Кандидат создан</div>
          <div className="modal-title">{createdResult.name}</div>
          <div className="modal-sub">
            Сохраните и передайте эти данные ученику. Пароль больше не будет показан.
          </div>

          <div className="creds-grid">
            <div className="creds-row">
              <span className="creds-label">Логин</span>
              <code className="creds-value">{createdResult.login}</code>
            </div>
            <div className="creds-row">
              <span className="creds-label">Пароль</span>
              <code className="creds-value">{createdResult.password}</code>
              <button
                type="button"
                className="btn ghost creds-copy"
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(
                      `логин: ${createdResult.login}\nпароль: ${createdResult.password}`
                    );
                    setPwCopied(true);
                    setTimeout(() => setPwCopied(false), 1500);
                  } catch {}
                }}
              >{pwCopied ? 'Скопировано' : 'Скопировать'}</button>
            </div>
          </div>

          <div className="modal-actions">
            <button type="button" className="btn primary" onClick={closeAndFinish}>Готово</button>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="scrim open" onClick={() => !busy && onClose && onClose()} />
      <div className="modal candidate-add-modal" role="dialog" aria-modal="true">
        <div className="modal-eyebrow">Новый кандидат</div>
        <div className="modal-title">Добавить ученика</div>
        <div className="modal-sub">Все поля можно поправить позже в личном кабинете</div>

        <form onSubmit={submit} className="add-form">
          <div className="add-row two">
            <label className="auth-field">
              <span>Handle</span>
              <input
                type="text"
                value={handle}
                onChange={(e) => setHandle(e.target.value.toLowerCase())}
                required minLength={2} maxLength={40}
                pattern="[a-z0-9.\-_]+"
                disabled={busy}
                placeholder="ivan.sokolov"
              />
            </label>
            <label className="auth-field">
              <span>Логин ученика</span>
              <input
                type="text"
                value={login}
                onChange={(e) => setLogin(e.target.value.toLowerCase())}
                minLength={2} maxLength={40}
                pattern="[a-z0-9.\-_]+"
                disabled={busy}
                placeholder="для входа в систему"
              />
            </label>
          </div>

          <div className="add-row two">
            <label className="auth-field">
              <span>ФИО</span>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required maxLength={80}
                disabled={busy}
              />
            </label>
          </div>

          <div className="add-row three">
            <label className="auth-field">
              <span>Город</span>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                maxLength={60}
                disabled={busy}
              />
            </label>
            <label className="auth-field">
              <span>Возраст</span>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                min={14} max={120}
                disabled={busy}
              />
            </label>
            <label className="auth-field">
              <span>Инициалы</span>
              <input
                type="text"
                value={initials}
                onChange={(e) => setInitials(e.target.value.toUpperCase())}
                maxLength={3}
                placeholder={autoInitials}
                disabled={busy}
              />
            </label>
          </div>

          <div className="add-row">
            <label className="auth-field">
              <span>Стартовый этап</span>
              <select
                value={stageId}
                onChange={(e) => setStageId(parseInt(e.target.value, 10))}
                disabled={busy}
              >
                {stages.map(s => (
                  <option key={s.id} value={s.id}>
                    {String(s.order).padStart(2, '0')} · {s.title}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="add-row">
            <span className="edit-label">Цвет аватарки</span>
            <div className="color-row">
              {AVATAR_PALETTE.map(c => (
                <button
                  key={c}
                  type="button"
                  className={`color-dot ${avatarColor === c ? 'on' : ''}`}
                  style={{ background: c }}
                  onClick={() => setAvatarColor(c)}
                  disabled={busy}
                  aria-label="Выбрать цвет"
                />
              ))}
            </div>
          </div>

          <div className="add-row">
            <label className="auth-field">
              <span>Описание</span>
              <textarea
                className="edit-textarea"
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={2000}
                disabled={busy}
                placeholder="Короткое био"
              />
            </label>
          </div>

          <div className="add-row">
            <span className="edit-label">Сильные стороны</span>
            <TagEditor value={strengths} onChange={setStrengths} disabled={busy} />
          </div>

          <div className="add-row">
            <span className="edit-label">Зоны роста</span>
            <TagEditor value={weaknesses} onChange={setWeaknesses} accent="muted" disabled={busy} />
          </div>

          {error && <div className="rpc-error">{error}</div>}

          <div className="modal-actions">
            <button type="button" className="btn" onClick={onClose} disabled={busy}>Отмена</button>
            <button type="submit" className="btn primary" disabled={busy}>
              {busy ? 'Сохраняю…' : 'Создать'}
            </button>
          </div>
        </form>
      </div>
    </>
  );
}

/* ------------------------------ Timeline item ----------------------------- */
/* Renders a single stage row in the candidate drawer's timeline.            */
/* Shows score, deadline (if any), and an inline link editor (admin only).   */
function formatDeadline(iso, history) {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(+d)) return null;
  const dateStr = d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
  // Submitted on time
  if (history && history.isReady && history.setReadyAt) {
    const sr = new Date(history.setReadyAt);
    if (!isNaN(+sr) && sr.getTime() < d.getTime()) {
      return { dateStr, rel: 'сдана в срок', overdue: false, onTime: true };
    }
  }
  const now = new Date();
  const dayMs = 24 * 60 * 60 * 1000;
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startThat = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const diffDays = Math.round((startThat - startToday) / dayMs);
  const overdue = d.getTime() < now.getTime();
  let rel;
  if (diffDays === 0) rel = 'сегодня';
  else if (diffDays === 1) rel = 'завтра';
  else if (diffDays === -1) rel = 'вчера';
  else if (diffDays > 0) rel = `через ${diffDays} дн.`;
  else rel = `${Math.abs(diffDays)} дн. назад`;
  return { dateStr, rel, overdue, onTime: false };
}

function LinkEditor({ history, canEdit, onChange }) {
  const [editing, setEditing] = useStateE(false);
  const [draft, setDraft] = useStateE(history.link || '');
  const [busy, setBusy] = useStateE(false);
  const [err, setErr] = useStateE(null);

  useEffectE(() => {
    if (!editing) setDraft(history.link || '');
  }, [history.link, editing]);

  if (!history.candidateStageId) return null; // todo stage — no row to attach link to

  const save = async () => {
    if (busy) return;
    const trimmed = draft.trim();
    setBusy(true); setErr(null);
    try {
      await RPC.candidate.setLink({
        candidateStageID: history.candidateStageId,
        link: trimmed === '' ? null : trimmed,
      });
      setEditing(false);
      onChange && onChange();
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  const detach = async () => {
    if (busy) return;
    setBusy(true); setErr(null);
    try {
      await RPC.candidate.setLink({ candidateStageID: history.candidateStageId, link: null });
      setDraft('');
      setEditing(false);
      onChange && onChange();
    } catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  };

  // Read-only state: just show link if it exists.
  if (!editing) {
    if (history.link) {
      return (
        <div className="tl-link">
          <a href={history.link} target="_blank" rel="noopener noreferrer" className="tl-link-a">
            <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true">
              <path d="M5 7l-1.5 1.5a2.1 2.1 0 1 1-3-3L2 4M7 5l1.5-1.5a2.1 2.1 0 1 1 3 3L10 8M4.5 7.5l3-3"
                stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" fill="none"/>
            </svg>
            <span className="tl-link-url">{history.link}</span>
          </a>
          {canEdit && (
            <button type="button" className="tl-link-edit" onClick={() => setEditing(true)}>
              изменить
            </button>
          )}
        </div>
      );
    }
    if (canEdit) {
      return (
        <button type="button" className="tl-link-add" onClick={() => setEditing(true)}>
          + ссылка на работу
        </button>
      );
    }
    return null;
  }

  // Edit state.
  return (
    <div className="tl-link-edit-row">
      <input
        type="url"
        className="tl-link-input"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        placeholder="https://github.com/..."
        disabled={busy}
        autoFocus
        onKeyDown={(e) => {
          if (e.key === 'Enter') { e.preventDefault(); save(); }
          if (e.key === 'Escape') { e.preventDefault(); setEditing(false); }
        }}
      />
      <button type="button" className="btn tl-link-save" onClick={save} disabled={busy}>
        {busy ? '…' : 'OK'}
      </button>
      {history.link && (
        <button type="button" className="btn ghost tl-link-detach" onClick={detach} disabled={busy} title="Убрать ссылку">
          ×
        </button>
      )}
      <button type="button" className="btn ghost" onClick={() => setEditing(false)} disabled={busy}>
        Отмена
      </button>
      {err && <div className="rpc-error tl-link-err">{err}</div>}
    </div>
  );
}

function ReadyToggle({ history, canEdit, onChange }) {
  const [busy, setBusy] = useStateE(false);
  const [err, setErr] = useStateE(null);
  if (!history.candidateStageId) return null;
  const isReady = !!history.isReady;
  const hasLink = !!(history.link && history.link.trim());
  const disabled = busy || (!isReady && !hasLink);

  const toggle = async () => {
    if (busy) return;
    setBusy(true); setErr(null);
    try {
      await RPC.candidate.setReady({
        candidateStageID: history.candidateStageId,
        isReady: !isReady,
      });
      onChange && onChange();
    } catch (e) { setErr(e.message); }
    finally { setBusy(false); }
  };

  if (!canEdit) {
    if (!isReady) return null;
    return (
      <div className="tl-ready">
        <span className="tl-ready-chip on" title={history.setReadyAt ? `Готово с ${formatStamp(history.setReadyAt)}` : 'Готово'}>
          <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
            <path d="M2.5 6.5l2.5 2.5 4.5-5" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          готово
        </span>
      </div>
    );
  }

  return (
    <div className="tl-ready">
      <button
        type="button"
        className={`tl-ready-chip ${isReady ? 'on' : 'off'}`}
        onClick={toggle}
        disabled={disabled}
        title={!hasLink && !isReady ? 'Сначала прикрепите ссылку на работу' : ''}
      >
        {isReady ? (
          <>
            <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
              <path d="M2.5 6.5l2.5 2.5 4.5-5" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            готово · снять
          </>
        ) : (
          <>
            <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
              <circle cx="6" cy="6" r="4" stroke="currentColor" strokeWidth="1.2" fill="none" />
            </svg>
            отметить готово
          </>
        )}
      </button>
      {!isReady && !hasLink && (
        <span className="tl-ready-hint">прикрепите ссылку, чтобы отметить готовность</span>
      )}
      {err && <div className="rpc-error tl-link-err">{err}</div>}
    </div>
  );
}

function formatStamp(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(+d)) return '';
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' }) + ', ' +
         d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

/* Renders a notes block — admin's commentary after rating.
 * URLs in the text are auto-linkified and open in a new tab. */
function NotesBlock({ notes }) {
  if (!notes || !notes.trim()) return null;
  // Split text by URL regex; keep the URLs as separate tokens for <a> wrap.
  const urlRe = /(https?:\/\/[^\s<>"']+)/g;
  const parts = [];
  let lastIdx = 0;
  let m;
  while ((m = urlRe.exec(notes)) !== null) {
    if (m.index > lastIdx) parts.push({ kind: 'text', value: notes.slice(lastIdx, m.index) });
    parts.push({ kind: 'url', value: m[0] });
    lastIdx = m.index + m[0].length;
  }
  if (lastIdx < notes.length) parts.push({ kind: 'text', value: notes.slice(lastIdx) });

  return (
    <div className="tl-notes">
      <div className="tl-notes-label">
        <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
          <path d="M2.5 2.5h7v7h-7z M4 4.5h4 M4 6h4 M4 7.5h2.5"
            stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        </svg>
        заметка
      </div>
      <div className="tl-notes-text">
        {parts.map((p, i) =>
          p.kind === 'url'
            ? <a key={i} href={p.value} target="_blank" rel="noopener noreferrer" className="tl-notes-link">{p.value}</a>
            : <React.Fragment key={i}>{p.value}</React.Fragment>
        )}
      </div>
    </div>
  );
}

function TimelineItem({ history, canEditLink, canSetReady, onLinkChange }) {
  const dl = formatDeadline(history.deadline, history);
  const showDeadline = dl && (history.status === 'current' || history.status === 'todo');
  const retries = history.retries || 0;
  return (
    <li className={`tl-item ${history.status} ${history.isReady ? 'ready' : ''}`}>
      <div className="tl-dot" />
      <div className="tl-body">
        <div className="tl-title">
          {history.stage ? history.stage.title : '—'}
          {retries > 0 && (
            <span className="tl-retries" title="Попытки сдачи (после первой проверки)">×{retries + 1}</span>
          )}
        </div>
        {history.stage && history.stage.description && (
          <div className="tl-desc">{history.stage.description}</div>
        )}
        {showDeadline && (
          <div className={`tl-deadline ${dl.onTime ? 'ontime' : (dl.overdue ? 'overdue' : '')}`}>
            {dl.onTime ? (
              <svg width="11" height="11" viewBox="0 0 11 11" aria-hidden="true">
                <path d="M2.2 6l2.4 2.4L9 3.8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              </svg>
            ) : (
              <svg width="11" height="11" viewBox="0 0 11 11" aria-hidden="true">
                <circle cx="5.5" cy="6" r="4" stroke="currentColor" strokeWidth="1.1" fill="none" />
                <path d="M5.5 4v2.2L7 7" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" fill="none" />
              </svg>
            )}
            <span>
              {dl.onTime
                ? <>сдана в срок · дедлайн был {dl.dateStr}</>
                : <>дедлайн {dl.dateStr} · {dl.rel}</>}
            </span>
          </div>
        )}
        <LinkEditor history={history} canEdit={canEditLink} onChange={onLinkChange} />
        {history.status === 'current' && (
          <ReadyToggle history={history} canEdit={!!canSetReady} onChange={onLinkChange} />
        )}
        <NotesBlock notes={history.notes} />
      </div>
      <div className="tl-score">
        {history.score != null
          ? <span className="tl-num">{history.score}</span>
          : <span className="tl-empty">—</span>}
      </div>
    </li>
  );
}

window.TagEditor = TagEditor;
window.DrawerEditForm = DrawerEditForm;
window.CandidateAddModal = CandidateAddModal;
window.TimelineItem = TimelineItem;

/* ----------------------------- Avatar editor ----------------------------- */
/* Inline edit for avatarUrl, similar styling to LinkEditor on timeline.    */
function AvatarUrlEditor({ detail, canEdit, mode, onChange }) {
  const isSelfA = mode === 'self';
  const [editing, setEditing] = useStateE(false);
  const [draft, setDraft] = useStateE(detail.avatarUrl || '');
  const [busy, setBusy] = useStateE(false);
  const [err, setErr] = useStateE(null);

  useEffectE(() => {
    if (!editing) setDraft(detail.avatarUrl || '');
  }, [detail.avatarUrl, editing]);

  if (!canEdit && !detail.avatarUrl) return null;

  const save = async (urlOverride) => {
    if (busy) return;
    const trimmed = (urlOverride !== undefined ? urlOverride : draft).trim();
    setBusy(true); setErr(null);
    try {
      const newUrl = trimmed === '' ? undefined : trimmed;
      if (isSelfA) {
        // Кандидат правит свой аватар через updateProfile.
        const profile = {
          login: detail.login || '',
          name: detail.name,
          handle: detail.handle,
          city: detail.city || '',
          age: detail.age,
          bio: detail.bio || '',
          avatarColor: detail.avatarColor,
          initials: detail.initials,
          avatarUrl: newUrl,
          strengths: detail.strengths || [],
          weaknesses: detail.weaknesses || [],
        };
        await RPC.candidate.updateProfile({ profile });
      } else {
        await RPC.candidate.setAvatarURL({
          candidateID: detail.id,
          avatarUrl: newUrl,
        });
      }
      setEditing(false);
      onChange && onChange();
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  };

  if (!editing) {
    if (!canEdit) return null;
    return (
      <button
        type="button"
        className="avatar-url-toggle"
        onClick={(e) => { e.stopPropagation(); setEditing(true); }}
      >
        {detail.avatarUrl ? 'изменить аватар' : '+ ссылка на аватар'}
      </button>
    );
  }

  return (
    <div className="avatar-url-row" onClick={(e) => e.stopPropagation()}>
      <input
        type="url"
        className="tl-link-input"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        placeholder="https://…/avatar.jpg"
        disabled={busy}
        autoFocus
        onKeyDown={(e) => {
          if (e.key === 'Enter') { e.preventDefault(); save(); }
          if (e.key === 'Escape') { e.preventDefault(); setEditing(false); }
        }}
      />
      <button type="button" className="btn tl-link-save" onClick={() => save()} disabled={busy}>
        {busy ? '…' : 'OK'}
      </button>
      {detail.avatarUrl && (
        <button type="button" className="btn ghost tl-link-detach" onClick={() => save('')} disabled={busy} title="Убрать аватар">×</button>
      )}
      <button type="button" className="btn ghost" onClick={() => setEditing(false)} disabled={busy}>Отмена</button>
      {err && <div className="rpc-error tl-link-err">{err}</div>}
    </div>
  );
}

window.AvatarUrlEditor = AvatarUrlEditor;
