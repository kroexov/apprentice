/* Theory tab — v2. Variant: matrix only, with theme switch + material modal. */

const { useState, useMemo } = React;

const TYPES = {
  book:    { label: 'Книга',  glyph: '📖', color: 'oklch(0.66 0.13 30)'  },
  article: { label: 'Статья', glyph: '📰', color: 'oklch(0.66 0.13 220)' },
  video:   { label: 'Видео',  glyph: '▶',  color: 'oklch(0.66 0.13 340)' },
  quiz:    { label: 'Тест',   glyph: '✓',  color: 'oklch(0.66 0.13 160)' },
  other:   { label: 'Другое', glyph: '◆',  color: 'oklch(0.58 0.05 250)' },
};

/* Material — see DTO from backend */
const MATERIALS = [
  { id: 1,  type: 'book',    title: 'The Go Programming Language', url: 'https://www.gopl.io/', description: 'Базовая книга, первые 6 глав обязательны. Внимание уделить главам 4 (composite types) и 8 (goroutines).', maxScore: 5, order: 1, createdAt: '2026-01-15', updatedAt: '2026-03-02' },
  { id: 2,  type: 'article', title: 'Effective Go', url: 'https://go.dev/doc/effective_go', description: 'Идиомы и стиль. Прочитать целиком, затем обсудим главу про concurrency на личной встрече.', maxScore: 3, order: 2, createdAt: '2026-01-15', updatedAt: '2026-01-15' },
  { id: 3,  type: 'video',   title: 'Concurrency Patterns', url: 'https://www.youtube.com/watch?v=f6kdp27TYZs', description: 'Rob Pike о goroutines, channels, select. Старое, но актуальное.', maxScore: 4, order: 3, createdAt: '2026-01-20', updatedAt: '2026-01-20' },
  { id: 4,  type: 'article', title: 'Go Memory Model', url: 'https://go.dev/ref/mem', description: 'Что гарантирует язык про порядок операций. Сложно, но обязательно для миддлов.', maxScore: 3, order: 4, createdAt: '2026-02-01', updatedAt: '2026-02-01' },
  { id: 5,  type: 'quiz',    title: 'Базовый синтаксис', url: 'https://forms.example/quiz-basic', description: '20 вопросов по основам, проходной балл 80%.', maxScore: 5, order: 5, createdAt: '2026-02-10', updatedAt: '2026-02-10' },
  { id: 6,  type: 'video',   title: 'Understanding Channels', url: 'https://www.youtube.com/watch?v=KBZlN0izeiY', description: 'Kavya Joshi — как устроены каналы внутри.', maxScore: 4, order: 6, createdAt: '2026-02-15', updatedAt: '2026-02-15' },
  { id: 7,  type: 'book',    title: '100 Go Mistakes', url: 'https://100go.co/', description: 'Главы 1–4 и 9. Помогает не наступать на типовые грабли.', maxScore: 5, order: 7, createdAt: '2026-02-20', updatedAt: '2026-02-20' },
  { id: 8,  type: 'article', title: 'Context package', url: 'https://go.dev/blog/context', description: 'Зачем нужен context, как правильно прокидывать.', maxScore: 3, order: 8, createdAt: '2026-03-01', updatedAt: '2026-03-01' },
  { id: 9,  type: 'other',   title: 'Tour of Go', url: 'https://tour.golang.org/', description: 'Пройти полностью, в идеале — параллельно с книгой Donovan.', maxScore: 4, order: 9, createdAt: '2026-03-05', updatedAt: '2026-03-05' },
  { id: 10, type: 'quiz',    title: 'Concurrency: квиз', url: 'https://forms.example/quiz-cc', description: '15 вопросов, после видео Pike и Joshi.', maxScore: 5, order: 10, createdAt: '2026-03-10', updatedAt: '2026-03-10' },
];

const CANDIDATES = [
  { id: 1, name: 'Анна Соколова',    initials: 'АС', color: 'oklch(0.78 0.12 30)'  },
  { id: 2, name: 'Дмитрий Волков',   initials: 'ДВ', color: 'oklch(0.78 0.12 220)' },
  { id: 3, name: 'Мария Петрова',    initials: 'МП', color: 'oklch(0.78 0.12 160)' },
  { id: 4, name: 'Иван Кузнецов',    initials: 'ИК', color: 'oklch(0.78 0.12 340)' },
  { id: 5, name: 'Елена Никитина',   initials: 'ЕН', color: 'oklch(0.78 0.12 70)'  },
  { id: 6, name: 'Артём Орлов',      initials: 'АО', color: 'oklch(0.78 0.12 280)' },
];

const PROGRESS = {
  1: { 1: { read: true, readAt: '2026-04-12', score: 5 }, 2: { read: true, readAt: '2026-04-15', score: 3 }, 3: { read: true, readAt: '2026-04-20', score: 4 }, 4: { read: true, readAt: '2026-04-22' }, 5: { read: true, readAt: '2026-04-25', score: 5 }, 6: { read: true, readAt: '2026-04-28' }, 8: { read: true, readAt: '2026-05-01' } },
  2: { 1: { read: true, readAt: '2026-04-10', score: 4 }, 2: { read: true, readAt: '2026-04-14', score: 3 }, 3: { read: true, readAt: '2026-04-19', score: 3 }, 5: { read: true, readAt: '2026-04-24', score: 4 } },
  3: { 1: { read: true, readAt: '2026-04-15', score: 5 }, 2: { read: true, readAt: '2026-04-18', score: 3 }, 3: { read: true, readAt: '2026-04-22', score: 4 }, 4: { read: true, readAt: '2026-04-25', score: 3 }, 5: { read: true, readAt: '2026-04-28', score: 5 }, 6: { read: true, readAt: '2026-05-01', score: 4 }, 7: { read: true, readAt: '2026-05-02' }, 8: { read: true, readAt: '2026-05-03' }, 9: { read: true, readAt: '2026-05-03' } },
  4: { 1: { read: true, readAt: '2026-04-20', score: 3 }, 2: { read: true, readAt: '2026-04-23' } },
  5: { 1: { read: true, readAt: '2026-04-08', score: 5 }, 2: { read: true, readAt: '2026-04-11', score: 3 }, 3: { read: true, readAt: '2026-04-15', score: 4 }, 4: { read: true, readAt: '2026-04-18', score: 3 }, 5: { read: true, readAt: '2026-04-20', score: 5 } },
  6: {},
};

const cellState = (cid, mid) => {
  const r = PROGRESS[cid] && PROGRESS[cid][mid];
  if (!r || !r.read) return 'empty';
  if (r.score == null) return 'pending';
  return 'verified';
};
const candProgress = (cid) => {
  let read = 0, verified = 0;
  MATERIALS.forEach(m => {
    const r = PROGRESS[cid] && PROGRESS[cid][m.id];
    if (r && r.read) read++;
    if (r && r.score != null) verified++;
  });
  return { read, verified, total: MATERIALS.length };
};
const matProgress = (mid) => {
  let read = 0, verified = 0;
  CANDIDATES.forEach(c => {
    const r = PROGRESS[c.id] && PROGRESS[c.id][mid];
    if (r && r.read) read++;
    if (r && r.score != null) verified++;
  });
  return { read, verified, total: CANDIDATES.length };
};

/* ---- shared bits ---- */

function Avatar({ c, size = 28 }) {
  return <div className="tm-av" style={{ width: size, height: size, background: c.color, fontSize: size * 0.36 }}>{c.initials}</div>;
}

function ProgressPill({ read, total, verified }) {
  const pct = Math.round(read / total * 100);
  return (
    <div className="tm-pp" title={`${verified} проверено из ${read} прочитанных`}>
      <div className="tm-pp-bar">
        <div className="tm-pp-fill" style={{ width: pct + '%' }}></div>
        {verified > 0 && <div className="tm-pp-fill verified" style={{ width: Math.round(verified / total * 100) + '%' }}></div>}
      </div>
      <div className="tm-pp-text">
        <span className="tm-pp-num">{read}<span className="tm-pp-den">/{total}</span></span>
        <span className="tm-pp-pct">{pct}%</span>
      </div>
    </div>
  );
}

/* ---- Material modal (admin/candidate/guest) ---- */

function MaterialModal({ material, role, onClose, myCandidateId }) {
  if (!material) return null;
  const t = TYPES[material.type];
  const mp = matProgress(material.id);
  const verifiedScores = CANDIDATES
    .map(c => ({ c, r: PROGRESS[c.id] && PROGRESS[c.id][material.id] }))
    .filter(x => x.r && x.r.score != null);
  const avgScore = verifiedScores.length
    ? (verifiedScores.reduce((a, x) => a + x.r.score, 0) / verifiedScores.length).toFixed(1)
    : '—';

  return (
    <div className="tm-modal-back" onClick={onClose}>
      <div className="tm-modal" onClick={e => e.stopPropagation()}>
        <button className="tm-modal-x" onClick={onClose} aria-label="Закрыть">✕</button>
        <div className="tm-modal-eyebrow" style={{ '--type-color': t.color }}>
          <span className="tm-modal-glyph">{t.glyph}</span>
          <span>{t.label} · #{material.order}</span>
        </div>
        <h3 className="tm-modal-title">{material.title}</h3>
        <a className="tm-modal-link" href={material.url} target="_blank" rel="noreferrer">{material.url} ↗</a>
        <p className="tm-modal-desc">{material.description}</p>

        <div className="tm-modal-meta">
          <div><span>Макс. балл</span><b>{material.maxScore}</b></div>
          <div><span>Создан</span><b>{material.createdAt}</b></div>
          <div><span>Обновлён</span><b>{material.updatedAt}</b></div>
        </div>

        <div className="tm-modal-stats">
          <div className="tm-modal-stat">
            <div className="tm-modal-stat-num">{mp.read}<span className="tm-modal-stat-den">/{mp.total}</span></div>
            <div className="tm-modal-stat-lbl">прочитали</div>
          </div>
          <div className="tm-modal-stat">
            <div className="tm-modal-stat-num">{mp.verified}<span className="tm-modal-stat-den">/{mp.total}</span></div>
            <div className="tm-modal-stat-lbl">зачтено</div>
          </div>
          <div className="tm-modal-stat">
            <div className="tm-modal-stat-num">{avgScore}<span className="tm-modal-stat-den">/{material.maxScore}</span></div>
            <div className="tm-modal-stat-lbl">средний балл</div>
          </div>
        </div>

        <div className="tm-modal-section-title">Кто прочитал</div>
        <div className="tm-modal-list">
          {CANDIDATES.map(c => {
            const r = PROGRESS[c.id] && PROGRESS[c.id][material.id];
            const st = cellState(c.id, material.id);
            return (
              <div key={c.id} className={`tm-modal-row ${st}`}>
                <Avatar c={c} size={26} />
                <div className="tm-modal-row-name">{c.name}</div>
                <div className="tm-modal-row-date">{r && r.readAt ? r.readAt : '—'}</div>
                <div className="tm-modal-row-score">
                  {st === 'verified' && <span className="tm-mscore verified">{r.score}/{material.maxScore}</span>}
                  {st === 'pending'  && <span className="tm-mscore pending">ожидает</span>}
                  {st === 'empty'    && <span className="tm-mscore empty">—</span>}
                </div>
                {role === 'admin' && st !== 'empty' && (
                  <button className="tm-modal-btn">{st === 'verified' ? 'изменить' : 'оценить'}</button>
                )}
                {role === 'candidate' && c.id === myCandidateId && st === 'empty' && (
                  <button className="tm-modal-btn primary">отметить</button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ---- Matrix ---- */

function MatrixVariant({ role, theme }) {
  const myCandidateId = role === 'candidate' ? 1 : null;
  const [openMat, setOpenMat] = useState(null);

  return (
    <div className={`tm-frame`} data-theme={theme}>
      <div className="tm-topbar">
        <div className="tm-brand">{theme === 'rpg' ? 'Apprentice ⚔' : 'Apprentice'}</div>
        <div className="tm-tabs">
          <div className="tm-tab">Доска</div>
          <div className="tm-tab on">Теория</div>
        </div>
        <div className="tm-role">
          {role === 'admin' && <span className="tm-role-badge admin">{theme === 'rpg' ? 'Магистр' : 'Админ'}</span>}
          {role === 'candidate' && <span className="tm-role-badge user">{theme === 'rpg' ? 'Ученик' : 'Ученик'}</span>}
          {role === 'candidate' && <span className="tm-role-login">@anna</span>}
          {role === 'admin' && <span className="tm-role-login">@admin</span>}
          {role === 'guest' && <span className="tm-role-login">гость</span>}
        </div>
      </div>

      <div className="tm-page">
        <div className="tm-page-head">
          <div>
            <h2 className="tm-h2">{theme === 'rpg' ? 'Гримуар' : 'Теория'}</h2>
            <div className="tm-sub">{MATERIALS.length} материалов · {CANDIDATES.length} учеников · клик по материалу — детали</div>
          </div>
          <div className="tm-legend">
            <span><i className="dot empty"></i>не открыто</span>
            <span><i className="dot pending"></i>прочитано</span>
            <span><i className="dot verified"></i>зачтено</span>
          </div>
        </div>

        <div className="tm-matrix-wrap">
          <table className="tm-matrix">
            <thead>
              <tr>
                <th className="tm-mx-corner">Ученик</th>
                {MATERIALS.map(m => (
                  <th key={m.id} className="tm-mx-col" onClick={() => setOpenMat(m)}>
                    <div className="tm-mx-glyph" style={{ color: TYPES[m.type].color }}>{TYPES[m.type].glyph}</div>
                    <div className="tm-mx-title" title={m.title}>{m.title}</div>
                  </th>
                ))}
                <th className="tm-mx-progress">Прогресс</th>
              </tr>
            </thead>
            <tbody>
              {CANDIDATES.map(c => {
                const p = candProgress(c.id);
                const isMine = myCandidateId === c.id;
                return (
                  <tr key={c.id} className={isMine ? 'mine' : ''}>
                    <td className="tm-mx-row-head">
                      <Avatar c={c} />
                      <span className="tm-mx-row-name">{c.name}</span>
                      {isMine && <span className="tm-mx-mine-badge">это вы</span>}
                    </td>
                    {MATERIALS.map(m => {
                      const st = cellState(c.id, m.id);
                      const r = PROGRESS[c.id] && PROGRESS[c.id][m.id];
                      const showCheckable = isMine && st === 'empty';
                      return (
                        <td key={m.id} className={`tm-mx-cell ${st} ${showCheckable ? 'checkable' : ''}`}>
                          {st === 'verified' && <span className="tm-mx-score">{r.score}<span className="tm-mx-max">/{m.maxScore}</span></span>}
                          {st === 'pending' && <span className="tm-mx-check">✓</span>}
                          {showCheckable && <span className="tm-mx-ghost">✓</span>}
                        </td>
                      );
                    })}
                    <td className="tm-mx-prog">
                      <ProgressPill read={p.read} total={p.total} verified={p.verified} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr>
                <td className="tm-mx-foot-head">Прочитали</td>
                {MATERIALS.map(m => {
                  const ip = matProgress(m.id);
                  return (
                    <td key={m.id} className="tm-mx-foot">
                      <span className="tm-mx-foot-num">{ip.read}<span className="tm-mx-foot-den">/{ip.total}</span></span>
                    </td>
                  );
                })}
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="tm-note">
          {role === 'admin' && 'Клик по заголовку материала — детали и оценка. Клик по ячейке «прочитано» — выставить оценку.'}
          {role === 'candidate' && 'Серая галочка — пустая клетка, по клику отметите «прочитано». Клик по материалу — детали.'}
          {role === 'guest' && 'Только просмотр. Войдите, чтобы отмечать прочитанное.'}
        </div>
      </div>

      <MaterialModal material={openMat} role={role} myCandidateId={myCandidateId} onClose={() => setOpenMat(null)} />
    </div>
  );
}

/* ---- Canvas ---- */

function TheoryCanvas() {
  return (
    <DesignCanvas title="Теория · v2 (матрица)" subtitle="Тот же вариант 1 — с правками: «это вы» только на строке, серые галочки в пустых ячейках кандидата, RPG-тема, кликабельные материалы.">
      <DCSection id="official" title="Official тема" subtitle="Стандартная тема как на главной доске.">
        <DCArtboard id="off-admin"     label="Админ"    width={1320} height={780}><MatrixVariant role="admin"     theme="official" /></DCArtboard>
        <DCArtboard id="off-candidate" label="Кандидат" width={1320} height={780}><MatrixVariant role="candidate" theme="official" /></DCArtboard>
        <DCArtboard id="off-guest"     label="Незарег"  width={1320} height={780}><MatrixVariant role="guest"     theme="official" /></DCArtboard>
      </DCSection>

      <DCSection id="rpg" title="RPG тема" subtitle="Та же матрица в тёмной ember-палитре.">
        <DCArtboard id="rpg-admin"     label="Магистр"  width={1320} height={780}><MatrixVariant role="admin"     theme="rpg" /></DCArtboard>
        <DCArtboard id="rpg-candidate" label="Ученик"   width={1320} height={780}><MatrixVariant role="candidate" theme="rpg" /></DCArtboard>
        <DCArtboard id="rpg-guest"     label="Гость"    width={1320} height={780}><MatrixVariant role="guest"     theme="rpg" /></DCArtboard>
      </DCSection>

      <DCSection id="modal" title="Карточка материала (модалка)" subtitle="Открывается по клику на заголовке материала. Детали + список «кто прочитал».">
        <DCArtboard id="mod-admin-off"  label="Админ · official"     width={1320} height={900}><MatrixVariantWithOpen role="admin"     theme="official" openId={3} /></DCArtboard>
        <DCArtboard id="mod-cand-off"   label="Кандидат · official"  width={1320} height={900}><MatrixVariantWithOpen role="candidate" theme="official" openId={3} /></DCArtboard>
        <DCArtboard id="mod-admin-rpg"  label="Магистр · RPG"        width={1320} height={900}><MatrixVariantWithOpen role="admin"     theme="rpg"      openId={3} /></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

/* Helper variant that opens a modal by default — for showing the modal in canvas. */
function MatrixVariantWithOpen({ role, theme, openId }) {
  const myCandidateId = role === 'candidate' ? 1 : null;
  const mat = MATERIALS.find(m => m.id === openId);
  return (
    <div className={`tm-frame`} data-theme={theme}>
      <div className="tm-topbar">
        <div className="tm-brand">{theme === 'rpg' ? 'Apprentice ⚔' : 'Apprentice'}</div>
        <div className="tm-tabs">
          <div className="tm-tab">Доска</div>
          <div className="tm-tab on">Теория</div>
        </div>
        <div className="tm-role">
          {role === 'admin' && <span className="tm-role-badge admin">Админ</span>}
          {role === 'candidate' && <><span className="tm-role-badge user">Ученик</span><span className="tm-role-login">@anna</span></>}
        </div>
      </div>
      <div className="tm-page tm-page-dimmed">
        <div className="tm-page-head">
          <div><h2 className="tm-h2">{theme === 'rpg' ? 'Гримуар' : 'Теория'}</h2></div>
        </div>
        <div className="tm-matrix-wrap dim">…</div>
      </div>
      <MaterialModal material={mat} role={role} myCandidateId={myCandidateId} onClose={() => {}} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<TheoryCanvas />);
