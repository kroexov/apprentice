/* global React, ReactDOM, RPC, RPC_SESSION, AuthModal */
const { useState, useMemo, useEffect, useCallback, useRef } = React;

function useSession() {
  const [session, setSession] = useState(() => RPC_SESSION.get());
  useEffect(() => RPC_SESSION.onChange(setSession), []);
  return session;
}

/* --------------------------------- Intro --------------------------------- */
function GopherSprite() {
  return (
    <svg viewBox="0 0 80 70" className="gopher-svg" aria-hidden="true">
      <defs>
        <linearGradient id="gophGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="oklch(0.82 0.10 220)" />
          <stop offset="1" stopColor="oklch(0.66 0.13 220)" />
        </linearGradient>
      </defs>
      {/* arms */}
      <ellipse cx="10" cy="42" rx="6" ry="9" fill="url(#gophGrad)" />
      <ellipse cx="70" cy="42" rx="6" ry="9" fill="url(#gophGrad)" />
      {/* body */}
      <rect x="12" y="22" width="56" height="42" rx="22" fill="url(#gophGrad)" />
      {/* ears */}
      <circle cx="22" cy="14" r="6" fill="url(#gophGrad)" />
      <circle cx="58" cy="14" r="6" fill="url(#gophGrad)" />
      <circle cx="22" cy="14" r="2.5" fill="oklch(0.55 0.12 220)" />
      <circle cx="58" cy="14" r="2.5" fill="oklch(0.55 0.12 220)" />
      {/* eyes */}
      <circle cx="29" cy="34" r="6" fill="white" />
      <circle cx="51" cy="34" r="6" fill="white" />
      <circle cx="30" cy="35" r="2.4" fill="oklch(0.2 0.02 240)" />
      <circle cx="52" cy="35" r="2.4" fill="oklch(0.2 0.02 240)" />
      {/* nose */}
      <ellipse cx="40" cy="44" rx="3" ry="2" fill="oklch(0.2 0.02 240)" />
      {/* teeth */}
      <rect x="37.5" y="46" width="2" height="4" fill="white" />
      <rect x="40.5" y="46" width="2" height="4" fill="white" />
      {/* feet */}
      <ellipse cx="28" cy="65" rx="7" ry="4" fill="oklch(0.55 0.12 220)" />
      <ellipse cx="52" cy="65" rx="7" ry="4" fill="oklch(0.55 0.12 220)" />
    </svg>
  );
}

function OfficialIntro({ onStart, onSwitchToRpg, leaving }) {
  return (
    <div className={`intro ${leaving ? 'leaving' : ''}`} aria-hidden={leaving}>
      <div className="intro-sky">
        <div className="goph goph-a"><GopherSprite /></div>
        <div className="goph goph-b"><GopherSprite /></div>
        <div className="goph goph-c"><GopherSprite /></div>
        <div className="goph goph-d"><GopherSprite /></div>
        <div className="goph goph-e"><GopherSprite /></div>
        <div className="goph goph-f"><GopherSprite /></div>
      </div>
      <div className="rpg-mode rpg-mode-official" role="tablist" aria-label="Режим">
        <button role="tab" aria-selected="true" className="on">Official</button>
        <button role="tab" aria-selected="false" onClick={onSwitchToRpg}>RPG</button>
      </div>
      <div className="intro-content">
        <div className="intro-mark">
          <Mark size={56} />
        </div>
        <h1 className="intro-title">Golang Apprentice</h1>
        <p className="intro-sub">Сезон 1 · Когорта весна-лето 2026</p>
        <button className="intro-cta" onClick={onStart}>Начать</button>
      </div>
      <div className="intro-curtain intro-curtain-l" />
      <div className="intro-curtain intro-curtain-r" />
    </div>
  );
}

function Intro({ onStart, leaving }) {
  const [mode, setMode] = useState(() => {
    try { return localStorage.getItem('ga-theme') === 'rpg' ? 'rpg' : 'official'; } catch (e) { return 'official'; }
  });
  useEffect(() => {
    try { localStorage.setItem('ga-theme', mode); } catch (e) {}
    document.documentElement.setAttribute('data-theme', mode);
    window.dispatchEvent(new CustomEvent('ga-theme-change', { detail: { mode } }));
  }, [mode]);

  const RpgIntro = window.RpgIntro;
  if (mode === 'rpg' && RpgIntro) {
    return (
      <RpgIntro
        onStart={onStart}
        onSwitchToOfficial={() => setMode('official')}
        leaving={leaving}
      />
    );
  }
  return (
    <OfficialIntro
      onStart={onStart}
      onSwitchToRpg={() => setMode('rpg')}
      leaving={leaving}
    />
  );
}

/* --------------------------------- Mark --------------------------------- */
function Mark({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden="true">
      <defs>
        <linearGradient id="mk" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="oklch(0.78 0.12 220)" />
          <stop offset="1" stopColor="oklch(0.66 0.13 220)" />
        </linearGradient>
      </defs>
      <rect x="6" y="10" width="28" height="24" rx="13" fill="url(#mk)" />
      <circle cx="13" cy="10" r="3.2" fill="url(#mk)" />
      <circle cx="27" cy="10" r="3.2" fill="url(#mk)" />
      <circle cx="15.5" cy="20" r="2.4" fill="white" />
      <circle cx="24.5" cy="20" r="2.4" fill="white" />
      <circle cx="15.5" cy="20" r="1.1" fill="oklch(0.2 0.02 240)" />
      <circle cx="24.5" cy="20" r="1.1" fill="oklch(0.2 0.02 240)" />
    </svg>
  );
}

/* ------------------------------ Sub-pieces ------------------------------ */
function Avatar({ candidate, size = 36 }) {
  const hasImg = !!candidate.avatarUrl;
  return (
    <div
      className={`avatar${hasImg ? ' avatar-img' : ''}`}
      style={{
        width: size, height: size,
        background: hasImg ? '#0a0a0a' : candidate.avatarColor,
        fontSize: size * 0.36, lineHeight: `${size}px`
      }}
      aria-label={candidate.name}
    >
      {hasImg ? (
        <img
          src={candidate.avatarUrl}
          alt=""
          loading="lazy"
          onError={(e) => {
            const node = e.currentTarget;
            const parent = node.parentNode;
            if (parent) {
              parent.classList.remove('avatar-img');
              parent.style.background = candidate.avatarColor;
              node.remove();
              parent.textContent = candidate.initials;
            }
          }}
        />
      ) : (
        candidate.initials
      )}
    </div>
  );
}

function StageDots({ stages, currentStageId, completedAt }) {
  const currentStage = stages.find(s => s.id === currentStageId);
  const currentOrder = currentStage ? currentStage.order : 0;
  return (
    <div className="dots" role="img" aria-label={`Этап ${currentOrder} из ${stages.length}`}>
      {stages.map((s) => {
        let cls = 'dot todo';
        if (completedAt) cls = 'dot done';
        else if (s.order < currentOrder) cls = 'dot done';
        else if (s.order === currentOrder) cls = 'dot current';
        return <span key={s.id} className={cls} />;
      })}
    </div>
  );
}

function formatCardDeadline(iso, ccs) {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(+d)) return null;
  const dayMs = 24 * 60 * 60 * 1000;
  // Submission already happened — compare setReadyAt vs deadline.
  if (ccs && ccs.isReady && ccs.setReadyAt) {
    const sr = new Date(ccs.setReadyAt);
    if (!isNaN(+sr)) {
      if (sr.getTime() < d.getTime()) {
        return { label: 'сдана в срок', overdue: false, onTime: true };
      }
      const startSr = new Date(sr.getFullYear(), sr.getMonth(), sr.getDate());
      const startDl = new Date(d.getFullYear(), d.getMonth(), d.getDate());
      const lateDays = Math.round((startSr - startDl) / dayMs);
      return { label: `дедлайн пропущен на ${lateDays} д.`, overdue: true, onTime: false, late: true };
    }
  }
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startThat = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const diffDays = Math.round((startThat - startToday) / dayMs);
  const overdue = d.getTime() < now.getTime();
  let label;
  if (diffDays === 0) label = 'сегодня';
  else if (diffDays === 1) label = 'завтра';
  else if (diffDays === -1) label = 'вчера';
  else if (diffDays > 0) label = `${diffDays} д.`;
  else label = `−${Math.abs(diffDays)} д.`;
  return { label, overdue, onTime: false };
}

function CandidateCard({ candidate, stages, onOpen, onDragStart, onDragEnd, dragging, draggable, isMine }) {
  const currentStage = candidate.currentStage || stages.find(s => s.id === candidate.currentStageId);
  const ccs = candidate.currentCandidateStage; // { link?, deadline?, isReady, retries, setReadyAt?, createdAt }
  const dl = ccs && ccs.deadline ? formatCardDeadline(ccs.deadline, ccs) : null;
  const hasLink = ccs && ccs.link;
  const isReady = !!(ccs && ccs.isReady);
  const retries = ccs ? (ccs.retries || 0) : 0;
  // green "mine" outline wins over blue "ready" if both apply
  const readyClass = isReady && !isMine ? 'ready' : '';
  return (
    <div
      className={`card ${dragging ? 'dragging' : ''} ${draggable ? '' : 'not-draggable'} ${isMine ? 'mine' : ''} ${readyClass}`}
      role="button"
      tabIndex={0}
      draggable={draggable}
      onClick={() => onOpen(candidate)}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onOpen(candidate); } }}
      onDragStart={(e) => draggable ? onDragStart(e, candidate) : e.preventDefault()}
      onDragEnd={onDragEnd}
    >
      <div className="card-row">
        <Avatar candidate={candidate} size={40} />
        <div className="card-meta">
          <div className="card-name">{candidate.name}</div>
          <div className="card-handle">@{candidate.handle}</div>
          <div className="card-badges">
            {isMine && <span className="card-mine-badge">это вы</span>}
            {isReady && !isMine && <span className="card-ready-badge">готово</span>}
            {isReady && isMine && <span className="card-ready-badge subtle">готово</span>}
          </div>
        </div>
        <div className="card-score">
          <div className="score-num">{candidate.totalPoints}</div>
          <div className="score-max">/ {candidate.maxPoints}</div>
        </div>
      </div>
      <div className="card-bottom">
        <StageDots
          stages={stages}
          currentStageId={candidate.currentStage ? candidate.currentStage.id : candidate.currentStageId}
          completedAt={candidate.completedAt}
        />
        <div className="card-stage">{currentStage ? currentStage.shortTitle : '—'}</div>
      </div>
      {(hasLink || dl || retries > 0) && (
        <div className="card-extras">
          {hasLink && (
            <a
              className="card-link"
              href={ccs.link}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              title={ccs.link}
            >
              <svg width="11" height="11" viewBox="0 0 12 12" aria-hidden="true">
                <path d="M5 7l-1.5 1.5a2.1 2.1 0 1 1-3-3L2 4M7 5l1.5-1.5a2.1 2.1 0 1 1 3 3L10 8M4.5 7.5l3-3"
                  stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" fill="none"/>
              </svg>
              <span>работа</span>
            </a>
          )}
          {dl && (
            <span
              className={`card-deadline ${dl.onTime ? 'ontime' : (dl.overdue ? 'overdue' : '')}`}
              title={dl.onTime ? 'сдана в срок' : 'дедлайн'}
            >
              {dl.onTime ? (
                <svg width="10" height="10" viewBox="0 0 11 11" aria-hidden="true">
                  <path d="M2.2 6l2.4 2.4L9 3.8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                </svg>
              ) : (
                <svg width="10" height="10" viewBox="0 0 11 11" aria-hidden="true">
                  <circle cx="5.5" cy="6" r="4" stroke="currentColor" strokeWidth="1.1" fill="none" />
                  <path d="M5.5 4v2.2L7 7" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" fill="none" />
                </svg>
              )}
              {dl.label}
            </span>
          )}
          {retries > 0 && (
            <span className="card-retries" title="количество попыток">
              <svg width="10" height="10" viewBox="0 0 11 11" aria-hidden="true">
                <path d="M2 4.5a3.5 3.5 0 1 1 .5 3.7" stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round"/>
                <path d="M2 2.5v2H4" stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round"/>
              </svg>
              ×{retries + 1}
            </span>
          )}
        </div>
      )}
    </div>
  );
}

function FinishColumn({ candidates, stages, onOpen, onDropFinish, onDragStart, onDragEnd, draggingId, canDrag, myCandidateId, isAdmin, isAuthed }) {
  const [over, setOver] = useState(false);
  const emptyText = isAdmin
    ? 'Перетащи сюда, чтобы оценить финальный этап и завершить программу'
    : 'Здесь появятся кандидаты, дошедшие до финала';
  return (
    <section
      className={`column finish-column ${over ? 'drop-over' : ''}`}
      aria-label="Завершено"
      onDragOver={(e) => { if (draggingId != null) { e.preventDefault(); setOver(true); } }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); onDropFinish(); }}
    >
      <header className="col-head">
        <div className="col-head-row">
          <span className="col-num">★</span>
          <h2 className="col-title">Завершено</h2>
        </div>
        <span className="col-count">{candidates.length}</span>
      </header>
      <div className="col-body">
        {candidates.length === 0 && (
          <div className="col-empty">{emptyText}</div>
        )}
        {candidates.map(c => (
          <CandidateCard
            key={c.id}
            candidate={c}
            stages={stages}
            onOpen={onOpen}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
            dragging={draggingId === c.id}
            draggable={!!canDrag}
            isMine={myCandidateId != null && Number(c.id) === myCandidateId}
          />
        ))}
      </div>
    </section>
  );
}

function Column({ stage, index, candidates, stages, onOpen, onDropOnStage, onDragStart, onDragEnd, draggingId, dropTargetId, canDrag, myCandidateId }) {
  const [over, setOver] = useState(false);
  return (
    <section
      className={`column ${over || dropTargetId === stage.id ? 'drop-over' : ''}`}
      aria-label={stage.title}
      onDragOver={(e) => { if (draggingId != null) { e.preventDefault(); setOver(true); } }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); onDropOnStage(stage); }}
    >
      <header className="col-head">
        <div className="col-head-row">
          <span className="col-num">{String(index + 1).padStart(2, '0')}</span>
          <h2 className="col-title">{stage.title}</h2>
        </div>
        <span className="col-count">{candidates.length}</span>
      </header>
      <div className="col-body">
        {candidates.length === 0 && (
          <div className="col-empty">Никого на этом этапе</div>
        )}
        {candidates.map(c => (
          <CandidateCard
            key={c.id}
            candidate={c}
            stages={stages}
            onOpen={onOpen}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
            dragging={draggingId === c.id}
            draggable={!!canDrag}
            isMine={myCandidateId != null && Number(c.id) === myCandidateId}
          />
        ))}
      </div>
    </section>
  );
}

/* --------------------------- Score prompt modal --------------------------- */
function ScorePrompt({ candidate, stage, stepIndex, totalSteps, onSubmit, onCancel, busy, error }) {
  const max = stage ? stage.maxScore : 10;
  const [score, setScore] = useState(Math.min(8, max));
  const [notes, setNotes] = useState('');
  useEffect(() => {
    setScore(Math.min(8, max));
    setNotes('');
  }, [stage && stage.id]);

  if (!stage || !candidate) return null;
  return (
    <div className="th-modal-back" onClick={e => { if (e.target === e.currentTarget && !busy) onCancel(); }}>
      <div className="th-pop" role="dialog" aria-modal="true">
        <div className="th-pop-eyebrow">
          {totalSteps > 1 ? `Шаг ${stepIndex + 1} из ${totalSteps}` : 'Оценка этапа'} · {candidate.name}
        </div>
        <div className="th-pop-title">Оценить «{stage.title}»</div>

        <div className="th-pop-slider">
          <div className="th-pop-num">{score}<span className="th-pop-den">/{max}</span></div>
          <input
            type="range" min={1} max={max} step={1}
            value={score}
            onChange={e => setScore(parseInt(e.target.value, 10))}
            disabled={busy}
            className="th-pop-range"
            autoFocus
          />
          <div className="th-pop-range-labels">
            <span>1</span>
            <span>{max}</span>
          </div>
        </div>

        <textarea
          className="th-input th-textarea th-pop-notes"
          placeholder="Заметка (опционально). Можно вставлять ссылки — они станут кликабельными."
          rows={3}
          value={notes}
          onChange={e => setNotes(e.target.value)}
          disabled={busy}
        />

        {error && <div className="th-err">{error}</div>}

        <div className="th-pop-actions">
          <span style={{ flex: 1 }} />
          <button className="th-modal-btn" onClick={onCancel} disabled={busy}>Отмена</button>
          <button className="th-modal-btn primary" onClick={() => onSubmit(score, notes.trim() || null)} disabled={busy}>
            {busy ? '…' : (stepIndex + 1 === totalSteps ? 'Готово' : 'Дальше')}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------- Drawer -------------------------------- */
function Drawer({ candidateId, stages, onClose, isAdmin, myCandidateId, onCandidateChanged }) {
  const [detail, setDetail] = useState(null);
  const [error, setError] = useState(null);
  const [editing, setEditing] = useState(false);
  const open = candidateId != null;

  const reload = useCallback(async () => {
    if (candidateId == null) return;
    setError(null);
    try {
      const d = await RPC.candidate.getByID({ id: candidateId });
      setDetail(d);
    } catch (e) { setError(e.message); }
  }, [candidateId]);

  useEffect(() => {
    if (candidateId == null) { setDetail(null); setEditing(false); return; }
    let cancelled = false;
    setError(null);
    setEditing(false);
    RPC.candidate.getByID({ id: candidateId })
      .then(d => { if (!cancelled) setDetail(d); })
      .catch(e => { if (!cancelled) setError(e.message); });
    return () => { cancelled = true; };
  }, [candidateId]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const currentStage = detail && detail.currentStage;
  const isCompleted = !!(detail && detail.completedAt);

  return (
    <>
      <div className={`scrim ${open ? 'open' : ''}`} onClick={onClose} />
      <aside className={`drawer ${open ? 'open' : ''}`} aria-hidden={!open}>
        {detail && (
          <>
            <div className="drawer-head">
              <button className="icon-btn" onClick={onClose} aria-label="Закрыть">
                <svg width="16" height="16" viewBox="0 0 16 16">
                  <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                </svg>
              </button>
              <div className="drawer-eyebrow">Личный кабинет</div>
              {(isAdmin || (myCandidateId != null && Number(candidateId) === myCandidateId)) && !editing && (
                <button className="btn ghost drawer-edit-btn" type="button" onClick={() => setEditing(true)}>
                  Редактировать
                </button>
              )}
            </div>

            <div className="drawer-hero">
              <Avatar candidate={detail} size={72} />
              <div className="drawer-hero-meta">
                <h3 className="drawer-name">{detail.name}</h3>
                <div className="drawer-sub">
                  @{detail.handle} · {detail.city}{detail.age != null ? ` · ${detail.age} лет` : ''}
                </div>
                <AvatarUrlEditor
                  detail={detail}
                  canEdit={isAdmin || (myCandidateId != null && Number(candidateId) === myCandidateId)}
                  mode={isAdmin ? 'admin' : 'self'}
                  onChange={async () => {
                    await reload();
                    // notify parent so kanban cards re-render with new avatar,
                    // but don't await — we don't want to surface refresh errors here.
                    if (onCandidateChanged) try { onCandidateChanged(); } catch (e) {}
                  }}
                />
              </div>
            </div>

            {editing ? (
              <DrawerEditForm
                detail={detail}
                mode={isAdmin ? 'admin' : 'self'}
                onCancel={() => setEditing(false)}
                onSaved={async () => {
                  setEditing(false);
                  await reload();
                  onCandidateChanged && onCandidateChanged();
                }}
              />
            ) : (
              <>
                <p className="drawer-bio">{detail.bio || <span className="muted-empty">Описания пока нет</span>}</p>

            <div className="drawer-stats">
              <div className="stat">
                <div className="stat-label">Сумма баллов</div>
                <div className="stat-value">
                  <span className="stat-num">{detail.totalPoints}</span>
                  <span className="stat-den">/ {detail.maxPoints}</span>
                </div>
              </div>
              <div className="stat">
                <div className="stat-label">Текущий этап</div>
                <div className="stat-value">
                  <span className="stat-num small">
                    {isCompleted
                      ? String(detail.stageCount).padStart(2, '0')
                      : (currentStage ? String(currentStage.order).padStart(2, '0') : '—')}
                  </span>
                  <span className="stat-den">/ {String(detail.stageCount).padStart(2, '0')}</span>
                </div>
              </div>
            </div>

            {detail.strengths && detail.strengths.length > 0 && (
              <div className="drawer-section">
                <div className="section-title">Сильные стороны</div>
                <div className="chips">
                  {detail.strengths.map(s => <span key={s} className="chip">{s}</span>)}
                </div>
              </div>
            )}

            {detail.weaknesses && detail.weaknesses.length > 0 && (
              <div className="drawer-section">
                <div className="section-title">Зоны роста</div>
                <div className="chips">
                  {detail.weaknesses.map(s => <span key={s} className="chip muted">{s}</span>)}
                </div>
              </div>
            )}
              </>
            )}

            <div className="drawer-section">
              <div className="section-title">Прогресс по этапам</div>
              <ol className="timeline">
                {detail.history.map((h) => (
                  <TimelineItem
                    key={h.stageId}
                    history={h}
                    canEditLink={isAdmin || (myCandidateId != null && Number(candidateId) === myCandidateId)}
                    canSetReady={isAdmin || (myCandidateId != null && Number(candidateId) === myCandidateId)}
                    onLinkChange={reload}
                  />
                ))}
              </ol>
            </div>

            <div className="drawer-action">
              <div className="hint">
                Чтобы изменить этап — перетащи карточку в нужную колонку.
              </div>
              {isCompleted && (
                <div className="finished">
                  Программа пройдена. Итог: <b>{detail.totalPoints}</b> из {detail.maxPoints}.
                </div>
              )}
            </div>
          </>
        )}

        {!detail && open && !error && (
          <div className="drawer-loading">Загрузка…</div>
        )}
        {!detail && open && error && (
          <div className="drawer-loading">
            <div className="rpc-error">{error}</div>
          </div>
        )}
      </aside>
    </>
  );
}

/* --------------------------------- App --------------------------------- */
function App() {
  const [introVisible, setIntroVisible] = useState(true);
  const [introLeaving, setIntroLeaving] = useState(false);
  const startApp = () => {
    setIntroLeaving(true);
    setTimeout(() => setIntroVisible(false), 1200);
  };

  // Theme — synced with intro and persisted to localStorage.
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem('ga-theme') === 'rpg' ? 'rpg' : 'official'; } catch (e) { return 'official'; }
  });
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    try { localStorage.setItem('ga-theme', theme); } catch (e) {}
  }, [theme]);
  useEffect(() => {
    const onChange = (e) => { if (e.detail && e.detail.mode) setTheme(e.detail.mode); };
    window.addEventListener('ga-theme-change', onChange);
    return () => window.removeEventListener('ga-theme-change', onChange);
  }, []);

  const session = useSession();
  const principal = session && session.principal;
  const isAdmin = !!(principal && principal.userType === 'admin');
  const myCandidateId = principal && principal.userType !== 'admin'
    ? Number(principal.userId)
    : null;

  // Resolve principal once at boot if there's an authKey cookie.
  useEffect(() => { RPC_SESSION.boot && RPC_SESSION.boot(); }, []);
  const [authOpen, setAuthOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);

  const [stages, setStages] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [summary, setSummary] = useState(null);
  const [openId, setOpenId] = useState(null);
  const [sortBy, setSortBy] = useState('points');
  const [view, setView] = useState('board'); // 'board' | 'theory'
  const [bootError, setBootError] = useState(null);
  const [loading, setLoading] = useState(true);

  // drag state
  const [draggingId, setDraggingId] = useState(null);
  const draggingRef = useRef(null);

  // forward-advance flow state
  const [advanceQueue, setAdvanceQueue] = useState(null); // { candidate, stages: [stage,...], stepIndex }
  const [advanceBusy, setAdvanceBusy] = useState(false);
  const [advanceError, setAdvanceError] = useState(null);

  const refresh = useCallback(async () => {
    try {
      const [stagesRes, candsRes, sumRes] = await Promise.all([
        RPC.stage.get(),
        RPC.candidate.get({ sortBy }),
        RPC.dashboard.summary(),
      ]);
      setStages(stagesRes || []);
      setCandidates(candsRes || []);
      setSummary(sumRes || null);
      setBootError(null);
    } catch (e) {
      setBootError(e.message);
    } finally {
      setLoading(false);
    }
  }, [sortBy]);

  useEffect(() => { refresh(); }, [refresh]);

  const byStage = useMemo(() => {
    const map = new Map();
    stages.forEach(s => map.set(s.id, []));
    candidates.forEach(c => {
      if (c.completedAt) return; // completed candidates live in the Finish column only
      const sid = c.currentStage ? c.currentStage.id : c.currentStageId;
      if (map.has(sid)) map.get(sid).push(c);
    });
    return stages.map(s => map.get(s.id) || []);
  }, [stages, candidates]);

  /* ------------------------------- Drag flow ------------------------------ */
  const onDragStart = (e, candidate) => {
    draggingRef.current = candidate;
    setDraggingId(candidate.id);
    try {
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', String(candidate.id));
    } catch (err) {}
  };
  const onDragEnd = () => {
    draggingRef.current = null;
    setDraggingId(null);
  };

  const onDropOnStage = async (targetStage) => {
    const candidate = draggingRef.current;
    draggingRef.current = null;
    setDraggingId(null);
    if (!candidate) return;
    if (!isAdmin) return;

    const currentStageObj = candidate.currentStage || stages.find(s => s.id === candidate.currentStageId);
    if (!currentStageObj) return;

    // If candidate is completed and dropped on a stage column — treat as a roll-back from "completed"
    // back to that stage. Roll back once to clear completion (lands them on final stage), then continue
    // rolling back to the target.
    const isCompleted = !!candidate.completedAt;
    const currentOrder = currentStageObj.order;
    const targetOrder = targetStage.order;

    if (!isCompleted && targetOrder === currentOrder) return;

    if (isCompleted || targetOrder < currentOrder) {
      // Number of rollbacks: if completed, 1 to clear completion + (currentOrder - targetOrder) to walk back.
      // If not completed, just (currentOrder - targetOrder).
      const steps = (isCompleted ? 1 : 0) + Math.max(0, currentOrder - targetOrder);
      try {
        for (let i = 0; i < steps; i++) {
          await RPC.candidate.rollback({ candidateID: candidate.id });
        }
        await refresh();
      } catch (e) {
        alert('Не удалось откатить кандидата: ' + e.message);
        await refresh();
      }
      return;
    }

    // targetOrder > currentOrder — forward advance
    const stagesToScore = stages
      .filter(s => s.order >= currentOrder && s.order < targetOrder)
      .sort((a, b) => a.order - b.order);
    setAdvanceError(null);
    setAdvanceQueue({ candidateId: candidate.id, candidateName: candidate.name, stagesToScore, stepIndex: 0 });
  };

  const submitAdvanceStep = async (score, notes) => {
    if (!advanceQueue) return;
    setAdvanceBusy(true);
    setAdvanceError(null);
    try {
      await RPC.candidate.advance({ candidateID: advanceQueue.candidateId, score, notes: notes || null });
      const nextIndex = advanceQueue.stepIndex + 1;
      if (nextIndex >= advanceQueue.stagesToScore.length) {
        setAdvanceQueue(null);
        await refresh();
      } else {
        setAdvanceQueue({ ...advanceQueue, stepIndex: nextIndex });
      }
    } catch (e) {
      setAdvanceError(e.message);
    } finally {
      setAdvanceBusy(false);
    }
  };

  const cancelAdvance = async () => {
    setAdvanceQueue(null);
    setAdvanceError(null);
    await refresh();
  };

  // Drop on the virtual "Завершено" column — score the final stage and complete the program.
  const onDropFinish = async () => {
    const candidate = draggingRef.current;
    draggingRef.current = null;
    setDraggingId(null);
    if (!candidate) return;
    if (!isAdmin) return;
    if (candidate.completedAt) return;

    const currentStageObj = candidate.currentStage || stages.find(s => s.id === candidate.currentStageId);
    if (!currentStageObj) return;

    // Score every remaining stage from current up to and including the last.
    const stagesToScore = stages
      .filter(s => s.order >= currentStageObj.order)
      .sort((a, b) => a.order - b.order);

    setAdvanceError(null);
    setAdvanceQueue({
      candidateId: candidate.id,
      candidateName: candidate.name,
      stagesToScore,
      stepIndex: 0,
    });
  };

  const currentPromptCandidate = advanceQueue
    ? candidates.find(c => c.id === advanceQueue.candidateId) || { id: advanceQueue.candidateId, name: advanceQueue.candidateName }
    : null;
  const currentPromptStage = advanceQueue ? advanceQueue.stagesToScore[advanceQueue.stepIndex] : null;

  return (
    <div className="page">
      <header className="topbar">
        <div className="brand">
          <Mark size={26} />
          <div className="brand-text">
            <div className="brand-name">Golang Apprentice</div>
            <div className="brand-sub">Сезон 1 · Когорта весна-лето 2026</div>
          </div>
          <div className="app-tabs" role="tablist" aria-label="Раздел">
            <button role="tab" aria-selected={view === 'board'} className={`app-tab ${view === 'board' ? 'on' : ''}`} onClick={() => setView('board')}>
              {theme === 'rpg' ? 'Поход' : 'Доска'}
            </button>
            <button role="tab" aria-selected={view === 'theory'} className={`app-tab ${view === 'theory' ? 'on' : ''}`} onClick={() => setView('theory')}>
              {theme === 'rpg' ? 'Гримуар' : 'Теория'}
            </button>
          </div>
        </div>

        <div className="top-stats">
          <div className="ts">
            <div className="ts-label">Кандидатов</div>
            <div className="ts-value">{summary ? summary.candidatesCount : '—'}</div>
          </div>
          <div className="ts">
            <div className="ts-label">Этапов</div>
            <div className="ts-value">{summary ? summary.stagesCount : '—'}</div>
          </div>
          <div className="ts">
            <div className="ts-label">Сумма баллов</div>
            <div className="ts-value">
              {summary ? summary.totalPoints : '—'}
              <span className="ts-den"> / {summary ? summary.maxPoints : '—'}</span>
            </div>
          </div>
          <div className="ts">
            <div className="ts-label">Средний этап</div>
            <div className="ts-value">{summary ? summary.averageOrder.toFixed(1) : '—'}</div>
          </div>
        </div>

        <div className="top-controls">
          <span className="sort-label">Сортировать</span>
          <div className="seg">
            <button className={sortBy === 'points' ? 'on' : ''} onClick={() => setSortBy('points')}>по баллам</button>
            <button className={sortBy === 'stage' ? 'on' : ''} onClick={() => setSortBy('stage')}>по этапу</button>
            <button className={sortBy === 'name' ? 'on' : ''} onClick={() => setSortBy('name')}>А–Я</button>
          </div>

          <div className="auth-pill">
            {session ? (
              principal ? (
                <>
                  <span className={`auth-badge ${isAdmin ? 'admin' : 'user'}`}>
                    {isAdmin ? 'Админ' : 'Ученик'}
                  </span>
                  <span className="auth-login">@{principal.login}</span>
                  {isAdmin && (
                    <button className="btn ghost" onClick={() => setAddOpen(true)}>+ Кандидат</button>
                  )}
                  <button className="btn ghost" onClick={() => RPC_SESSION.logout()}>Выйти</button>
                </>
              ) : (
                <span className="auth-login auth-booting">проверка сессии…</span>
              )
            ) : (
              <button className="btn primary" onClick={() => setAuthOpen(true)}>Войти</button>
            )}
          </div>
        </div>
      </header>

      <main className={`board ${draggingId != null ? 'is-dragging' : ''}`} data-screen-label="01 Board" style={{ display: view === 'board' ? '' : 'none' }}>
        {loading && <div className="board-loading">Загрузка…</div>}
        {bootError && (
          <div className="board-error">
            Не удалось получить данные с сервера: {bootError}
            <div className="board-error-hint">
              Endpoint: <code>{window.RPC_ENDPOINT_RESOLVED}</code>
            </div>
          </div>
        )}
        {!loading && !bootError && stages.map((s, i) => (
          <Column
            key={s.id}
            stage={s}
            index={i}
            candidates={byStage[i] || []}
            stages={stages}
            onOpen={(c) => setOpenId(c.id)}
            onDropOnStage={onDropOnStage}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
            draggingId={draggingId}
            canDrag={isAdmin}
            myCandidateId={myCandidateId}
          />
        ))}
        {!loading && !bootError && (
          <FinishColumn
            candidates={candidates.filter(c => !!c.completedAt)}
            stages={stages}
            onOpen={(c) => setOpenId(c.id)}
            onDropFinish={onDropFinish}
            onDragStart={onDragStart}
            onDragEnd={onDragEnd}
            draggingId={draggingId}
            canDrag={isAdmin}
            myCandidateId={myCandidateId}
            isAdmin={isAdmin}
            isAuthed={!!principal}
          />
        )}
      </main>

      {view === 'theory' && window.TheoryTab && (
        <window.TheoryTab isAdmin={isAdmin} principal={principal} theme={theme} />
      )}

      <footer className="footer">
        <div className="foot-left">{isAdmin ? 'Перетащи карточку в другую колонку → сменить этап' : ''}</div>
        <div className="foot-theme" role="tablist" aria-label="Стиль интерфейса">
          <button
            role="tab"
            aria-selected={theme === 'official'}
            className={theme === 'official' ? 'on' : ''}
            onClick={() => setTheme('official')}
          >Official</button>
          <button
            role="tab"
            aria-selected={theme === 'rpg'}
            className={theme === 'rpg' ? 'on' : ''}
            onClick={() => setTheme('rpg')}
          >RPG</button>
        </div>
        <div className="foot-right">Клик по карточке → личный кабинет</div>
      </footer>

      <Drawer
        candidateId={openId}
        stages={stages}
        onClose={() => setOpenId(null)}
        isAdmin={isAdmin}
        myCandidateId={myCandidateId}
        onCandidateChanged={refresh}
      />

      {advanceQueue && currentPromptStage && (
        <ScorePrompt
          candidate={currentPromptCandidate}
          stage={currentPromptStage}
          stepIndex={advanceQueue.stepIndex}
          totalSteps={advanceQueue.stagesToScore.length}
          onSubmit={submitAdvanceStep}
          onCancel={cancelAdvance}
          busy={advanceBusy}
          error={advanceError}
        />
      )}

      {introVisible && <Intro onStart={startApp} leaving={introLeaving} />}

      {authOpen && (
        <AuthModal
          onClose={() => setAuthOpen(false)}
          onSuccess={() => { setAuthOpen(false); refresh(); }}
        />
      )}

      {addOpen && (
        <CandidateAddModal
          stages={stages}
          onClose={() => setAddOpen(false)}
          onCreated={(c) => {
            setAddOpen(false);
            refresh();
            if (c && c.id) setOpenId(c.id);
          }}
        />
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
