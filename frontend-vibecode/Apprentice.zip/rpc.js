/* Apprentice — JSON-RPC 2.0 client with auth + Me boot. */
(function (global) {
  const DEFAULT_ENDPOINT = 'https://kroexov.webhop.me/apprentice/v1/rpc/';
  const ENDPOINT = global.RPC_ENDPOINT || DEFAULT_ENDPOINT;
  const COOKIE_KEY = 'ga_auth';   // stores authKey only

  let nextId = 1;

  /* ----------------------------- session store -----------------------------
   * session shape: { authKey, principal: { userId, login, userType } | null }
   * On boot: read authKey from cookie; principal is null until auth.Me succeeds.
   * setAuthKey(key) — saves cookie and resolves principal via auth.Me.
   * setSession(null) — clears cookie + principal (logout).
   */
  function readCookie(name) {
    const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : null;
  }
  function writeCookie(name, value, days) {
    const expires = new Date(Date.now() + days * 864e5).toUTCString();
    document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/; samesite=lax`;
  }
  function clearCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/`;
  }

  let authKey = readCookie(COOKIE_KEY) || null;
  let principal = null;            // resolved by auth.Me
  let booting = !!authKey;         // true while we're verifying cookie via Me

  const listeners = new Set();
  function notify() { listeners.forEach(fn => { try { fn(getSession()); } catch (e) {} }); }
  function onSessionChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }

  function getSession() {
    if (!authKey) return null;
    return { authKey, principal, booting };
  }

  function setAuthKeyCookie(key) {
    authKey = key;
    if (key) writeCookie(COOKIE_KEY, key, 14);
    else clearCookie(COOKIE_KEY);
  }

  /* ---------------------------------- send --------------------------------- */
  async function send(method, params) {
    const body = { jsonrpc: '2.0', method, id: nextId++ };
    if (params !== undefined) body.params = params;

    const headers = { 'Content-Type': 'application/json' };
    if (authKey) headers['Authorization2'] = authKey;

    let res;
    try {
      res = await fetch(ENDPOINT, { method: 'POST', headers, body: JSON.stringify(body) });
    } catch (e) {
      const err = new Error('Network error: ' + e.message);
      err.code = 0; throw err;
    }

    let payload;
    try { payload = await res.json(); }
    catch (e) {
      const err = new Error('Invalid JSON from server (HTTP ' + res.status + ')');
      err.code = res.status; throw err;
    }

    if (payload && payload.error) {
      const err = new Error(payload.error.message || 'RPC error');
      err.code = payload.error.code;
      err.data = payload.error.data;
      // Only drop session when auth.Me itself rejects the cookie — that's
      // the canonical "this key no longer works" signal. Other 401s (e.g.
      // a method's own RBAC check) shouldn't log the user out.
      if (err.code === 401 && method === 'auth.Me' && authKey) {
        setAuthKeyCookie(null);
        principal = null;
        booting = false;
        notify();
      }
      throw err;
    }
    return payload ? payload.result : undefined;
  }

  /* --------------------------------- auth ---------------------------------- */
  async function resolveMe() {
    if (!authKey) { principal = null; booting = false; notify(); return null; }
    booting = true; notify();
    try {
      const me = await send('auth.Me');
      principal = me;
    } catch (e) {
      // Send already cleared on 401; for other errors, leave key but principal null.
      principal = null;
    } finally {
      booting = false;
      notify();
    }
    return principal;
  }

  async function login(params) {
    const key = await send('auth.Login', params);
    setAuthKeyCookie(key);
    await resolveMe();
    return getSession();
  }
  async function register(params) {
    const key = await send('auth.Register', params);
    setAuthKeyCookie(key);
    await resolveMe();
    return getSession();
  }
  async function signUp(params) {
    // params: ISignUpParams (login, password, name, …profile fields)
    const key = await send('auth.SignUp', { params });
    setAuthKeyCookie(key);
    await resolveMe();
    return getSession();
  }
  function logout() {
    setAuthKeyCookie(null);
    principal = null;
    booting = false;
    notify();
  }

  const api = {
    auth: {
      login,
      register,
      signUp,
      logout,
      me: () => send('auth.Me'),
    },
    candidate: {
      add:      (params) => send('candidate.Add', params),
      advance:  (params) => send('candidate.Advance', params),
      delete:   (params) => send('candidate.Delete', params),
      get:      (params) => send('candidate.Get', params),
      getByID:  (params) => send('candidate.GetByID', params),
      kanban:   ()       => send('candidate.Kanban'),
      rate:     (params) => send('candidate.Rate', params),
      rollback: (params) => send('candidate.Rollback', params),
      setAvatarURL: (params) => send('candidate.SetAvatarURL', params),
      setLink:  (params) => send('candidate.SetLink', params),
      setReady: (params) => send('candidate.SetReady', params),
      update:   (params) => send('candidate.Update', params),
      updateProfile: (params) => send('candidate.UpdateProfile', params),
    },
    dashboard: { summary: () => send('dashboard.Summary') },
    stage: {
      add:     (params) => send('stage.Add', params),
      delete:  (params) => send('stage.Delete', params),
      get:     ()       => send('stage.Get'),
      getByID: (params) => send('stage.GetByID', params),
      reorder: (params) => send('stage.Reorder', params),
      update:  (params) => send('stage.Update', params),
    },
    material: {
      add:           (params) => send('material.Add', params),
      delete:        (params) => send('material.Delete', params),
      get:           (params) => send('material.Get', params || {}),
      getByID:       (params) => send('material.GetByID', params),
      getProgress:   ()       => send('material.GetProgress'),
      getMyProgress: ()       => send('material.GetMyProgress'),
      score:         (params) => send('material.Score', params),
      setRead:       (params) => send('material.SetRead', params),
      unscore:       (params) => send('material.Unscore', params),
      update:        (params) => send('material.Update', params),
    },
  };

  global.RPC = api;
  global.RPC_SESSION = {
    get: getSession,
    onChange: onSessionChange,
    boot: resolveMe,           // call on app start
    logout,
  };
  global.RPC_ENDPOINT_RESOLVED = ENDPOINT;
})(window);
