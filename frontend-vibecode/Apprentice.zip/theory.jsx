/* Theory tab — backed by material.* RPC. Globals: window.TheoryTab */
/* global React, RPC */
(function () {
  const { useState, useMemo, useEffect, useCallback } = React;

  const TYPES = [
    { id: 'book',    label: 'Книга',  glyph: '📖', color: 'oklch(0.66 0.13 30)'  },
    { id: 'article', label: 'Статья', glyph: '📰', color: 'oklch(0.66 0.13 220)' },
    { id: 'video',   label: 'Видео',  glyph: '▶',  color: 'oklch(0.66 0.13 340)' },
    { id: 'test',    label: 'Тест',   glyph: '✓',  color: 'oklch(0.66 0.13 160)' },
    { id: 'other',   label: 'Другое', glyph: '◆',  color: 'oklch(0.58 0.05 250)' },
  ];
  const typeOf = (id) => TYPES.find(t => t.id === id) || TYPES[4];

  /* Indexed lookup of progress: key = `${candidateId}:${materialId}` */
  function indexProgress(rows) {
    const m = new Map();
    (rows || []).forEach(r => m.set(`${r.candidateId}:${r.materialId}`, r));
    return m;
  }

  function cellState(progressMap, cid, mid) {
    const r = progressMap.get(`${cid}:${mid}`);
    if (!r || !r.readAt) {
      if (r && r.score != null) return 'verified'; // scored without read flag (admin upserted)
      return 'empty';
    }
    if (r.score != null) return 'verified';
    return 'pending';
  }

  /* Linkify plain text: returns an array of strings and <a> elements
   * for URLs (http/https). Used in material description, mirrors the
   * NotesBlock behavior on candidate stages. */
  function linkifyText(text) {
    if (!text) return [];
    const urlRe = /(https?:\/\/[^\s<>"']+?)([.,;:!?)\]]*)(?=\s|$)/g;
    const out = [];
    let lastIdx = 0;
    let m;
    while ((m = urlRe.exec(text)) !== null) {
      if (m.index > lastIdx) out.push({ kind: 'text', value: text.slice(lastIdx, m.index) });
      out.push({ kind: 'url', value: m[1] });
      if (m[2]) out.push({ kind: 'text', value: m[2] });
      lastIdx = m.index + m[0].length;
    }
    if (lastIdx < text.length) out.push({ kind: 'text', value: text.slice(lastIdx) });
    return out;
  }

  function LinkifiedText({ text, linkClass }) {
    const parts = useMemo(() => linkifyText(text), [text]);
    return parts.map((p, i) =>
      p.kind === 'url'
        ? <a key={i} href={p.value} target="_blank" rel="noopener noreferrer" className={linkClass}>{p.value}</a>
        : <React.Fragment key={i}>{p.value}</React.Fragment>
    );
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(+d)) return '—';
    return d.toISOString().slice(0, 10);
  }

  function Avatar({ c, size = 28 }) {
    return <div className="th-av" style={{ width: size, height: size, background: c.avatarColor, fontSize: size * 0.36 }}>{c.initials}</div>;
  }

  function ProgressPill({ read, total, verified }) {
    const pct = total ? Math.round(read / total * 100) : 0;
    const vpct = total ? Math.round(verified / total * 100) : 0;
    return (
      <div className="th-pp">
        <div className="th-pp-bar">
          <div className="th-pp-fill" style={{ width: pct + '%' }}></div>
          {verified > 0 && <div className="th-pp-fill verified" style={{ width: vpct + '%' }}></div>}
        </div>
        <div className="th-pp-text">
          <span className="th-pp-num">{read}<span className="th-pp-den">/{total}</span></span>
          <span className="th-pp-pct">{pct}%</span>
        </div>
      </div>
    );
  }

  /* --- Material modal --- */
  function MaterialModal({ material, role, candidates, progressMap, myCandidateId, onClose, onMark, onUnmark, onScore, onEdit, onDelete }) {
    if (!material) return null;
    const t = typeOf(material.type);
    let read = 0, verified = 0;
    candidates.forEach(c => {
      const r = progressMap.get(`${c.id}:${material.id}`);
      if (r && r.readAt) read++;
      if (r && r.score != null) verified++;
    });
    const verifiedScores = candidates
      .map(c => progressMap.get(`${c.id}:${material.id}`))
      .filter(r => r && r.score != null);
    const avgScore = verifiedScores.length
      ? (verifiedScores.reduce((a, r) => a + r.score, 0) / verifiedScores.length).toFixed(1)
      : '—';

    return (
      <div className="th-modal-back" onClick={onClose}>
        <div className="th-modal" onClick={e => e.stopPropagation()}>
          <button className="th-modal-x" onClick={onClose} aria-label="Закрыть">✕</button>
          <div className="th-modal-eyebrow" style={{ '--type-color': t.color }}>
            <span className="th-modal-glyph">{t.glyph}</span>
            <span>{t.label} · #{material.order}</span>
          </div>
          <h3 className="th-modal-title">{material.title}</h3>
          <a className="th-modal-link" href={material.url} target="_blank" rel="noreferrer">{material.url} ↗</a>
          {material.description && (
            <p className="th-modal-desc">
              <LinkifiedText text={material.description} linkClass="th-modal-desc-link" />
            </p>
          )}

          <div className="th-modal-meta">
            <div><span>Макс. балл</span><b>{material.maxScore}</b></div>
            <div><span>Создан</span><b>{fmtDate(material.createdAt)}</b></div>
            <div><span>Обновлён</span><b>{fmtDate(material.updatedAt)}</b></div>
          </div>

          <div className="th-modal-stats">
            <div className="th-modal-stat">
              <div className="th-modal-stat-num">{read}<span className="th-modal-stat-den">/{candidates.length}</span></div>
              <div className="th-modal-stat-lbl">прочитали</div>
            </div>
            <div className="th-modal-stat">
              <div className="th-modal-stat-num">{verified}<span className="th-modal-stat-den">/{candidates.length}</span></div>
              <div className="th-modal-stat-lbl">зачтено</div>
            </div>
            <div className="th-modal-stat">
              <div className="th-modal-stat-num">{avgScore}<span className="th-modal-stat-den">/{material.maxScore}</span></div>
              <div className="th-modal-stat-lbl">средний балл</div>
            </div>
          </div>

          <div className="th-modal-section-title">Кто прочитал</div>
          <div className="th-modal-list">
            {candidates.map(c => {
              const r = progressMap.get(`${c.id}:${material.id}`);
              const st = cellState(progressMap, c.id, material.id);
              const isMine = c.id === myCandidateId;
              return (
                <div key={c.id} className={`th-modal-row ${st}`}>
                  <Avatar c={c} size={26} />
                  <div className="th-modal-row-name">{c.name}{isMine && <span className="th-mine-tag">это вы</span>}</div>
                  <div className="th-modal-row-date">{r && r.readAt ? fmtDate(r.readAt) : '—'}</div>
                  <div className="th-modal-row-score">
                    {st === 'verified' && <span className="th-mscore verified">{r.score}/{material.maxScore}</span>}
                    {st === 'pending'  && <span className="th-mscore pending">ожидает</span>}
                    {st === 'empty'    && <span className="th-mscore empty">—</span>}
                  </div>
                  <div className="th-modal-row-actions">
                    {role === 'admin' && st !== 'empty' && (
                      <button className="th-modal-btn" onClick={() => onScore(c, material)}>{st === 'verified' ? 'изменить' : 'оценить'}</button>
                    )}
                    {role === 'candidate' && isMine && st === 'empty' && (
                      <button className="th-modal-btn primary" onClick={() => onMark(c.id, material.id)}>отметить</button>
                    )}
                    {role === 'candidate' && isMine && st === 'pending' && (
                      <button className="th-modal-btn" onClick={() => onUnmark(c.id, material.id)}>снять</button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {role === 'admin' && (
            <div className="th-modal-admin-actions">
              <button className="th-modal-btn" onClick={() => onEdit(material)}>Редактировать</button>
              <button className="th-modal-btn danger" onClick={() => onDelete(material)}>Удалить</button>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* --- Score popover --- */
  function ScorePopover({ material, candidate, current, busy, error, onClose, onSubmit, onUnscore }) {
    const [v, setV] = useState(current != null ? current : Math.ceil(material.maxScore / 2));
    const [notes, setNotes] = useState('');
    return (
      <div className="th-modal-back" onClick={busy ? undefined : onClose}>
        <div className="th-pop" onClick={e => e.stopPropagation()}>
          <div className="th-pop-eyebrow">Оценка · {candidate.name}</div>
          <div className="th-pop-title">{material.title}</div>
          <div className="th-pop-slider">
            <div className="th-pop-num">{v}<span className="th-pop-den">/{material.maxScore}</span></div>
            <input
              type="range"
              min={1}
              max={material.maxScore}
              step={1}
              value={v}
              onChange={e => setV(parseInt(e.target.value, 10))}
              disabled={busy}
              className="th-pop-range"
              autoFocus
            />
            <div className="th-pop-range-labels">
              <span>1</span>
              <span>{material.maxScore}</span>
            </div>
          </div>
          <textarea
            className="th-input th-textarea th-pop-notes"
            placeholder="Заметка (опционально)"
            rows={2}
            value={notes}
            onChange={e => setNotes(e.target.value)}
            disabled={busy}
          />
          {error && <div className="th-err">{error}</div>}
          <div className="th-pop-actions">
            {current != null && onUnscore && (
              <button className="th-modal-btn danger" onClick={onUnscore} disabled={busy}>Сбросить</button>
            )}
            <span style={{ flex: 1 }} />
            <button className="th-modal-btn" onClick={onClose} disabled={busy}>Отмена</button>
            <button className="th-modal-btn primary" onClick={() => onSubmit(v, notes.trim() || null)} disabled={busy}>{busy ? '…' : 'Сохранить'}</button>
          </div>
        </div>
      </div>
    );
  }

  /* --- Material form modal (add/edit) --- */
  function MaterialFormModal({ initial, onClose, onSubmit, busy, error, nextOrder }) {
    const isEdit = !!initial;
    const [state, setState] = useState(() => initial ? {
      title: initial.title, type: initial.type, url: initial.url,
      description: initial.description || '', maxScore: initial.maxScore, order: initial.order,
    } : {
      title: '', type: 'book', url: '', description: '', maxScore: 5, order: nextOrder,
    });
    const t = typeOf(state.type);
    const canSubmit = state.title.trim() && state.url.trim() && !busy;

    return (
      <div className="th-modal-back" onClick={busy ? undefined : onClose}>
        <div className="th-add-modal" onClick={e => e.stopPropagation()}>
          <button className="th-modal-x" onClick={onClose} aria-label="Закрыть" disabled={busy}>✕</button>
          <h3 className="th-add-title">{isEdit ? 'Редактировать материал' : 'Новый материал'}</h3>
          <p className="th-add-sub">{isEdit ? 'Изменения применятся ко всем ученикам.' : 'Добавьте источник, который кандидаты должны изучить.'}</p>

          <div className="th-add-grid">
            <div className="th-add-form">
              <label className="th-field">
                <div className="th-flabel">Title<em>*</em></div>
                <input className="th-input" value={state.title} onChange={e => setState(s => ({ ...s, title: e.target.value }))} placeholder="Например: Effective Go" disabled={busy} />
              </label>
              <label className="th-field">
                <div className="th-flabel">Type<em>*</em></div>
                <div className="th-types">
                  {TYPES.map(tt => (
                    <button key={tt.id} type="button" className={`th-type ${state.type === tt.id ? 'on' : ''}`} style={{ '--tc': tt.color }} onClick={() => setState(s => ({ ...s, type: tt.id }))} disabled={busy}>
                      <span className="th-type-glyph">{tt.glyph}</span>
                      <span className="th-type-lbl">{tt.label}</span>
                    </button>
                  ))}
                </div>
              </label>
              <label className="th-field">
                <div className="th-flabel">URL<em>*</em></div>
                <input className="th-input" type="url" value={state.url} onChange={e => setState(s => ({ ...s, url: e.target.value }))} placeholder="https://" disabled={busy} />
              </label>
              <label className="th-field">
                <div className="th-flabel">Description</div>
                <textarea className="th-input th-textarea" rows={4} value={state.description} onChange={e => setState(s => ({ ...s, description: e.target.value }))} placeholder="Главы, ключевые идеи, что обсудим…" disabled={busy} />
              </label>
              <div className="th-add-row2">
                <label className="th-field">
                  <div className="th-flabel">Max score<em>*</em></div>
                  <div className="th-stepper">
                    <button type="button" onClick={() => setState(s => ({ ...s, maxScore: Math.max(1, s.maxScore - 1) }))} disabled={busy}>−</button>
                    <input type="number" min={1} max={100} value={state.maxScore} onChange={e => setState(s => ({ ...s, maxScore: Math.max(1, Math.min(100, Number(e.target.value) || 1)) }))} disabled={busy} />
                    <button type="button" onClick={() => setState(s => ({ ...s, maxScore: Math.min(100, s.maxScore + 1) }))} disabled={busy}>+</button>
                  </div>
                </label>
                <label className="th-field">
                  <div className="th-flabel">Order</div>
                  <input className="th-input th-order" type="number" min={0} value={state.order} onChange={e => setState(s => ({ ...s, order: Math.max(0, Number(e.target.value) || 0) }))} disabled={busy} />
                </label>
              </div>
            </div>
            <div className="th-add-preview">
              <div className="th-add-preview-lbl">Превью</div>
              <div className="th-mat-card" style={{ '--tc': t.color }}>
                <div className="th-mat-eyebrow">
                  <span>{t.glyph}</span>
                  <span>{t.label} · #{state.order}</span>
                  <span className="th-mat-score">{state.maxScore}p</span>
                </div>
                <div className="th-mat-title">{state.title || 'Заголовок материала'}</div>
                <div className="th-mat-link">{state.url || 'https://'}</div>
                <div className="th-mat-desc">{state.description || 'Описание материала.'}</div>
              </div>
            </div>
          </div>

          {error && <div className="th-err th-err-block">{error}</div>}

          <div className="th-add-actions">
            <button type="button" className="th-modal-btn" onClick={onClose} disabled={busy}>Отмена</button>
            <button type="button" className="th-modal-btn primary" disabled={!canSubmit} onClick={() => onSubmit({
              title: state.title.trim(),
              type: state.type,
              url: state.url.trim(),
              description: state.description,
              maxScore: state.maxScore,
              order: state.order,
            })}>{busy ? '…' : (isEdit ? 'Сохранить' : 'Добавить материал')}</button>
          </div>
        </div>
      </div>
    );
  }

  /* --- Main matrix --- */
  function TheoryTab({ isAdmin, principal, theme }) {
    const myCandidateId = principal && principal.userType !== 'admin' ? Number(principal.userId) : null;
    const role = isAdmin ? 'admin' : (principal ? 'candidate' : 'guest');

    const [materials, setMaterials] = useState([]);
    const [candidates, setCandidates] = useState([]);
    const [progressRows, setProgressRows] = useState([]);
    const [loading, setLoading] = useState(true);
    const [err, setErr] = useState(null);

    const [openMat, setOpenMat] = useState(null);
    const [scoreFor, setScoreFor] = useState(null); // { material, candidate, current }
    const [scoreBusy, setScoreBusy] = useState(false);
    const [scoreErr, setScoreErr] = useState(null);
    const [formOpen, setFormOpen] = useState(false);
    const [formInitial, setFormInitial] = useState(null);
    const [formBusy, setFormBusy] = useState(false);
    const [formErr, setFormErr] = useState(null);

    const progressMap = useMemo(() => indexProgress(progressRows), [progressRows]);
    const sorted = useMemo(() => [...materials].sort((a, b) => (a.order - b.order) || a.title.localeCompare(b.title)), [materials]);

    const refresh = useCallback(async () => {
      setErr(null);
      try {
        if (role === 'admin' || role === 'guest') {
          // Public matrix RPC.
          const data = await RPC.material.getProgress();
          setMaterials(data.materials || []);
          setCandidates(data.candidates || []);
          setProgressRows(data.progress || []);
        } else {
          // Candidate: getProgress is also public, but getMyProgress gives self-context.
          // Use getProgress for the matrix (same data as admins see) — read-only for others.
          const data = await RPC.material.getProgress();
          setMaterials(data.materials || []);
          setCandidates(data.candidates || []);
          setProgressRows(data.progress || []);
        }
      } catch (e) {
        setErr(e.message);
      } finally {
        setLoading(false);
      }
    }, [role]);

    useEffect(() => { refresh(); }, [refresh]);

    const candProgress = (cid) => {
      let read = 0, verified = 0;
      sorted.forEach(m => {
        const r = progressMap.get(`${cid}:${m.id}`);
        if (r && r.readAt) read++;
        if (r && r.score != null) verified++;
      });
      return { read, verified, total: sorted.length };
    };
    const matProgress = (mid) => {
      let read = 0;
      candidates.forEach(c => {
        const r = progressMap.get(`${c.id}:${mid}`);
        if (r && r.readAt) read++;
      });
      return { read, total: candidates.length };
    };

    /* --- mutations --- */
    const handleMark = async (cid, mid) => {
      // Only candidate-self can call setRead.
      if (role !== 'candidate' || cid !== myCandidateId) return;
      try {
        await RPC.material.setRead({ materialID: mid, read: true });
        await refresh();
      } catch (e) { alert('Не удалось отметить: ' + e.message); }
    };

    const handleUnmark = async (cid, mid) => {
      if (role !== 'candidate' || cid !== myCandidateId) return;
      const r = progressMap.get(`${cid}:${mid}`);
      if (r && r.score != null) return;
      try {
        await RPC.material.setRead({ materialID: mid, read: false });
        await refresh();
      } catch (e) { alert('Не удалось снять отметку: ' + e.message); }
    };

    const openScore = (candidate, material) => {
      const r = progressMap.get(`${candidate.id}:${material.id}`);
      setScoreErr(null);
      setScoreFor({ candidate, material, current: r && r.score != null ? r.score : null });
    };

    const submitScore = async (score, notes) => {
      if (!scoreFor) return;
      setScoreBusy(true); setScoreErr(null);
      try {
        await RPC.material.score({
          candidateID: scoreFor.candidate.id,
          materialID: scoreFor.material.id,
          score,
          notes: notes || null,
        });
        setScoreFor(null);
        await refresh();
      } catch (e) {
        setScoreErr(e.message);
      } finally { setScoreBusy(false); }
    };

    const submitUnscore = async () => {
      if (!scoreFor) return;
      setScoreBusy(true); setScoreErr(null);
      try {
        await RPC.material.unscore({
          candidateID: scoreFor.candidate.id,
          materialID: scoreFor.material.id,
        });
        setScoreFor(null);
        await refresh();
      } catch (e) {
        setScoreErr(e.message);
      } finally { setScoreBusy(false); }
    };

    const handleCellClick = (c, m) => {
      const st = cellState(progressMap, c.id, m.id);
      if (role === 'admin') {
        // Admin clicks always lead to scoring. Even on empty cells: open score popover (UPSERT).
        openScore(c, m);
      } else if (role === 'candidate' && c.id === myCandidateId) {
        if (st === 'empty') handleMark(c.id, m.id);
        else if (st === 'pending') handleUnmark(c.id, m.id);
      }
    };

    const submitMaterial = async (input) => {
      setFormBusy(true); setFormErr(null);
      try {
        if (formInitial) {
          await RPC.material.update({ id: formInitial.id, input });
        } else {
          await RPC.material.add({ input });
        }
        setFormOpen(false);
        setFormInitial(null);
        await refresh();
      } catch (e) {
        setFormErr(e.message);
      } finally { setFormBusy(false); }
    };

    const handleDelete = async (m) => {
      if (!confirm(`Удалить материал «${m.title}»? Записи прогресса сохранятся.`)) return;
      try {
        await RPC.material.delete({ id: m.id });
        setOpenMat(null);
        await refresh();
      } catch (e) { alert('Не удалось удалить: ' + e.message); }
    };

    return (
      <div className="th-page" data-screen-label="02 Theory">
        <div className="th-page-head">
          <div>
            <h2 className="th-h2">{theme === 'rpg' ? 'Гримуар' : 'Теория'}</h2>
            <div className="th-sub">{materials.length} материалов · {candidates.length} учеников</div>
          </div>
          <div className="th-head-right">
            <div className="th-legend">
              <span><i className="dot empty"></i>не открыто</span>
              <span><i className="dot pending"></i>прочитано</span>
              <span><i className="dot verified"></i>зачтено</span>
            </div>
            {isAdmin && (
              <button className="btn primary" onClick={() => { setFormInitial(null); setFormErr(null); setFormOpen(true); }}>+ Материал</button>
            )}
          </div>
        </div>

        {loading && <div className="th-state">Загрузка…</div>}
        {err && <div className="th-state th-err">Не удалось загрузить: {err}</div>}

        {!loading && !err && (
          <div className="th-matrix-wrap">
            <table className="th-matrix">
              <thead>
                <tr>
                  <th className="th-mx-corner">Ученик</th>
                  {sorted.map(m => (
                    <th key={m.id} className="th-mx-col" onClick={() => setOpenMat(m)} title={m.title}>
                      <div className="th-mx-glyph" style={{ color: typeOf(m.type).color }}>{typeOf(m.type).glyph}</div>
                      <div className="th-mx-title">{m.title}</div>
                    </th>
                  ))}
                  <th className="th-mx-progress">Прогресс</th>
                </tr>
              </thead>
              <tbody>
                {candidates.map(c => {
                  const p = candProgress(c.id);
                  const isMine = myCandidateId === c.id;
                  return (
                    <tr key={c.id} className={isMine ? 'mine' : ''}>
                      <td className="th-mx-row-head">
                        <Avatar c={c} />
                        <span className="th-mx-row-name">{c.name}</span>
                        {isMine && <span className="th-mx-mine-badge">это вы</span>}
                      </td>
                      {sorted.map(m => {
                        const st = cellState(progressMap, c.id, m.id);
                        const r = progressMap.get(`${c.id}:${m.id}`);
                        const interactive = role === 'admin' || (role === 'candidate' && isMine && st !== 'verified');
                        const showGhost = role === 'candidate' && isMine && st === 'empty';
                        return (
                          <td
                            key={m.id}
                            className={`th-mx-cell ${st} ${interactive ? 'interactive' : ''} ${showGhost ? 'ghosted' : ''}`}
                            onClick={interactive ? () => handleCellClick(c, m) : undefined}
                            title={r && r.readAt ? `Прочитано: ${fmtDate(r.readAt)}` : ''}
                          >
                            {st === 'verified' && <span className="th-mx-score">{r.score}<span className="th-mx-max">/{m.maxScore}</span></span>}
                            {st === 'pending' && <span className="th-mx-check">✓</span>}
                            {showGhost && <span className="th-mx-ghost">✓</span>}
                          </td>
                        );
                      })}
                      <td className="th-mx-prog">
                        <ProgressPill read={p.read} total={p.total} verified={p.verified} />
                      </td>
                    </tr>
                  );
                })}
                {candidates.length === 0 && (
                  <tr><td className="th-state" colSpan={sorted.length + 2}>Пока нет учеников.</td></tr>
                )}
              </tbody>
              {candidates.length > 0 && (
                <tfoot>
                  <tr>
                    <td className="th-mx-foot-head">Прочитали</td>
                    {sorted.map(m => {
                      const ip = matProgress(m.id);
                      return (
                        <td key={m.id} className="th-mx-foot">
                          <span className="th-mx-foot-num">{ip.read}<span className="th-mx-foot-den">/{ip.total}</span></span>
                        </td>
                      );
                    })}
                    <td></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}

        <div className="th-note">
          {role === 'admin' && 'Клик по любой ячейке открывает оценку (UPSERT). Клик по заголовку материала — детали и редактирование.'}
          {role === 'candidate' && 'Серая галочка — клик отметит «прочитано». Повторный клик снимет отметку, пока админ не зачёл.'}
          {role === 'guest' && 'Только просмотр. Войдите, чтобы отмечать прочитанное.'}
        </div>

        {openMat && (
          <MaterialModal
            material={openMat}
            role={role}
            candidates={candidates}
            progressMap={progressMap}
            myCandidateId={myCandidateId}
            onClose={() => setOpenMat(null)}
            onMark={(cid, mid) => handleMark(cid, mid)}
            onUnmark={(cid, mid) => handleUnmark(cid, mid)}
            onScore={(c, m) => { setOpenMat(null); openScore(c, m); }}
            onEdit={(m) => { setOpenMat(null); setFormInitial(m); setFormErr(null); setFormOpen(true); }}
            onDelete={handleDelete}
          />
        )}

        {scoreFor && (
          <ScorePopover
            material={scoreFor.material}
            candidate={scoreFor.candidate}
            current={scoreFor.current}
            busy={scoreBusy}
            error={scoreErr}
            onClose={() => setScoreFor(null)}
            onSubmit={submitScore}
            onUnscore={scoreFor.current != null ? submitUnscore : null}
          />
        )}

        {formOpen && (
          <MaterialFormModal
            initial={formInitial}
            busy={formBusy}
            error={formErr}
            onClose={() => { if (!formBusy) { setFormOpen(false); setFormInitial(null); } }}
            onSubmit={submitMaterial}
            nextOrder={Math.max(0, ...materials.map(m => m.order)) + 1}
          />
        )}
      </div>
    );
  }

  window.TheoryTab = TheoryTab;
})();
